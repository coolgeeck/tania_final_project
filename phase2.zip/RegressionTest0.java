import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        int int0 = org.objectweb.asm.Opcodes.DASTORE;
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 82 + "'", int0 == 82);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        ExampleTransformed.m1();
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        int int0 = org.objectweb.asm.Opcodes.LASTORE;
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 80 + "'", int0 == 80);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        Example.m1();
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        int int0 = org.objectweb.asm.Opcodes.FSTORE;
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 56 + "'", int0 == 56);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        int int0 = org.objectweb.asm.Opcodes.LDC;
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 18 + "'", int0 == 18);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        int int0 = org.objectweb.asm.Opcodes.ISHR;
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 122 + "'", int0 == 122);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        int int0 = org.objectweb.asm.Opcodes.ACC_PROTECTED;
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        int int0 = org.objectweb.asm.Opcodes.INVOKESPECIAL;
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 183 + "'", int0 == 183);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        int int0 = org.objectweb.asm.Opcodes.ASM7;
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 458752 + "'", int0 == 458752);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        int int0 = org.objectweb.asm.Opcodes.ARRAYLENGTH;
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 190 + "'", int0 == 190);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        int int0 = org.objectweb.asm.Opcodes.D2L;
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 143 + "'", int0 == 143);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        int int0 = org.objectweb.asm.Opcodes.INVOKEVIRTUAL;
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 182 + "'", int0 == 182);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        int int0 = org.objectweb.asm.Opcodes.ISUB;
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 100 + "'", int0 == 100);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        int int0 = org.objectweb.asm.Opcodes.ACC_ANNOTATION;
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8192 + "'", int0 == 8192);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        int int0 = org.objectweb.asm.Opcodes.CASTORE;
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 85 + "'", int0 == 85);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        int int0 = org.objectweb.asm.Opcodes.L2F;
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 137 + "'", int0 == 137);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        int int0 = org.objectweb.asm.Opcodes.ICONST_4;
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 7 + "'", int0 == 7);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        java.lang.Integer int0 = org.objectweb.asm.Opcodes.NULL;
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 5 + "'", int0.equals(5));
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        int int0 = org.objectweb.asm.Opcodes.DUP2;
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 92 + "'", int0 == 92);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        int int0 = org.objectweb.asm.Opcodes.ACC_ENUM;
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 16384 + "'", int0 == 16384);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        int int0 = org.objectweb.asm.Opcodes.AALOAD;
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 50 + "'", int0 == 50);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        int int0 = org.objectweb.asm.Opcodes.LSHL;
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 121 + "'", int0 == 121);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        int int0 = org.objectweb.asm.Opcodes.ICONST_3;
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 6 + "'", int0 == 6);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        int int0 = org.objectweb.asm.Opcodes.ATHROW;
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 191 + "'", int0 == 191);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        int int0 = org.objectweb.asm.Opcodes.NOP;
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        int int0 = org.objectweb.asm.Opcodes.IDIV;
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 108 + "'", int0 == 108);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        int int0 = org.objectweb.asm.Opcodes.IFNE;
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 154 + "'", int0 == 154);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        int int0 = org.objectweb.asm.Opcodes.V1_3;
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 47 + "'", int0 == 47);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        int int0 = org.objectweb.asm.Opcodes.IMUL;
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 104 + "'", int0 == 104);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        int int0 = org.objectweb.asm.Opcodes.ACC_FINAL;
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 16 + "'", int0 == 16);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        int int0 = org.objectweb.asm.Opcodes.IFGT;
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 157 + "'", int0 == 157);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        int int0 = org.objectweb.asm.Opcodes.DCONST_0;
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 14 + "'", int0 == 14);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        int int0 = org.objectweb.asm.Opcodes.LSTORE;
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 55 + "'", int0 == 55);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        int int0 = org.objectweb.asm.Opcodes.IFLE;
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 158 + "'", int0 == 158);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        int int0 = org.objectweb.asm.Opcodes.IALOAD;
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 46 + "'", int0 == 46);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        int int0 = org.objectweb.asm.Opcodes.RETURN;
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 177 + "'", int0 == 177);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        int int0 = org.objectweb.asm.Opcodes.IXOR;
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 130 + "'", int0 == 130);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        int int0 = org.objectweb.asm.Opcodes.H_GETSTATIC;
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        int int0 = org.objectweb.asm.Opcodes.ALOAD;
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 25 + "'", int0 == 25);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        int int0 = org.objectweb.asm.Opcodes.F_APPEND;
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        int int0 = org.objectweb.asm.Opcodes.MONITOREXIT;
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 195 + "'", int0 == 195);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        int int0 = org.objectweb.asm.Opcodes.ACC_PUBLIC;
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        int int0 = org.objectweb.asm.Opcodes.LCMP;
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 148 + "'", int0 == 148);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        int int0 = org.objectweb.asm.Opcodes.ICONST_M1;
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        int int0 = org.objectweb.asm.Opcodes.DUP_X1;
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 90 + "'", int0 == 90);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        int int0 = org.objectweb.asm.Opcodes.I2C;
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 146 + "'", int0 == 146);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        ExampleTransformed.m2();
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        int int0 = org.objectweb.asm.Opcodes.MULTIANEWARRAY;
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 197 + "'", int0 == 197);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        int int0 = org.objectweb.asm.Opcodes.V9;
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 53 + "'", int0 == 53);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        int int0 = org.objectweb.asm.Opcodes.IADD;
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 96 + "'", int0 == 96);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        int int0 = org.objectweb.asm.Opcodes.IUSHR;
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 124 + "'", int0 == 124);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        int int0 = org.objectweb.asm.Opcodes.IFNONNULL;
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 199 + "'", int0 == 199);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        int int0 = org.objectweb.asm.Opcodes.V1_2;
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 46 + "'", int0 == 46);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        int int0 = org.objectweb.asm.Opcodes.DNEG;
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 119 + "'", int0 == 119);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        int int0 = org.objectweb.asm.Opcodes.IFEQ;
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 153 + "'", int0 == 153);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        int int0 = org.objectweb.asm.Opcodes.I2F;
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 134 + "'", int0 == 134);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        int int0 = org.objectweb.asm.Opcodes.FADD;
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 98 + "'", int0 == 98);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        int int0 = org.objectweb.asm.Opcodes.ACC_STATIC;
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        int int0 = org.objectweb.asm.Opcodes.DDIV;
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 111 + "'", int0 == 111);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        int int0 = org.objectweb.asm.Opcodes.ACC_OPEN;
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 32 + "'", int0 == 32);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        int int0 = org.objectweb.asm.Opcodes.ACC_SUPER;
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 32 + "'", int0 == 32);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        int int0 = org.objectweb.asm.Opcodes.IF_ICMPLE;
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 164 + "'", int0 == 164);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        int int0 = org.objectweb.asm.Opcodes.IASTORE;
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 79 + "'", int0 == 79);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        int int0 = org.objectweb.asm.Opcodes.I2D;
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 135 + "'", int0 == 135);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        int int0 = org.objectweb.asm.Opcodes.ACC_PRIVATE;
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        int int0 = org.objectweb.asm.Opcodes.ASTORE;
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 58 + "'", int0 == 58);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        int int0 = org.objectweb.asm.Opcodes.T_BYTE;
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        int int0 = org.objectweb.asm.Opcodes.SOURCE_DEPRECATED;
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 256 + "'", int0 == 256);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        int int0 = org.objectweb.asm.Opcodes.V13;
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 57 + "'", int0 == 57);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        int int0 = org.objectweb.asm.Opcodes.DUP;
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 89 + "'", int0 == 89);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        int int0 = org.objectweb.asm.Opcodes.DCMPL;
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 151 + "'", int0 == 151);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        int int0 = org.objectweb.asm.Opcodes.IF_ICMPGT;
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 163 + "'", int0 == 163);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        int int0 = org.objectweb.asm.Opcodes.L2D;
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 138 + "'", int0 == 138);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        int int0 = org.objectweb.asm.Opcodes.GETFIELD;
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 180 + "'", int0 == 180);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        int int0 = org.objectweb.asm.Opcodes.AASTORE;
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 83 + "'", int0 == 83);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        int int0 = org.objectweb.asm.Opcodes.DSUB;
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 103 + "'", int0 == 103);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        int int0 = org.objectweb.asm.Opcodes.F_CHOP;
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        int int0 = org.objectweb.asm.Opcodes.ACC_TRANSITIVE;
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 32 + "'", int0 == 32);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        int int0 = org.objectweb.asm.Opcodes.INVOKEINTERFACE;
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 185 + "'", int0 == 185);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        int int0 = org.objectweb.asm.Opcodes.BALOAD;
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 51 + "'", int0 == 51);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        int int0 = org.objectweb.asm.Opcodes.DADD;
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 99 + "'", int0 == 99);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        int int0 = org.objectweb.asm.Opcodes.F_FULL;
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        int int0 = org.objectweb.asm.Opcodes.PUTFIELD;
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 181 + "'", int0 == 181);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        int int0 = org.objectweb.asm.Opcodes.SWAP;
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 95 + "'", int0 == 95);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        Example.m2();
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        int int0 = org.objectweb.asm.Opcodes.V11;
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 55 + "'", int0 == 55);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        int int0 = org.objectweb.asm.Opcodes.FDIV;
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 110 + "'", int0 == 110);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        int int0 = org.objectweb.asm.Opcodes.ACC_SYNTHETIC;
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4096 + "'", int0 == 4096);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        int int0 = org.objectweb.asm.Opcodes.V12;
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 56 + "'", int0 == 56);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        TransformClassFile transformClassFile0 = new TransformClassFile();
        java.lang.Class<?> wildcardClass1 = transformClassFile0.getClass();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass1);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        int int0 = org.objectweb.asm.Opcodes.LUSHR;
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 125 + "'", int0 == 125);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        int int0 = org.objectweb.asm.Opcodes.FCONST_2;
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 13 + "'", int0 == 13);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        int int0 = org.objectweb.asm.Opcodes.FRETURN;
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 174 + "'", int0 == 174);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        int int0 = org.objectweb.asm.Opcodes.ACC_STRICT;
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2048 + "'", int0 == 2048);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        int int0 = org.objectweb.asm.Opcodes.JSR;
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 168 + "'", int0 == 168);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        int int0 = org.objectweb.asm.Opcodes.TABLESWITCH;
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 170 + "'", int0 == 170);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        int int0 = org.objectweb.asm.Opcodes.CALOAD;
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 52 + "'", int0 == 52);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        int int0 = org.objectweb.asm.Opcodes.RET;
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 169 + "'", int0 == 169);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        int int0 = org.objectweb.asm.Opcodes.IRETURN;
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 172 + "'", int0 == 172);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        int int0 = org.objectweb.asm.Opcodes.DLOAD;
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 24 + "'", int0 == 24);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        int int0 = org.objectweb.asm.Opcodes.T_LONG;
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 11 + "'", int0 == 11);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        int int0 = org.objectweb.asm.Opcodes.ASM5;
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 327680 + "'", int0 == 327680);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        int int0 = org.objectweb.asm.Opcodes.FNEG;
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 118 + "'", int0 == 118);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        int int0 = org.objectweb.asm.Opcodes.BIPUSH;
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 16 + "'", int0 == 16);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        int int0 = org.objectweb.asm.Opcodes.IF_ACMPNE;
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 166 + "'", int0 == 166);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        int int0 = org.objectweb.asm.Opcodes.ICONST_5;
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        java.lang.Integer int0 = org.objectweb.asm.Opcodes.LONG;
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0.equals(4));
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        int int0 = org.objectweb.asm.Opcodes.FCMPL;
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 149 + "'", int0 == 149);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        int int0 = org.objectweb.asm.Opcodes.LCONST_1;
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        int int0 = org.objectweb.asm.Opcodes.INSTANCEOF;
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 193 + "'", int0 == 193);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        int int0 = org.objectweb.asm.Opcodes.D2I;
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 142 + "'", int0 == 142);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        int int0 = org.objectweb.asm.Opcodes.LOR;
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 129 + "'", int0 == 129);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        int int0 = org.objectweb.asm.Opcodes.IFGE;
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 156 + "'", int0 == 156);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        int int0 = org.objectweb.asm.Opcodes.I2B;
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 145 + "'", int0 == 145);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        int int0 = org.objectweb.asm.Opcodes.DUP2_X1;
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 93 + "'", int0 == 93);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        int int0 = org.objectweb.asm.Opcodes.T_FLOAT;
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 6 + "'", int0 == 6);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        int int0 = org.objectweb.asm.Opcodes.FALOAD;
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 48 + "'", int0 == 48);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        int int0 = org.objectweb.asm.Opcodes.F_SAME;
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        java.lang.Integer int0 = org.objectweb.asm.Opcodes.TOP;
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0.equals(0));
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        int int0 = org.objectweb.asm.Opcodes.DMUL;
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 107 + "'", int0 == 107);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        int int0 = org.objectweb.asm.Opcodes.LXOR;
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 131 + "'", int0 == 131);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        int int0 = org.objectweb.asm.Opcodes.BASTORE;
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 84 + "'", int0 == 84);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        int int0 = org.objectweb.asm.Opcodes.SIPUSH;
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 17 + "'", int0 == 17);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        int int0 = org.objectweb.asm.Opcodes.V1_1;
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 196653 + "'", int0 == 196653);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        int int0 = org.objectweb.asm.Opcodes.L2I;
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 136 + "'", int0 == 136);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        java.lang.Integer int0 = org.objectweb.asm.Opcodes.DOUBLE;
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0.equals(3));
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        int int0 = org.objectweb.asm.Opcodes.H_NEWINVOKESPECIAL;
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        int int0 = org.objectweb.asm.Opcodes.LAND;
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 127 + "'", int0 == 127);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        int int0 = org.objectweb.asm.Opcodes.SOURCE_MASK;
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 256 + "'", int0 == 256);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        int int0 = org.objectweb.asm.Opcodes.ICONST_2;
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 5 + "'", int0 == 5);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        int int0 = org.objectweb.asm.Opcodes.V14;
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 58 + "'", int0 == 58);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        int int0 = org.objectweb.asm.Opcodes.DCMPG;
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 152 + "'", int0 == 152);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        int int0 = org.objectweb.asm.Opcodes.ACC_INTERFACE;
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 512 + "'", int0 == 512);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        int int0 = org.objectweb.asm.Opcodes.DUP_X2;
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 91 + "'", int0 == 91);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        int int0 = org.objectweb.asm.Opcodes.ACONST_NULL;
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        int int0 = org.objectweb.asm.Opcodes.LREM;
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 113 + "'", int0 == 113);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        int int0 = org.objectweb.asm.Opcodes.ACC_DEPRECATED;
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 131072 + "'", int0 == 131072);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        int int0 = org.objectweb.asm.Opcodes.FCONST_0;
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 11 + "'", int0 == 11);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        int int0 = org.objectweb.asm.Opcodes.NEWARRAY;
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 188 + "'", int0 == 188);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        int int0 = org.objectweb.asm.Opcodes.GOTO;
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 167 + "'", int0 == 167);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        int int0 = org.objectweb.asm.Opcodes.H_INVOKESTATIC;
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 6 + "'", int0 == 6);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        int int0 = org.objectweb.asm.Opcodes.LMUL;
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 105 + "'", int0 == 105);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        java.lang.Integer int0 = org.objectweb.asm.Opcodes.UNINITIALIZED_THIS;
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 6 + "'", int0.equals(6));
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        int int0 = org.objectweb.asm.Opcodes.IF_ICMPEQ;
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 159 + "'", int0 == 159);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        int int0 = org.objectweb.asm.Opcodes.DALOAD;
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 49 + "'", int0 == 49);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        int int0 = org.objectweb.asm.Opcodes.LALOAD;
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 47 + "'", int0 == 47);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        int int0 = org.objectweb.asm.Opcodes.FCONST_1;
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 12 + "'", int0 == 12);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        int int0 = org.objectweb.asm.Opcodes.T_DOUBLE;
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 7 + "'", int0 == 7);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        java.lang.Integer int0 = org.objectweb.asm.Opcodes.FLOAT;
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0.equals(2));
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        int int0 = org.objectweb.asm.Opcodes.FSUB;
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 102 + "'", int0 == 102);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        int int0 = org.objectweb.asm.Opcodes.V10;
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 54 + "'", int0 == 54);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        int int0 = org.objectweb.asm.Opcodes.DREM;
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 115 + "'", int0 == 115);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        int int0 = org.objectweb.asm.Opcodes.INVOKESTATIC;
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 184 + "'", int0 == 184);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        int int0 = org.objectweb.asm.Opcodes.IINC;
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 132 + "'", int0 == 132);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        int int0 = org.objectweb.asm.Opcodes.IREM;
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 112 + "'", int0 == 112);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        int int0 = org.objectweb.asm.Opcodes.ARETURN;
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 176 + "'", int0 == 176);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        int int0 = org.objectweb.asm.Opcodes.LADD;
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 97 + "'", int0 == 97);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        int int0 = org.objectweb.asm.Opcodes.POP2;
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 88 + "'", int0 == 88);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        int int0 = org.objectweb.asm.Opcodes.F_SAME1;
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        int int0 = org.objectweb.asm.Opcodes.V1_6;
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 50 + "'", int0 == 50);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        int int0 = org.objectweb.asm.Opcodes.ASM6;
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 393216 + "'", int0 == 393216);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        int int0 = org.objectweb.asm.Opcodes.ASM4;
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 262144 + "'", int0 == 262144);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        int int0 = org.objectweb.asm.Opcodes.DSTORE;
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 57 + "'", int0 == 57);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        int int0 = org.objectweb.asm.Opcodes.CHECKCAST;
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 192 + "'", int0 == 192);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        int int0 = org.objectweb.asm.Opcodes.H_GETFIELD;
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        int int0 = org.objectweb.asm.Opcodes.I2L;
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 133 + "'", int0 == 133);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        int int0 = org.objectweb.asm.Opcodes.H_INVOKESPECIAL;
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 7 + "'", int0 == 7);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        int int0 = org.objectweb.asm.Opcodes.IAND;
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 126 + "'", int0 == 126);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        int int0 = org.objectweb.asm.Opcodes.LSUB;
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 101 + "'", int0 == 101);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        int int0 = org.objectweb.asm.Opcodes.T_CHAR;
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 5 + "'", int0 == 5);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        int int0 = org.objectweb.asm.Opcodes.ACC_ABSTRACT;
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1024 + "'", int0 == 1024);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        int int0 = org.objectweb.asm.Opcodes.F2D;
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 141 + "'", int0 == 141);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        int int0 = org.objectweb.asm.Opcodes.F_NEW;
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + (-1) + "'", int0 == (-1));
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        int int0 = org.objectweb.asm.Opcodes.LDIV;
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 109 + "'", int0 == 109);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        int int0 = org.objectweb.asm.Opcodes.T_SHORT;
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 9 + "'", int0 == 9);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        int int0 = org.objectweb.asm.Opcodes.POP;
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 87 + "'", int0 == 87);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        int int0 = org.objectweb.asm.Opcodes.FCMPG;
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 150 + "'", int0 == 150);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        int int0 = org.objectweb.asm.Opcodes.I2S;
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 147 + "'", int0 == 147);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        int int0 = org.objectweb.asm.Opcodes.LSHR;
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 123 + "'", int0 == 123);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        int int0 = org.objectweb.asm.Opcodes.DCONST_1;
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 15 + "'", int0 == 15);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        int int0 = org.objectweb.asm.Opcodes.SALOAD;
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 53 + "'", int0 == 53);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        int int0 = org.objectweb.asm.Opcodes.FASTORE;
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 81 + "'", int0 == 81);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        int int0 = org.objectweb.asm.Opcodes.ISHL;
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 120 + "'", int0 == 120);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        int int0 = org.objectweb.asm.Opcodes.ACC_MODULE;
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 32768 + "'", int0 == 32768);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        int int0 = org.objectweb.asm.Opcodes.FLOAD;
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 23 + "'", int0 == 23);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        int int0 = org.objectweb.asm.Opcodes.IOR;
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 128 + "'", int0 == 128);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        int int0 = org.objectweb.asm.Opcodes.LCONST_0;
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 9 + "'", int0 == 9);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        int int0 = org.objectweb.asm.Opcodes.ICONST_0;
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        int int0 = org.objectweb.asm.Opcodes.V1_7;
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 51 + "'", int0 == 51);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        int int0 = org.objectweb.asm.Opcodes.MONITORENTER;
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 194 + "'", int0 == 194);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        int int0 = org.objectweb.asm.Opcodes.ACC_TRANSIENT;
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 128 + "'", int0 == 128);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        int int0 = org.objectweb.asm.Opcodes.ILOAD;
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 21 + "'", int0 == 21);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        int int0 = org.objectweb.asm.Opcodes.GETSTATIC;
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 178 + "'", int0 == 178);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        int int0 = org.objectweb.asm.Opcodes.V_PREVIEW;
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + (-65536) + "'", int0 == (-65536));
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        int int0 = org.objectweb.asm.Opcodes.ACC_MANDATED;
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 32768 + "'", int0 == 32768);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        int int0 = org.objectweb.asm.Opcodes.ACC_NATIVE;
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 256 + "'", int0 == 256);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        int int0 = org.objectweb.asm.Opcodes.F2I;
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 139 + "'", int0 == 139);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        int int0 = org.objectweb.asm.Opcodes.FMUL;
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 106 + "'", int0 == 106);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        int int0 = org.objectweb.asm.Opcodes.LOOKUPSWITCH;
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 171 + "'", int0 == 171);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        int int0 = org.objectweb.asm.Opcodes.V1_8;
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 52 + "'", int0 == 52);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        int int0 = org.objectweb.asm.Opcodes.LLOAD;
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 22 + "'", int0 == 22);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        int int0 = org.objectweb.asm.Opcodes.ACC_SYNCHRONIZED;
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 32 + "'", int0 == 32);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        int int0 = org.objectweb.asm.Opcodes.H_PUTFIELD;
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        int int0 = org.objectweb.asm.Opcodes.ACC_STATIC_PHASE;
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 64 + "'", int0 == 64);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        int int0 = org.objectweb.asm.Opcodes.T_BOOLEAN;
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        int int0 = org.objectweb.asm.Opcodes.SASTORE;
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 86 + "'", int0 == 86);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        int int0 = org.objectweb.asm.Opcodes.H_INVOKEVIRTUAL;
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 5 + "'", int0 == 5);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        int int0 = org.objectweb.asm.Opcodes.ACC_VOLATILE;
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 64 + "'", int0 == 64);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        java.lang.Integer int0 = org.objectweb.asm.Opcodes.INTEGER;
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0.equals(1));
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        int int0 = org.objectweb.asm.Opcodes.V1_4;
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 48 + "'", int0 == 48);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        Temp temp0 = new Temp();
        temp0.m1("", (java.lang.Object) 127, 95);
        java.lang.Class<?> wildcardClass5 = temp0.getClass();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass5);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        int int0 = org.objectweb.asm.Opcodes.IF_ACMPEQ;
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 165 + "'", int0 == 165);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        int int0 = org.objectweb.asm.Opcodes.ACC_VARARGS;
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 128 + "'", int0 == 128);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        int int0 = org.objectweb.asm.Opcodes.T_INT;
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        int int0 = org.objectweb.asm.Opcodes.INVOKEDYNAMIC;
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 186 + "'", int0 == 186);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        int int0 = org.objectweb.asm.Opcodes.IFNULL;
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 198 + "'", int0 == 198);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        int int0 = org.objectweb.asm.Opcodes.INEG;
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 116 + "'", int0 == 116);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        int int0 = org.objectweb.asm.Opcodes.IF_ICMPLT;
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 161 + "'", int0 == 161);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        int int0 = org.objectweb.asm.Opcodes.IF_ICMPNE;
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 160 + "'", int0 == 160);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        int int0 = org.objectweb.asm.Opcodes.FREM;
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 114 + "'", int0 == 114);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        int int0 = org.objectweb.asm.Opcodes.DUP2_X2;
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 94 + "'", int0 == 94);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        int int0 = org.objectweb.asm.Opcodes.ISTORE;
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 54 + "'", int0 == 54);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        int int0 = org.objectweb.asm.Opcodes.NEW;
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 187 + "'", int0 == 187);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        int int0 = org.objectweb.asm.Opcodes.V1_5;
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 49 + "'", int0 == 49);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        int int0 = org.objectweb.asm.Opcodes.DRETURN;
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 175 + "'", int0 == 175);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        int int0 = org.objectweb.asm.Opcodes.F2L;
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 140 + "'", int0 == 140);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        int int0 = org.objectweb.asm.Opcodes.H_PUTSTATIC;
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        int int0 = org.objectweb.asm.Opcodes.ICONST_1;
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        int int0 = org.objectweb.asm.Opcodes.D2F;
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 144 + "'", int0 == 144);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        int int0 = org.objectweb.asm.Opcodes.LNEG;
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 117 + "'", int0 == 117);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        int int0 = org.objectweb.asm.Opcodes.IF_ICMPGE;
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 162 + "'", int0 == 162);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        int int0 = org.objectweb.asm.Opcodes.ACC_BRIDGE;
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 64 + "'", int0 == 64);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        int int0 = org.objectweb.asm.Opcodes.IFLT;
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 155 + "'", int0 == 155);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        int int0 = org.objectweb.asm.Opcodes.ANEWARRAY;
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 189 + "'", int0 == 189);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        int int0 = org.objectweb.asm.Opcodes.PUTSTATIC;
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 179 + "'", int0 == 179);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        int int0 = org.objectweb.asm.Opcodes.H_INVOKEINTERFACE;
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 9 + "'", int0 == 9);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        int int0 = org.objectweb.asm.Opcodes.LRETURN;
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 173 + "'", int0 == 173);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        Temp temp0 = new Temp();
        temp0.m1("", (java.lang.Object) 127, 95);
        temp0.m1("hi!", (java.lang.Object) 126, 22);
        java.lang.Class<?> wildcardClass9 = temp0.getClass();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass9);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        Temp temp0 = new Temp();
        temp0.m1("", (java.lang.Object) 127, 95);
        temp0.m();
        temp0.m();
        java.lang.Class<?> wildcardClass7 = temp0.getClass();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass7);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        Temp temp0 = new Temp();
        temp0.m1("", (java.lang.Object) 127, 95);
        temp0.m();
        Temp temp7 = new Temp();
        temp7.m();
        temp7.m1("hi!", (java.lang.Object) 88, 94);
        temp7.m1("hi!", (java.lang.Object) 131, 98);
        temp7.m1("", (java.lang.Object) 13, 103);
        temp0.m1("", (java.lang.Object) temp7, 131);
        temp0.m1("", (java.lang.Object) 135, 115);
        java.lang.Class<?> wildcardClass27 = temp0.getClass();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass27);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        Temp temp0 = new Temp();
        temp0.m1("", (java.lang.Object) 127, 95);
        temp0.m1("hi!", (java.lang.Object) 126, 22);
        temp0.m1("", (java.lang.Object) 152, 199);
        java.lang.Class<?> wildcardClass13 = temp0.getClass();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass13);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        Temp temp0 = new Temp();
        temp0.m1("", (java.lang.Object) 127, 95);
        temp0.m1("hi!", (java.lang.Object) 126, 22);
        temp0.m1("", (java.lang.Object) 157, 154);
        temp0.m();
        temp0.m1("", (java.lang.Object) 161, 0);
        java.lang.Class<?> wildcardClass18 = temp0.getClass();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass18);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        Temp temp0 = new Temp();
        temp0.m1("", (java.lang.Object) 127, 95);
        temp0.m1("hi!", (java.lang.Object) 126, 22);
        temp0.m1("", (java.lang.Object) 157, 154);
        ExampleTransformed exampleTransformed14 = new ExampleTransformed();
        temp0.m1("hi!", (java.lang.Object) exampleTransformed14, 10);
        temp0.m();
        java.lang.Class<?> wildcardClass18 = temp0.getClass();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass18);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        Temp temp0 = new Temp();
        temp0.m();
        temp0.m1("hi!", (java.lang.Object) 88, 94);
        temp0.m1("hi!", (java.lang.Object) 131, 98);
        temp0.m1("hi!", (java.lang.Object) 4096, 0);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        Temp temp0 = new Temp();
        temp0.m();
        temp0.m1("hi!", (java.lang.Object) 88, 94);
        temp0.m1("hi!", (java.lang.Object) 131, 98);
        temp0.m1("", (java.lang.Object) 13, 103);
        temp0.m1("hi!", (java.lang.Object) 131, 143);
        java.lang.Class<?> wildcardClass18 = temp0.getClass();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass18);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        Temp temp0 = new Temp();
        temp0.m1("hi!", (java.lang.Object) (short) 100, 120);
        temp0.m();
        temp0.m();
        java.lang.Class<?> wildcardClass7 = temp0.getClass();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass7);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        Temp temp0 = new Temp();
        temp0.m();
        temp0.m1("", (java.lang.Object) 15, 141);
        temp0.m1("", (java.lang.Object) 128, (int) (short) 100);
        java.lang.Class<?> wildcardClass10 = temp0.getClass();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass10);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        Temp temp0 = new Temp();
        temp0.m();
        temp0.m1("hi!", (java.lang.Object) 88, 94);
        temp0.m1("hi!", (java.lang.Object) 131, 98);
        temp0.m1("", (java.lang.Object) 13, 103);
        temp0.m1("hi!", (java.lang.Object) 131, 143);
        temp0.m1("hi!", (java.lang.Object) 161, 132);
        java.lang.Class<?> wildcardClass22 = temp0.getClass();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass22);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        Temp temp0 = new Temp();
        temp0.m1("hi!", (java.lang.Object) (short) 100, 120);
        temp0.m();
        temp0.m1("hi!", (java.lang.Object) 131072, 176);
        java.lang.Class<?> wildcardClass10 = temp0.getClass();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass10);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        Temp temp0 = new Temp();
        java.lang.Class<?> wildcardClass1 = temp0.getClass();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass1);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        Temp temp0 = new Temp();
        temp0.m1("", (java.lang.Object) 127, 95);
        temp0.m1("hi!", (java.lang.Object) 126, 22);
        temp0.m1("", (java.lang.Object) 157, 154);
        temp0.m();
        java.lang.Class<?> wildcardClass14 = temp0.getClass();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass14);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        Temp temp0 = new Temp();
        temp0.m1("", (java.lang.Object) 127, 95);
        temp0.m();
        Temp temp7 = new Temp();
        temp7.m();
        temp7.m1("hi!", (java.lang.Object) 88, 94);
        temp7.m1("hi!", (java.lang.Object) 131, 98);
        temp7.m1("", (java.lang.Object) 13, 103);
        temp0.m1("", (java.lang.Object) temp7, 131);
        temp0.m1("", (java.lang.Object) 135, 115);
        temp0.m();
        temp0.m();
        temp0.m();
        temp0.m1("", (java.lang.Object) 181, 0);
        java.lang.Class<?> wildcardClass34 = temp0.getClass();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass34);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        Temp temp0 = new Temp();
        temp0.m();
        temp0.m1("hi!", (java.lang.Object) 88, 94);
        temp0.m1("hi!", (java.lang.Object) 131, 98);
        temp0.m1("", (java.lang.Object) 13, 103);
        temp0.m1("hi!", (java.lang.Object) 131, 143);
        temp0.m1("", (java.lang.Object) 195, 118);
        temp0.m1("", (java.lang.Object) 96, 88);
        java.lang.Class<?> wildcardClass26 = temp0.getClass();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass26);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        Temp temp0 = new Temp();
        temp0.m();
        temp0.m1("hi!", (java.lang.Object) 88, 94);
        temp0.m1("hi!", (java.lang.Object) 131, 98);
        temp0.m1("", (java.lang.Object) 13, 103);
        temp0.m1("hi!", (java.lang.Object) 131, 143);
        temp0.m1("hi!", (java.lang.Object) 161, 132);
        temp0.m();
        temp0.m1("", (java.lang.Object) 171, 2);
        Temp temp28 = new Temp();
        temp28.m();
        temp28.m1("hi!", (java.lang.Object) 88, 94);
        temp28.m1("hi!", (java.lang.Object) 131, 98);
        temp28.m1("", (java.lang.Object) 13, 103);
        temp28.m1("hi!", (java.lang.Object) 131, 143);
        temp28.m1("hi!", (java.lang.Object) 161, 132);
        temp0.m1("hi!", (java.lang.Object) temp28, 56);
        java.lang.Class<?> wildcardClass52 = temp28.getClass();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass52);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        Temp temp0 = new Temp();
        temp0.m();
        temp0.m();
        java.lang.Class<?> wildcardClass3 = temp0.getClass();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass3);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        Temp temp0 = new Temp();
        temp0.m();
        temp0.m1("hi!", (java.lang.Object) 88, 94);
        temp0.m1("hi!", (java.lang.Object) 131, 98);
        temp0.m1("", (java.lang.Object) 13, 103);
        temp0.m1("hi!", (java.lang.Object) 131, 143);
        temp0.m1("", (java.lang.Object) 262144, 158);
        java.lang.Class<?> wildcardClass22 = temp0.getClass();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass22);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        Temp temp0 = new Temp();
        temp0.m();
        temp0.m1("hi!", (java.lang.Object) 88, 94);
        temp0.m();
        java.lang.Class<?> wildcardClass7 = temp0.getClass();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass7);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        Temp temp0 = new Temp();
        temp0.m1("", (java.lang.Object) 127, 95);
        temp0.m();
        temp0.m();
        Temp temp8 = new Temp();
        temp8.m();
        temp8.m1("hi!", (java.lang.Object) 88, 94);
        temp8.m1("hi!", (java.lang.Object) 131, 98);
        temp8.m1("", (java.lang.Object) 13, 103);
        temp8.m1("hi!", (java.lang.Object) 131, 143);
        temp8.m1("", (java.lang.Object) 23, 113);
        java.lang.Object obj31 = null;
        temp8.m1("hi!", obj31, 58);
        temp0.m1("", (java.lang.Object) temp8, 256);
        temp8.m1("hi!", (java.lang.Object) 175, 180);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        Temp temp0 = new Temp();
        temp0.m1("", (java.lang.Object) 127, 95);
        temp0.m1("hi!", (java.lang.Object) 126, 22);
        temp0.m1("", (java.lang.Object) 157, 154);
        temp0.m();
        temp0.m();
        temp0.m();
        temp0.m1("hi!", (java.lang.Object) 172, 112);
        java.lang.Class<?> wildcardClass20 = temp0.getClass();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass20);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        Temp temp0 = new Temp();
        temp0.m();
        temp0.m1("hi!", (java.lang.Object) 88, 94);
        temp0.m1("hi!", (java.lang.Object) 131, 98);
        temp0.m1("", (java.lang.Object) 13, 103);
        Temp temp15 = new Temp();
        temp15.m1("", (java.lang.Object) 127, 95);
        temp15.m1("hi!", (java.lang.Object) 126, 22);
        temp15.m1("", (java.lang.Object) 157, 154);
        java.lang.Class<?> wildcardClass28 = temp15.getClass();
        temp0.m1("", (java.lang.Object) temp15, 180);
        java.lang.Class<?> wildcardClass31 = temp0.getClass();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass28);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass31);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        ParseClassFile parseClassFile0 = new ParseClassFile();
        java.lang.Class<?> wildcardClass1 = parseClassFile0.getClass();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass1);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        Temp temp0 = new Temp();
        temp0.m1("", (java.lang.Object) 127, 95);
        temp0.m();
        Example example7 = new Example();
        java.lang.Class<?> wildcardClass8 = example7.getClass();
        temp0.m1("", (java.lang.Object) wildcardClass8, 166);
        java.lang.Class<?> wildcardClass11 = temp0.getClass();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass8);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass11);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        Temp temp0 = new Temp();
        temp0.m();
        temp0.m1("hi!", (java.lang.Object) 88, 94);
        temp0.m1("hi!", (java.lang.Object) 131, 98);
        temp0.m1("", (java.lang.Object) 147, (-65536));
        temp0.m();
        java.lang.Class<?> wildcardClass15 = temp0.getClass();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass15);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        Temp temp0 = new Temp();
        temp0.m();
        temp0.m1("hi!", (java.lang.Object) 88, 94);
        temp0.m1("hi!", (java.lang.Object) 131, 98);
        temp0.m1("", (java.lang.Object) 13, 103);
        temp0.m1("hi!", (java.lang.Object) 131, 143);
        temp0.m1("", (java.lang.Object) 262144, 158);
        temp0.m();
        java.lang.Class<?> wildcardClass23 = temp0.getClass();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass23);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        Temp temp0 = new Temp();
        temp0.m();
        temp0.m1("hi!", (java.lang.Object) 88, 94);
        temp0.m1("hi!", (java.lang.Object) 131, 98);
        temp0.m1("", (java.lang.Object) 13, 103);
        temp0.m1("hi!", (java.lang.Object) 131, 143);
        temp0.m1("hi!", (java.lang.Object) 161, 132);
        temp0.m();
        temp0.m1("", (java.lang.Object) 171, 2);
        Temp temp28 = new Temp();
        temp28.m();
        temp28.m1("hi!", (java.lang.Object) 88, 94);
        temp28.m1("hi!", (java.lang.Object) 131, 98);
        temp28.m1("", (java.lang.Object) 13, 103);
        temp28.m1("hi!", (java.lang.Object) 131, 143);
        temp28.m1("hi!", (java.lang.Object) 161, 132);
        temp0.m1("hi!", (java.lang.Object) temp28, 56);
        java.lang.Object obj53 = null;
        temp0.m1("hi!", obj53, 161);
        temp0.m1("hi!", (java.lang.Object) 172, 183);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        Temp temp0 = new Temp();
        temp0.m();
        temp0.m1("", (java.lang.Object) 15, 157);
        temp0.m1("hi!", (java.lang.Object) 21, 152);
        temp0.m1("hi!", (java.lang.Object) 53, 53);
        java.lang.Class<?> wildcardClass14 = temp0.getClass();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass14);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        Temp temp0 = new Temp();
        temp0.m();
        temp0.m1("", (java.lang.Object) 15, 141);
        Temp temp7 = new Temp();
        temp7.m();
        temp7.m1("hi!", (java.lang.Object) 88, 94);
        temp7.m1("hi!", (java.lang.Object) 131, 98);
        temp7.m1("", (java.lang.Object) 13, 103);
        temp7.m1("hi!", (java.lang.Object) 131, 143);
        temp7.m1("", (java.lang.Object) 262144, 158);
        temp7.m();
        temp7.m1("hi!", (java.lang.Object) 161, 85);
        java.lang.Class<?> wildcardClass34 = temp7.getClass();
        temp0.m1("", (java.lang.Object) wildcardClass34, 184);
        java.lang.Class<?> wildcardClass37 = temp0.getClass();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass34);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass37);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        Temp temp0 = new Temp();
        temp0.m1("", (java.lang.Object) 127, 95);
        temp0.m1("hi!", (java.lang.Object) 126, 22);
        temp0.m1("", (java.lang.Object) 157, 154);
        ExampleTransformed exampleTransformed14 = new ExampleTransformed();
        temp0.m1("hi!", (java.lang.Object) exampleTransformed14, 10);
        java.lang.Class<?> wildcardClass17 = exampleTransformed14.getClass();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass17);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        Temp temp0 = new Temp();
        temp0.m();
        temp0.m1("hi!", (java.lang.Object) 88, 94);
        temp0.m1("hi!", (java.lang.Object) 131, 98);
        temp0.m1("", (java.lang.Object) 147, (-65536));
        temp0.m1("hi!", (java.lang.Object) 86, 177);
        Temp temp19 = new Temp();
        temp19.m1("", (java.lang.Object) 127, 95);
        temp19.m();
        Temp temp26 = new Temp();
        temp26.m();
        temp26.m1("hi!", (java.lang.Object) 88, 94);
        temp26.m1("hi!", (java.lang.Object) 131, 98);
        temp26.m1("", (java.lang.Object) 13, 103);
        temp19.m1("", (java.lang.Object) temp26, 131);
        temp26.m();
        java.lang.Class<?> wildcardClass43 = temp26.getClass();
        temp0.m1("hi!", (java.lang.Object) temp26, 147);
        temp26.m1("hi!", (java.lang.Object) (byte) 0, 172);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass43);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        Temp temp0 = new Temp();
        temp0.m();
        temp0.m1("", (java.lang.Object) 15, 141);
        temp0.m();
        temp0.m();
        java.lang.Class<?> wildcardClass8 = temp0.getClass();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass8);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        Temp temp0 = new Temp();
        temp0.m1("", (java.lang.Object) 127, 95);
        temp0.m();
        Temp temp7 = new Temp();
        temp7.m();
        temp7.m1("hi!", (java.lang.Object) 88, 94);
        temp7.m1("hi!", (java.lang.Object) 131, 98);
        temp7.m1("", (java.lang.Object) 13, 103);
        temp0.m1("", (java.lang.Object) temp7, 131);
        temp0.m();
        temp0.m();
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        Temp temp0 = new Temp();
        temp0.m1("", (java.lang.Object) 127, 95);
        temp0.m();
        Temp temp7 = new Temp();
        temp7.m();
        temp7.m1("hi!", (java.lang.Object) 88, 94);
        temp7.m1("hi!", (java.lang.Object) 131, 98);
        temp7.m1("", (java.lang.Object) 13, 103);
        temp0.m1("", (java.lang.Object) temp7, 131);
        temp0.m1("", (java.lang.Object) 176, 183);
        Temp temp28 = new Temp();
        temp28.m1("", (java.lang.Object) 127, 95);
        temp28.m1("hi!", (java.lang.Object) 126, 22);
        temp28.m1("", (java.lang.Object) 157, 154);
        temp28.m();
        temp28.m();
        temp28.m();
        temp28.m1("hi!", (java.lang.Object) 172, 112);
        temp28.m();
        temp0.m1("hi!", (java.lang.Object) temp28, 15);
        Temp temp52 = new Temp();
        temp52.m();
        temp52.m1("hi!", (java.lang.Object) 88, 94);
        temp52.m1("hi!", (java.lang.Object) 131, 98);
        temp52.m1("", (java.lang.Object) 13, 103);
        temp52.m1("hi!", (java.lang.Object) 131, 143);
        temp52.m1("", (java.lang.Object) 23, 113);
        CopyClassFile copyClassFile75 = new CopyClassFile();
        java.lang.Class<?> wildcardClass76 = copyClassFile75.getClass();
        temp52.m1("hi!", (java.lang.Object) wildcardClass76, 131);
        temp52.m1("", (java.lang.Object) 95, 135);
        temp28.m1("hi!", (java.lang.Object) "", 135);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass76);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        Temp temp0 = new Temp();
        temp0.m1("", (java.lang.Object) 127, 95);
        temp0.m1("hi!", (java.lang.Object) 126, 22);
        temp0.m1("hi!", (java.lang.Object) 85, 174);
        java.lang.Class<?> wildcardClass13 = temp0.getClass();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass13);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        Temp temp0 = new Temp();
        temp0.m();
        temp0.m1("hi!", (java.lang.Object) 88, 94);
        temp0.m1("hi!", (java.lang.Object) 131, 98);
        temp0.m1("", (java.lang.Object) 13, 103);
        temp0.m1("hi!", (java.lang.Object) 131, 143);
        temp0.m1("", (java.lang.Object) 23, 113);
        CopyClassFile copyClassFile23 = new CopyClassFile();
        java.lang.Class<?> wildcardClass24 = copyClassFile23.getClass();
        temp0.m1("hi!", (java.lang.Object) wildcardClass24, 131);
        temp0.m();
        temp0.m();
        java.lang.Class<?> wildcardClass29 = temp0.getClass();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass24);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass29);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        Temp temp0 = new Temp();
        temp0.m1("", (java.lang.Object) 127, 95);
        temp0.m1("hi!", (java.lang.Object) 126, 22);
        temp0.m1("", (java.lang.Object) 157, 154);
        temp0.m();
        temp0.m();
        temp0.m();
        java.lang.Class<?> wildcardClass16 = temp0.getClass();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass16);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        Temp temp0 = new Temp();
        temp0.m1("", (java.lang.Object) 127, 95);
        temp0.m();
        temp0.m1("hi!", (java.lang.Object) 120, 15);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        Temp temp0 = new Temp();
        temp0.m1("", (java.lang.Object) 127, 95);
        temp0.m1("hi!", (java.lang.Object) 126, 22);
        temp0.m1("", (java.lang.Object) 157, 154);
        temp0.m();
        temp0.m();
        temp0.m();
        temp0.m1("hi!", (java.lang.Object) 172, 112);
        temp0.m();
        temp0.m();
        java.lang.Class<?> wildcardClass22 = temp0.getClass();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass22);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        Temp temp0 = new Temp();
        temp0.m();
        temp0.m1("", (java.lang.Object) 15, 141);
        temp0.m();
        temp0.m();
        temp0.m();
        java.lang.Class<?> wildcardClass9 = temp0.getClass();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass9);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        Temp temp0 = new Temp();
        temp0.m1("", (java.lang.Object) 127, 95);
        temp0.m1("hi!", (java.lang.Object) 126, 22);
        temp0.m1("", (java.lang.Object) 157, 154);
        ExampleTransformed exampleTransformed14 = new ExampleTransformed();
        temp0.m1("hi!", (java.lang.Object) exampleTransformed14, 10);
        temp0.m();
        temp0.m1("hi!", (java.lang.Object) 256, 51);
        temp0.m();
        Temp temp24 = new Temp();
        temp24.m();
        temp24.m1("hi!", (java.lang.Object) 88, 94);
        temp24.m1("hi!", (java.lang.Object) 131, 98);
        temp24.m1("", (java.lang.Object) 13, 103);
        temp24.m1("hi!", (java.lang.Object) 131, 143);
        temp24.m1("", (java.lang.Object) 23, 113);
        CopyClassFile copyClassFile47 = new CopyClassFile();
        java.lang.Class<?> wildcardClass48 = copyClassFile47.getClass();
        temp24.m1("hi!", (java.lang.Object) wildcardClass48, 131);
        java.lang.Class<?> wildcardClass51 = temp24.getClass();
        temp0.m1("hi!", (java.lang.Object) wildcardClass51, 131072);
        Temp temp55 = new Temp();
        temp55.m();
        temp55.m1("hi!", (java.lang.Object) 88, 94);
        temp55.m1("hi!", (java.lang.Object) 131, 98);
        temp55.m1("", (java.lang.Object) 13, 103);
        Temp temp70 = new Temp();
        temp70.m1("", (java.lang.Object) 127, 95);
        temp70.m1("hi!", (java.lang.Object) 126, 22);
        temp70.m1("", (java.lang.Object) 157, 154);
        temp70.m();
        temp70.m1("", (java.lang.Object) 161, 0);
        temp55.m1("hi!", (java.lang.Object) "", 86);
        java.lang.Class<?> wildcardClass90 = temp55.getClass();
        temp0.m1("", (java.lang.Object) wildcardClass90, 14);
        java.lang.Class<?> wildcardClass93 = temp0.getClass();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass48);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass51);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass90);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass93);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        Temp temp0 = new Temp();
        temp0.m1("", (java.lang.Object) 127, 95);
        temp0.m();
        temp0.m();
        temp0.m1("hi!", (java.lang.Object) 127, 149);
        java.lang.Class<?> wildcardClass11 = temp0.getClass();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass11);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        Temp temp0 = new Temp();
        temp0.m();
        temp0.m1("hi!", (java.lang.Object) 88, 94);
        temp0.m1("hi!", (java.lang.Object) 131, 98);
        temp0.m1("", (java.lang.Object) 13, 103);
        Temp temp15 = new Temp();
        temp15.m1("", (java.lang.Object) 127, 95);
        temp15.m1("hi!", (java.lang.Object) 126, 22);
        temp15.m1("", (java.lang.Object) 157, 154);
        temp15.m();
        temp15.m1("", (java.lang.Object) 161, 0);
        temp0.m1("hi!", (java.lang.Object) "", 86);
        temp0.m();
        java.lang.Class<?> wildcardClass36 = temp0.getClass();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass36);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        Temp temp0 = new Temp();
        temp0.m();
        temp0.m1("hi!", (java.lang.Object) 88, 94);
        temp0.m1("hi!", (java.lang.Object) 131, 98);
        temp0.m1("", (java.lang.Object) 13, 103);
        temp0.m1("hi!", (java.lang.Object) 131, 143);
        temp0.m1("", (java.lang.Object) 195, 118);
        Temp temp23 = new Temp();
        temp23.m();
        temp23.m1("hi!", (java.lang.Object) 88, 94);
        temp23.m1("hi!", (java.lang.Object) 131, 98);
        temp23.m1("", (java.lang.Object) 13, 103);
        temp23.m1("hi!", (java.lang.Object) 131, 143);
        temp23.m1("", (java.lang.Object) 23, 113);
        CopyClassFile copyClassFile46 = new CopyClassFile();
        java.lang.Class<?> wildcardClass47 = copyClassFile46.getClass();
        temp23.m1("hi!", (java.lang.Object) wildcardClass47, 131);
        temp23.m();
        temp23.m1("", (java.lang.Object) 121, (int) (byte) 10);
        temp0.m1("hi!", (java.lang.Object) temp23, 11);
        temp23.m();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass47);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        Temp temp0 = new Temp();
        temp0.m1("", (java.lang.Object) 127, 95);
        temp0.m1("hi!", (java.lang.Object) 126, 22);
        temp0.m1("", (java.lang.Object) 157, 154);
        ExampleTransformed exampleTransformed14 = new ExampleTransformed();
        temp0.m1("hi!", (java.lang.Object) exampleTransformed14, 10);
        temp0.m();
        temp0.m1("hi!", (java.lang.Object) 256, 51);
        temp0.m();
        Temp temp24 = new Temp();
        temp24.m();
        temp24.m1("hi!", (java.lang.Object) 88, 94);
        temp24.m1("hi!", (java.lang.Object) 131, 98);
        temp24.m1("", (java.lang.Object) 13, 103);
        temp24.m1("hi!", (java.lang.Object) 131, 143);
        temp24.m1("", (java.lang.Object) 23, 113);
        CopyClassFile copyClassFile47 = new CopyClassFile();
        java.lang.Class<?> wildcardClass48 = copyClassFile47.getClass();
        temp24.m1("hi!", (java.lang.Object) wildcardClass48, 131);
        java.lang.Class<?> wildcardClass51 = temp24.getClass();
        temp0.m1("hi!", (java.lang.Object) wildcardClass51, 131072);
        java.lang.Class<?> wildcardClass54 = temp0.getClass();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass48);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass51);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass54);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        Temp temp0 = new Temp();
        temp0.m();
        temp0.m1("hi!", (java.lang.Object) 88, 94);
        temp0.m1("hi!", (java.lang.Object) 131, 98);
        temp0.m1("", (java.lang.Object) 13, 103);
        temp0.m1("hi!", (java.lang.Object) 131, 143);
        temp0.m1("", (java.lang.Object) 23, 113);
        CopyClassFile copyClassFile23 = new CopyClassFile();
        java.lang.Class<?> wildcardClass24 = copyClassFile23.getClass();
        temp0.m1("hi!", (java.lang.Object) wildcardClass24, 131);
        temp0.m1("", (java.lang.Object) 95, 135);
        temp0.m1("", (java.lang.Object) 101, 105);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass24);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        Temp temp0 = new Temp();
        temp0.m();
        temp0.m1("hi!", (java.lang.Object) 88, 94);
        temp0.m1("hi!", (java.lang.Object) 131, 98);
        temp0.m1("", (java.lang.Object) 13, 103);
        temp0.m1("hi!", (java.lang.Object) 131, 143);
        temp0.m1("", (java.lang.Object) 262144, 158);
        temp0.m();
        temp0.m1("hi!", (java.lang.Object) 161, 85);
        Temp temp28 = new Temp();
        temp28.m1("", (java.lang.Object) 127, 95);
        temp28.m1("hi!", (java.lang.Object) 126, 22);
        temp28.m1("", (java.lang.Object) 157, 154);
        temp28.m();
        temp28.m();
        temp28.m1("", (java.lang.Object) 11, 136);
        java.lang.Class<?> wildcardClass47 = temp28.getClass();
        temp0.m1("", (java.lang.Object) temp28, (int) (byte) 1);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass47);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        Temp temp0 = new Temp();
        temp0.m1("", (java.lang.Object) 127, 95);
        temp0.m1("hi!", (java.lang.Object) 87, 179);
        temp0.m();
        temp0.m1("", (java.lang.Object) 179, (-1));
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        Temp temp0 = new Temp();
        temp0.m();
        temp0.m1("hi!", (java.lang.Object) 88, 94);
        temp0.m1("hi!", (java.lang.Object) 131, 98);
        temp0.m1("", (java.lang.Object) 13, 103);
        temp0.m();
        temp0.m();
        temp0.m();
        temp0.m1("hi!", (java.lang.Object) 262144, 84);
        temp0.m1("hi!", (java.lang.Object) 141, 103);
        temp0.m();
        java.lang.Class<?> wildcardClass26 = temp0.getClass();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass26);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        Temp temp0 = new Temp();
        temp0.m();
        temp0.m1("hi!", (java.lang.Object) 88, 94);
        temp0.m1("hi!", (java.lang.Object) 131, 98);
        temp0.m1("", (java.lang.Object) 13, 103);
        temp0.m1("hi!", (java.lang.Object) 131, 143);
        temp0.m1("", (java.lang.Object) 23, 113);
        CopyClassFile copyClassFile23 = new CopyClassFile();
        java.lang.Class<?> wildcardClass24 = copyClassFile23.getClass();
        temp0.m1("hi!", (java.lang.Object) wildcardClass24, 131);
        temp0.m1("", (java.lang.Object) 95, 135);
        java.lang.Object obj32 = new java.lang.Object();
        java.lang.Class<?> wildcardClass33 = obj32.getClass();
        temp0.m1("", obj32, 0);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass24);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass33);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        Temp temp0 = new Temp();
        temp0.m();
        temp0.m1("hi!", (java.lang.Object) 88, 94);
        temp0.m1("hi!", (java.lang.Object) 131, 98);
        temp0.m1("", (java.lang.Object) 13, 103);
        temp0.m1("hi!", (java.lang.Object) 131, 143);
        temp0.m1("hi!", (java.lang.Object) 161, 132);
        temp0.m();
        temp0.m1("", (java.lang.Object) 171, 2);
        Temp temp28 = new Temp();
        temp28.m();
        temp28.m1("hi!", (java.lang.Object) 88, 94);
        temp28.m1("hi!", (java.lang.Object) 131, 98);
        temp28.m1("", (java.lang.Object) 13, 103);
        temp28.m1("hi!", (java.lang.Object) 131, 143);
        temp28.m1("hi!", (java.lang.Object) 161, 132);
        temp0.m1("hi!", (java.lang.Object) temp28, 56);
        temp28.m();
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        Temp temp0 = new Temp();
        temp0.m();
        temp0.m1("hi!", (java.lang.Object) 88, 94);
        temp0.m1("hi!", (java.lang.Object) 131, 98);
        temp0.m1("", (java.lang.Object) 13, 103);
        temp0.m1("hi!", (java.lang.Object) 131, 143);
        temp0.m1("", (java.lang.Object) 195, 0);
        java.lang.Class<?> wildcardClass22 = temp0.getClass();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass22);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        Temp temp0 = new Temp();
        temp0.m();
        temp0.m1("hi!", (java.lang.Object) 88, 94);
        temp0.m();
        temp0.m1("hi!", (java.lang.Object) 187, 0);
        java.lang.Class<?> wildcardClass11 = temp0.getClass();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass11);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        Temp temp0 = new Temp();
        temp0.m();
        temp0.m1("hi!", (java.lang.Object) 88, 94);
        temp0.m1("hi!", (java.lang.Object) 131, 98);
        temp0.m1("", (java.lang.Object) 13, 103);
        temp0.m1("hi!", (java.lang.Object) 131, 143);
        temp0.m1("", (java.lang.Object) 23, 113);
        CopyClassFile copyClassFile23 = new CopyClassFile();
        java.lang.Class<?> wildcardClass24 = copyClassFile23.getClass();
        temp0.m1("hi!", (java.lang.Object) wildcardClass24, 131);
        temp0.m();
        temp0.m1("", (java.lang.Object) 121, (int) (byte) 10);
        java.lang.Class<?> wildcardClass32 = temp0.getClass();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass24);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass32);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        Temp temp0 = new Temp();
        temp0.m1("", (java.lang.Object) 127, 95);
        temp0.m1("hi!", (java.lang.Object) 126, 22);
        temp0.m1("", (java.lang.Object) 157, 154);
        ExampleTransformed exampleTransformed14 = new ExampleTransformed();
        temp0.m1("hi!", (java.lang.Object) exampleTransformed14, 10);
        temp0.m();
        temp0.m1("hi!", (java.lang.Object) 256, 51);
        temp0.m();
        Temp temp24 = new Temp();
        temp24.m();
        temp24.m1("hi!", (java.lang.Object) 88, 94);
        temp24.m1("hi!", (java.lang.Object) 131, 98);
        temp24.m1("", (java.lang.Object) 13, 103);
        temp24.m1("hi!", (java.lang.Object) 131, 143);
        temp24.m1("", (java.lang.Object) 23, 113);
        CopyClassFile copyClassFile47 = new CopyClassFile();
        java.lang.Class<?> wildcardClass48 = copyClassFile47.getClass();
        temp24.m1("hi!", (java.lang.Object) wildcardClass48, 131);
        java.lang.Class<?> wildcardClass51 = temp24.getClass();
        temp0.m1("hi!", (java.lang.Object) wildcardClass51, 131072);
        Temp temp55 = new Temp();
        temp55.m1("", (java.lang.Object) 127, 95);
        temp55.m();
        Temp temp62 = new Temp();
        temp62.m();
        temp62.m1("hi!", (java.lang.Object) 88, 94);
        temp62.m1("hi!", (java.lang.Object) 131, 98);
        temp62.m1("", (java.lang.Object) 13, 103);
        temp55.m1("", (java.lang.Object) temp62, 131);
        temp62.m();
        temp62.m();
        temp62.m1("", (java.lang.Object) 54, 150);
        java.lang.Object obj85 = null;
        temp62.m1("", obj85, 82);
        temp0.m1("hi!", (java.lang.Object) 82, 9);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass48);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass51);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        Temp temp0 = new Temp();
        temp0.m1("", (java.lang.Object) 127, 95);
        temp0.m1("hi!", (java.lang.Object) 126, 22);
        temp0.m1("", (java.lang.Object) 152, 199);
        temp0.m();
        Temp temp15 = new Temp();
        temp15.m();
        temp15.m1("hi!", (java.lang.Object) 88, 94);
        temp15.m1("hi!", (java.lang.Object) 131, 98);
        temp15.m1("", (java.lang.Object) 13, 103);
        temp15.m1("hi!", (java.lang.Object) 131, 143);
        temp15.m1("hi!", (java.lang.Object) 161, 132);
        temp15.m();
        temp15.m1("", (java.lang.Object) 171, 2);
        Temp temp43 = new Temp();
        temp43.m();
        temp43.m1("hi!", (java.lang.Object) 88, 94);
        temp43.m1("hi!", (java.lang.Object) 131, 98);
        temp43.m1("", (java.lang.Object) 13, 103);
        temp43.m1("hi!", (java.lang.Object) 131, 143);
        temp43.m1("hi!", (java.lang.Object) 161, 132);
        temp15.m1("hi!", (java.lang.Object) temp43, 56);
        temp0.m1("hi!", (java.lang.Object) temp43, 22);
        temp0.m1("hi!", (java.lang.Object) 97, 149);
        java.lang.Class<?> wildcardClass73 = temp0.getClass();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass73);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        Temp temp0 = new Temp();
        temp0.m1("", (java.lang.Object) 127, 95);
        temp0.m1("hi!", (java.lang.Object) 126, 22);
        temp0.m1("", (java.lang.Object) 157, 154);
        ExampleTransformed exampleTransformed14 = new ExampleTransformed();
        temp0.m1("hi!", (java.lang.Object) exampleTransformed14, 10);
        temp0.m();
        temp0.m1("hi!", (java.lang.Object) 256, 51);
        temp0.m1("", (java.lang.Object) 195, 138);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        Temp temp0 = new Temp();
        temp0.m();
        temp0.m1("hi!", (java.lang.Object) 88, 94);
        temp0.m1("hi!", (java.lang.Object) 131, 98);
        temp0.m1("", (java.lang.Object) 13, 103);
        temp0.m1("hi!", (java.lang.Object) 131, 143);
        temp0.m1("", (java.lang.Object) 23, 113);
        CopyClassFile copyClassFile23 = new CopyClassFile();
        java.lang.Class<?> wildcardClass24 = copyClassFile23.getClass();
        temp0.m1("hi!", (java.lang.Object) wildcardClass24, 131);
        temp0.m();
        temp0.m();
        temp0.m();
        temp0.m1("", (java.lang.Object) 181, 98);
        temp0.m();
        java.lang.Class<?> wildcardClass35 = temp0.getClass();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass24);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass35);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        Temp temp0 = new Temp();
        temp0.m();
        temp0.m1("hi!", (java.lang.Object) 88, 94);
        temp0.m1("hi!", (java.lang.Object) 131, 98);
        temp0.m1("", (java.lang.Object) 13, 103);
        temp0.m1("hi!", (java.lang.Object) 131, 143);
        temp0.m1("", (java.lang.Object) 23, 113);
        CopyClassFile copyClassFile23 = new CopyClassFile();
        java.lang.Class<?> wildcardClass24 = copyClassFile23.getClass();
        temp0.m1("hi!", (java.lang.Object) wildcardClass24, 131);
        temp0.m1("", (java.lang.Object) 95, 135);
        Temp temp32 = new Temp();
        temp32.m();
        temp32.m1("hi!", (java.lang.Object) 88, 94);
        temp32.m1("hi!", (java.lang.Object) 131, 98);
        temp32.m1("", (java.lang.Object) 13, 103);
        temp32.m1("hi!", (java.lang.Object) 131, 143);
        temp32.m1("", (java.lang.Object) 23, 113);
        temp0.m1("hi!", (java.lang.Object) "", 152);
        java.lang.Class<?> wildcardClass56 = temp0.getClass();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass24);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass56);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        Temp temp0 = new Temp();
        temp0.m();
        temp0.m1("hi!", (java.lang.Object) 88, 94);
        temp0.m1("hi!", (java.lang.Object) 131, 98);
        temp0.m1("", (java.lang.Object) 13, 103);
        temp0.m1("hi!", (java.lang.Object) 131, 143);
        temp0.m1("", (java.lang.Object) 262144, 158);
        temp0.m();
        temp0.m1("hi!", (java.lang.Object) 11, 11);
        temp0.m();
        Temp temp29 = new Temp();
        temp29.m();
        temp29.m1("hi!", (java.lang.Object) 88, 94);
        temp29.m1("hi!", (java.lang.Object) 131, 98);
        temp29.m1("", (java.lang.Object) 13, 103);
        temp29.m1("hi!", (java.lang.Object) 131, 143);
        temp29.m1("hi!", (java.lang.Object) 161, 132);
        temp29.m();
        temp29.m1("", (java.lang.Object) 171, 2);
        java.lang.Class<?> wildcardClass56 = temp29.getClass();
        temp0.m1("hi!", (java.lang.Object) wildcardClass56, 123);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass56);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        Temp temp0 = new Temp();
        temp0.m1("", (java.lang.Object) 127, 95);
        temp0.m();
        Temp temp7 = new Temp();
        temp7.m();
        temp7.m1("hi!", (java.lang.Object) 88, 94);
        temp7.m1("hi!", (java.lang.Object) 131, 98);
        temp7.m1("", (java.lang.Object) 13, 103);
        temp0.m1("", (java.lang.Object) temp7, 131);
        temp0.m1("", (java.lang.Object) 135, 115);
        temp0.m();
        temp0.m();
        java.lang.Class<?> wildcardClass29 = temp0.getClass();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass29);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        Temp temp0 = new Temp();
        temp0.m1("", (java.lang.Object) 127, 95);
        temp0.m();
        temp0.m1("", (java.lang.Object) 1.0d, 130);
        temp0.m();
        Temp temp12 = new Temp();
        temp12.m1("", (java.lang.Object) 127, 95);
        temp12.m1("hi!", (java.lang.Object) 126, 22);
        temp12.m1("", (java.lang.Object) 157, 154);
        ExampleTransformed exampleTransformed26 = new ExampleTransformed();
        temp12.m1("hi!", (java.lang.Object) exampleTransformed26, 10);
        temp12.m();
        temp12.m1("hi!", (java.lang.Object) 256, 51);
        temp12.m();
        temp12.m1("", (java.lang.Object) 2048, 1);
        temp12.m1("hi!", (java.lang.Object) 14, 128);
        temp0.m1("", (java.lang.Object) temp12, 103);
        java.lang.Class<?> wildcardClass45 = temp12.getClass();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass45);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        Temp temp0 = new Temp();
        temp0.m();
        temp0.m1("hi!", (java.lang.Object) 88, 94);
        temp0.m1("hi!", (java.lang.Object) 131, 98);
        temp0.m1("", (java.lang.Object) 13, 103);
        temp0.m1("hi!", (java.lang.Object) 131, 143);
        temp0.m1("", (java.lang.Object) 23, 113);
        CopyClassFile copyClassFile23 = new CopyClassFile();
        java.lang.Class<?> wildcardClass24 = copyClassFile23.getClass();
        temp0.m1("hi!", (java.lang.Object) wildcardClass24, 131);
        temp0.m();
        temp0.m();
        temp0.m();
        temp0.m1("", (java.lang.Object) 181, 98);
        temp0.m();
        temp0.m();
        java.lang.Class<?> wildcardClass36 = temp0.getClass();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass24);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass36);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        Temp temp0 = new Temp();
        temp0.m();
        temp0.m1("hi!", (java.lang.Object) 88, 94);
        temp0.m1("hi!", (java.lang.Object) 131, 98);
        temp0.m1("", (java.lang.Object) 13, 103);
        temp0.m1("hi!", (java.lang.Object) 131, 143);
        temp0.m1("", (java.lang.Object) 195, 118);
        Temp temp23 = new Temp();
        temp23.m1("", (java.lang.Object) 127, 95);
        temp23.m1("hi!", (java.lang.Object) 126, 22);
        temp23.m1("", (java.lang.Object) 157, 154);
        temp23.m();
        temp23.m();
        temp23.m();
        temp23.m1("hi!", (java.lang.Object) 172, 112);
        temp23.m();
        temp0.m1("", (java.lang.Object) temp23, (-65536));
        temp0.m();
        temp0.m();
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        Temp temp0 = new Temp();
        temp0.m1("", (java.lang.Object) 127, 95);
        temp0.m();
        Example example7 = new Example();
        java.lang.Class<?> wildcardClass8 = example7.getClass();
        temp0.m1("", (java.lang.Object) wildcardClass8, 166);
        temp0.m1("hi!", (java.lang.Object) 180, 198);
        temp0.m();
        java.lang.Class<?> wildcardClass16 = temp0.getClass();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass8);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass16);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        Temp temp0 = new Temp();
        temp0.m();
        temp0.m();
        Temp temp4 = new Temp();
        temp4.m();
        temp4.m1("hi!", (java.lang.Object) 88, 94);
        temp4.m1("hi!", (java.lang.Object) 131, 98);
        temp0.m1("", (java.lang.Object) 131, 5);
        temp0.m1("hi!", (java.lang.Object) 168, 100);
        java.lang.Class<?> wildcardClass20 = temp0.getClass();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass20);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        Temp temp0 = new Temp();
        temp0.m1("", (java.lang.Object) 127, 95);
        temp0.m1("hi!", (java.lang.Object) 126, 22);
        temp0.m1("", (java.lang.Object) 157, 154);
        ExampleTransformed exampleTransformed14 = new ExampleTransformed();
        temp0.m1("hi!", (java.lang.Object) exampleTransformed14, 10);
        temp0.m();
        temp0.m1("hi!", (java.lang.Object) 256, 51);
        temp0.m();
        Temp temp24 = new Temp();
        temp24.m();
        temp24.m1("hi!", (java.lang.Object) 88, 94);
        temp24.m1("hi!", (java.lang.Object) 131, 98);
        temp24.m1("", (java.lang.Object) 13, 103);
        temp24.m1("hi!", (java.lang.Object) 131, 143);
        temp24.m1("", (java.lang.Object) 23, 113);
        CopyClassFile copyClassFile47 = new CopyClassFile();
        java.lang.Class<?> wildcardClass48 = copyClassFile47.getClass();
        temp24.m1("hi!", (java.lang.Object) wildcardClass48, 131);
        java.lang.Class<?> wildcardClass51 = temp24.getClass();
        temp0.m1("hi!", (java.lang.Object) wildcardClass51, 131072);
        Temp temp55 = new Temp();
        temp55.m();
        temp55.m1("hi!", (java.lang.Object) 88, 94);
        temp55.m1("hi!", (java.lang.Object) 131, 98);
        temp55.m1("", (java.lang.Object) 13, 103);
        Temp temp70 = new Temp();
        temp70.m1("", (java.lang.Object) 127, 95);
        temp70.m1("hi!", (java.lang.Object) 126, 22);
        temp70.m1("", (java.lang.Object) 157, 154);
        temp70.m();
        temp70.m1("", (java.lang.Object) 161, 0);
        temp55.m1("hi!", (java.lang.Object) "", 86);
        java.lang.Class<?> wildcardClass90 = temp55.getClass();
        temp0.m1("", (java.lang.Object) wildcardClass90, 14);
        temp0.m1("hi!", (java.lang.Object) 110, 185);
        java.lang.Class<?> wildcardClass97 = temp0.getClass();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass48);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass51);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass90);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass97);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        Temp temp0 = new Temp();
        temp0.m();
        temp0.m1("hi!", (java.lang.Object) 88, 94);
        temp0.m1("hi!", (java.lang.Object) 131, 98);
        temp0.m1("", (java.lang.Object) 13, 103);
        temp0.m1("hi!", (java.lang.Object) 131, 143);
        temp0.m1("", (java.lang.Object) 195, 118);
        Temp temp23 = new Temp();
        temp23.m1("", (java.lang.Object) 127, 95);
        temp23.m1("hi!", (java.lang.Object) 126, 22);
        temp23.m1("", (java.lang.Object) 157, 154);
        temp23.m();
        temp23.m();
        temp23.m();
        temp23.m1("hi!", (java.lang.Object) 172, 112);
        temp23.m();
        temp0.m1("", (java.lang.Object) temp23, (-65536));
        temp0.m();
        java.lang.Class<?> wildcardClass47 = temp0.getClass();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass47);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        Temp temp0 = new Temp();
        temp0.m1("", (java.lang.Object) 127, 95);
        temp0.m();
        Example example7 = new Example();
        java.lang.Class<?> wildcardClass8 = example7.getClass();
        temp0.m1("", (java.lang.Object) wildcardClass8, 166);
        temp0.m1("hi!", (java.lang.Object) 180, 198);
        temp0.m();
        temp0.m();
        java.lang.Class<?> wildcardClass17 = temp0.getClass();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass8);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass17);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        Temp temp0 = new Temp();
        temp0.m1("hi!", (java.lang.Object) (short) 100, 120);
        java.lang.Class<?> wildcardClass5 = temp0.getClass();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass5);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        Temp temp0 = new Temp();
        temp0.m();
        temp0.m1("", (java.lang.Object) 15, 157);
        temp0.m1("hi!", (java.lang.Object) 21, 152);
        temp0.m();
        temp0.m();
        java.lang.Class<?> wildcardClass12 = temp0.getClass();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass12);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        Temp temp0 = new Temp();
        temp0.m1("", (java.lang.Object) 127, 95);
        temp0.m1("hi!", (java.lang.Object) 126, 22);
        temp0.m1("", (java.lang.Object) 157, 154);
        ExampleTransformed exampleTransformed14 = new ExampleTransformed();
        temp0.m1("hi!", (java.lang.Object) exampleTransformed14, 10);
        temp0.m();
        temp0.m1("hi!", (java.lang.Object) 256, 51);
        temp0.m();
        Temp temp24 = new Temp();
        temp24.m();
        temp24.m1("hi!", (java.lang.Object) 88, 94);
        temp24.m1("hi!", (java.lang.Object) 131, 98);
        temp24.m1("", (java.lang.Object) 13, 103);
        temp24.m1("hi!", (java.lang.Object) 131, 143);
        temp24.m1("", (java.lang.Object) 23, 113);
        CopyClassFile copyClassFile47 = new CopyClassFile();
        java.lang.Class<?> wildcardClass48 = copyClassFile47.getClass();
        temp24.m1("hi!", (java.lang.Object) wildcardClass48, 131);
        java.lang.Class<?> wildcardClass51 = temp24.getClass();
        temp0.m1("hi!", (java.lang.Object) wildcardClass51, 131072);
        Temp temp55 = new Temp();
        temp55.m1("", (java.lang.Object) 127, 95);
        temp55.m();
        Temp temp62 = new Temp();
        temp62.m();
        temp62.m1("hi!", (java.lang.Object) 88, 94);
        temp62.m1("hi!", (java.lang.Object) 131, 98);
        temp62.m1("", (java.lang.Object) 13, 103);
        temp55.m1("", (java.lang.Object) temp62, 131);
        temp55.m();
        temp0.m1("", (java.lang.Object) temp55, 100);
        java.lang.Class<?> wildcardClass81 = temp55.getClass();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass48);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass51);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass81);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        Temp temp0 = new Temp();
        temp0.m();
        temp0.m1("hi!", (java.lang.Object) 88, 94);
        temp0.m1("hi!", (java.lang.Object) 131, 98);
        temp0.m1("", (java.lang.Object) 147, (-65536));
        temp0.m1("hi!", (java.lang.Object) 86, 177);
        Temp temp19 = new Temp();
        temp19.m1("", (java.lang.Object) 127, 95);
        temp19.m();
        Temp temp26 = new Temp();
        temp26.m();
        temp26.m1("hi!", (java.lang.Object) 88, 94);
        temp26.m1("hi!", (java.lang.Object) 131, 98);
        temp26.m1("", (java.lang.Object) 13, 103);
        temp19.m1("", (java.lang.Object) temp26, 131);
        temp26.m();
        java.lang.Class<?> wildcardClass43 = temp26.getClass();
        temp0.m1("hi!", (java.lang.Object) temp26, 147);
        temp26.m();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass43);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        Temp temp0 = new Temp();
        temp0.m1("", (java.lang.Object) 127, 95);
        temp0.m();
        temp0.m();
        temp0.m();
        temp0.m1("", (java.lang.Object) 176, (int) '#');
        temp0.m();
        Temp temp14 = new Temp();
        temp14.m1("", (java.lang.Object) 127, 95);
        temp14.m();
        temp14.m();
        temp14.m();
        Temp temp23 = new Temp();
        temp23.m1("", (java.lang.Object) 127, 95);
        temp23.m();
        temp23.m();
        temp23.m();
        temp14.m1("", (java.lang.Object) temp23, 186);
        temp0.m1("", (java.lang.Object) 186, 199);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        Temp temp0 = new Temp();
        temp0.m();
        temp0.m1("hi!", (java.lang.Object) 88, 94);
        temp0.m1("hi!", (java.lang.Object) 131, 98);
        temp0.m1("", (java.lang.Object) 13, 103);
        temp0.m1("hi!", (java.lang.Object) 131, 143);
        temp0.m1("hi!", (java.lang.Object) 161, 132);
        temp0.m();
        temp0.m1("", (java.lang.Object) 171, 2);
        temp0.m();
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        Temp temp0 = new Temp();
        temp0.m();
        temp0.m1("", (java.lang.Object) 15, 141);
        Temp temp7 = new Temp();
        temp7.m();
        temp7.m1("hi!", (java.lang.Object) 88, 94);
        temp7.m1("hi!", (java.lang.Object) 131, 98);
        temp7.m1("", (java.lang.Object) 13, 103);
        temp7.m1("hi!", (java.lang.Object) 131, 143);
        temp7.m1("", (java.lang.Object) 262144, 158);
        temp7.m();
        temp7.m1("hi!", (java.lang.Object) 161, 85);
        java.lang.Class<?> wildcardClass34 = temp7.getClass();
        temp0.m1("", (java.lang.Object) wildcardClass34, 184);
        Temp temp38 = new Temp();
        temp38.m();
        temp38.m1("", (java.lang.Object) 15, 141);
        temp38.m1("", (java.lang.Object) 128, (int) (short) 100);
        temp38.m();
        temp0.m1("", (java.lang.Object) temp38, 121);
        java.lang.Class<?> wildcardClass51 = temp38.getClass();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass34);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass51);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        Temp temp0 = new Temp();
        temp0.m();
        temp0.m1("hi!", (java.lang.Object) 88, 94);
        temp0.m1("hi!", (java.lang.Object) 131, 98);
        temp0.m1("", (java.lang.Object) 13, 103);
        temp0.m1("hi!", (java.lang.Object) 131, 143);
        temp0.m1("", (java.lang.Object) 262144, 158);
        temp0.m();
        temp0.m1("hi!", (java.lang.Object) 11, 11);
        temp0.m1("hi!", (java.lang.Object) 116, 32768);
        temp0.m();
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        Temp temp0 = new Temp();
        temp0.m();
        temp0.m1("hi!", (java.lang.Object) 88, 94);
        temp0.m1("hi!", (java.lang.Object) 131, 98);
        temp0.m1("", (java.lang.Object) 13, 103);
        temp0.m1("hi!", (java.lang.Object) 131, 143);
        temp0.m1("", (java.lang.Object) 195, 118);
        Temp temp23 = new Temp();
        temp23.m();
        temp23.m1("hi!", (java.lang.Object) 88, 94);
        temp23.m1("hi!", (java.lang.Object) 131, 98);
        temp23.m1("", (java.lang.Object) 13, 103);
        temp23.m1("hi!", (java.lang.Object) 131, 143);
        temp23.m1("", (java.lang.Object) 23, 113);
        CopyClassFile copyClassFile46 = new CopyClassFile();
        java.lang.Class<?> wildcardClass47 = copyClassFile46.getClass();
        temp23.m1("hi!", (java.lang.Object) wildcardClass47, 131);
        temp23.m();
        temp23.m1("", (java.lang.Object) 121, (int) (byte) 10);
        temp0.m1("hi!", (java.lang.Object) temp23, 11);
        java.lang.Class<?> wildcardClass57 = temp0.getClass();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass47);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass57);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        Temp temp0 = new Temp();
        temp0.m1("", (java.lang.Object) 127, 95);
        temp0.m();
        Example example7 = new Example();
        java.lang.Class<?> wildcardClass8 = example7.getClass();
        temp0.m1("", (java.lang.Object) wildcardClass8, 166);
        temp0.m1("hi!", (java.lang.Object) 180, 198);
        java.lang.Class<?> wildcardClass15 = temp0.getClass();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass8);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass15);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        Temp temp0 = new Temp();
        temp0.m1("", (java.lang.Object) 127, 95);
        temp0.m();
        temp0.m1("", (java.lang.Object) 1.0d, 130);
        Temp temp11 = new Temp();
        temp11.m();
        temp11.m1("hi!", (java.lang.Object) 88, 94);
        temp11.m1("hi!", (java.lang.Object) 131, 98);
        temp11.m1("", (java.lang.Object) 13, 103);
        temp11.m1("hi!", (java.lang.Object) 131, 143);
        temp11.m1("", (java.lang.Object) 262144, 158);
        temp11.m();
        temp11.m1("hi!", (java.lang.Object) 11, 11);
        temp0.m1("", (java.lang.Object) temp11, 133);
        java.lang.Class<?> wildcardClass40 = temp0.getClass();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass40);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        Temp temp0 = new Temp();
        temp0.m1("", (java.lang.Object) 127, 95);
        temp0.m1("hi!", (java.lang.Object) 87, 179);
        temp0.m();
        Temp temp11 = new Temp();
        temp11.m1("", (java.lang.Object) 127, 95);
        temp11.m();
        Temp temp18 = new Temp();
        temp18.m();
        temp18.m1("hi!", (java.lang.Object) 88, 94);
        temp18.m1("hi!", (java.lang.Object) 131, 98);
        temp18.m1("", (java.lang.Object) 13, 103);
        temp11.m1("", (java.lang.Object) temp18, 131);
        temp11.m1("", (java.lang.Object) 176, 183);
        temp11.m();
        temp0.m1("hi!", (java.lang.Object) temp11, 64);
        java.lang.Class<?> wildcardClass41 = temp11.getClass();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass41);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        Temp temp0 = new Temp();
        temp0.m1("", (java.lang.Object) 127, 95);
        temp0.m();
        temp0.m1("", (java.lang.Object) 1.0d, 130);
        temp0.m();
        Temp temp12 = new Temp();
        temp12.m1("", (java.lang.Object) 127, 95);
        temp12.m1("hi!", (java.lang.Object) 126, 22);
        temp12.m1("", (java.lang.Object) 157, 154);
        ExampleTransformed exampleTransformed26 = new ExampleTransformed();
        temp12.m1("hi!", (java.lang.Object) exampleTransformed26, 10);
        temp12.m();
        temp12.m1("hi!", (java.lang.Object) 256, 51);
        temp12.m();
        temp12.m1("", (java.lang.Object) 2048, 1);
        temp12.m1("hi!", (java.lang.Object) 14, 128);
        temp0.m1("", (java.lang.Object) temp12, 103);
        java.lang.Class<?> wildcardClass45 = temp0.getClass();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass45);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        Temp temp0 = new Temp();
        temp0.m1("", (java.lang.Object) 127, 95);
        temp0.m1("hi!", (java.lang.Object) 126, 22);
        temp0.m1("", (java.lang.Object) 157, 154);
        ExampleTransformed exampleTransformed14 = new ExampleTransformed();
        temp0.m1("hi!", (java.lang.Object) exampleTransformed14, 10);
        temp0.m();
        temp0.m1("hi!", (java.lang.Object) 256, 51);
        temp0.m();
        temp0.m1("", (java.lang.Object) 2048, 1);
        temp0.m();
        temp0.m();
        java.lang.Class<?> wildcardClass29 = temp0.getClass();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass29);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        Temp temp0 = new Temp();
        temp0.m1("", (java.lang.Object) 127, 95);
        temp0.m();
        Temp temp7 = new Temp();
        temp7.m();
        temp7.m1("hi!", (java.lang.Object) 88, 94);
        temp7.m1("hi!", (java.lang.Object) 131, 98);
        temp7.m1("", (java.lang.Object) 13, 103);
        temp0.m1("", (java.lang.Object) temp7, 131);
        temp0.m1("", (java.lang.Object) 176, 183);
        Temp temp28 = new Temp();
        temp28.m1("", (java.lang.Object) 127, 95);
        temp28.m1("hi!", (java.lang.Object) 126, 22);
        temp28.m1("", (java.lang.Object) 157, 154);
        temp28.m();
        temp28.m();
        temp28.m();
        temp28.m1("hi!", (java.lang.Object) 172, 112);
        temp28.m();
        temp0.m1("hi!", (java.lang.Object) temp28, 15);
        temp28.m();
        java.lang.Class<?> wildcardClass52 = temp28.getClass();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass52);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        Temp temp0 = new Temp();
        temp0.m1("", (java.lang.Object) 127, 95);
        temp0.m();
        temp0.m();
        temp0.m1("", (java.lang.Object) 81, 139);
        Temp temp12 = new Temp();
        temp12.m1("", (java.lang.Object) 127, 95);
        temp12.m();
        Temp temp19 = new Temp();
        temp19.m1("", (java.lang.Object) 127, 95);
        temp19.m1("hi!", (java.lang.Object) 126, 22);
        temp19.m1("", (java.lang.Object) 157, 154);
        temp19.m();
        temp19.m1("hi!", (java.lang.Object) 10.0d, 124);
        temp12.m1("", (java.lang.Object) 124, (int) (byte) -1);
        java.lang.Class<?> wildcardClass39 = temp12.getClass();
        temp0.m1("hi!", (java.lang.Object) temp12, (int) (byte) -1);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass39);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        Temp temp0 = new Temp();
        temp0.m1("", (java.lang.Object) 127, 95);
        temp0.m();
        temp0.m();
        temp0.m();
        temp0.m();
        java.lang.Class<?> wildcardClass9 = temp0.getClass();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass9);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        Temp temp0 = new Temp();
        temp0.m();
        temp0.m1("hi!", (java.lang.Object) 88, 94);
        temp0.m1("hi!", (java.lang.Object) 131, 98);
        temp0.m1("", (java.lang.Object) 13, 103);
        temp0.m1("hi!", (java.lang.Object) 131, 143);
        temp0.m1("hi!", (java.lang.Object) 161, 132);
        temp0.m();
        temp0.m1("", (java.lang.Object) 171, 2);
        Temp temp28 = new Temp();
        temp28.m();
        temp28.m1("hi!", (java.lang.Object) 88, 94);
        temp28.m1("hi!", (java.lang.Object) 131, 98);
        temp28.m1("", (java.lang.Object) 13, 103);
        temp28.m1("hi!", (java.lang.Object) 131, 143);
        temp28.m1("hi!", (java.lang.Object) 161, 132);
        temp0.m1("hi!", (java.lang.Object) temp28, 56);
        Temp temp53 = new Temp();
        temp53.m();
        temp53.m1("hi!", (java.lang.Object) 88, 94);
        temp53.m1("hi!", (java.lang.Object) 131, 98);
        temp53.m1("", (java.lang.Object) 13, 103);
        temp53.m1("hi!", (java.lang.Object) 131, 143);
        temp53.m1("", (java.lang.Object) 195, 118);
        temp53.m1("", (java.lang.Object) 96, 88);
        temp28.m1("", (java.lang.Object) temp53, 143);
        java.lang.Class<?> wildcardClass81 = temp53.getClass();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass81);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        Temp temp0 = new Temp();
        temp0.m();
        temp0.m1("", (java.lang.Object) 15, 157);
        temp0.m1("", (java.lang.Object) "hi!", 181);
        java.lang.Class<?> wildcardClass10 = temp0.getClass();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass10);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        Temp temp0 = new Temp();
        temp0.m();
        temp0.m1("", (java.lang.Object) 15, 141);
        temp0.m();
        temp0.m();
        Temp temp9 = new Temp();
        temp9.m();
        temp9.m1("hi!", (java.lang.Object) 88, 94);
        temp9.m1("hi!", (java.lang.Object) 131, 98);
        temp9.m1("", (java.lang.Object) 13, 103);
        temp9.m1("hi!", (java.lang.Object) 131, 143);
        temp9.m1("", (java.lang.Object) 23, 113);
        java.lang.Object obj32 = null;
        temp9.m1("hi!", obj32, 58);
        temp9.m();
        temp0.m1("", (java.lang.Object) temp9, 139);
        temp0.m1("hi!", (java.lang.Object) 48, 256);
        Temp temp43 = new Temp();
        temp43.m1("", (java.lang.Object) 127, 95);
        temp43.m();
        temp0.m1("", (java.lang.Object) temp43, 102);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        Temp temp0 = new Temp();
        temp0.m1("", (java.lang.Object) 127, 95);
        temp0.m1("hi!", (java.lang.Object) 126, 22);
        temp0.m1("hi!", (java.lang.Object) 85, 174);
        temp0.m();
        java.lang.Class<?> wildcardClass14 = temp0.getClass();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass14);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        Temp temp0 = new Temp();
        temp0.m1("", (java.lang.Object) 127, 95);
        temp0.m1("hi!", (java.lang.Object) 126, 22);
        temp0.m1("", (java.lang.Object) 152, 199);
        temp0.m();
        Temp temp15 = new Temp();
        temp15.m();
        temp15.m1("hi!", (java.lang.Object) 88, 94);
        temp15.m1("hi!", (java.lang.Object) 131, 98);
        temp15.m1("", (java.lang.Object) 13, 103);
        temp15.m1("hi!", (java.lang.Object) 131, 143);
        temp15.m1("hi!", (java.lang.Object) 161, 132);
        temp15.m();
        temp15.m1("", (java.lang.Object) 171, 2);
        Temp temp43 = new Temp();
        temp43.m();
        temp43.m1("hi!", (java.lang.Object) 88, 94);
        temp43.m1("hi!", (java.lang.Object) 131, 98);
        temp43.m1("", (java.lang.Object) 13, 103);
        temp43.m1("hi!", (java.lang.Object) 131, 143);
        temp43.m1("hi!", (java.lang.Object) 161, 132);
        temp15.m1("hi!", (java.lang.Object) temp43, 56);
        temp0.m1("hi!", (java.lang.Object) temp43, 22);
        temp0.m1("hi!", (java.lang.Object) 97, 149);
        Temp temp74 = new Temp();
        temp74.m();
        temp74.m1("hi!", (java.lang.Object) 88, 94);
        temp74.m1("hi!", (java.lang.Object) 131, 98);
        temp74.m1("", (java.lang.Object) 13, 103);
        temp74.m1("hi!", (java.lang.Object) 131, 143);
        temp74.m1("hi!", (java.lang.Object) 161, 132);
        temp74.m();
        java.lang.Class<?> wildcardClass97 = temp74.getClass();
        temp0.m1("hi!", (java.lang.Object) wildcardClass97, 141);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass97);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        Temp temp0 = new Temp();
        temp0.m();
        temp0.m1("hi!", (java.lang.Object) 88, 94);
        temp0.m();
        temp0.m1("hi!", (java.lang.Object) 187, 0);
        temp0.m();
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        Temp temp0 = new Temp();
        temp0.m1("", (java.lang.Object) 127, 95);
        temp0.m();
        temp0.m1("", (java.lang.Object) 1.0d, 130);
        temp0.m1("hi!", (java.lang.Object) 129, 118);
        java.lang.Class<?> wildcardClass14 = temp0.getClass();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass14);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        Temp temp0 = new Temp();
        temp0.m();
        temp0.m1("", (java.lang.Object) 15, 157);
        temp0.m1("hi!", (java.lang.Object) 21, 152);
        temp0.m();
        temp0.m1("hi!", (java.lang.Object) 32, 104);
        Temp temp16 = new Temp();
        temp16.m();
        temp16.m1("hi!", (java.lang.Object) 88, 94);
        temp16.m1("hi!", (java.lang.Object) 131, 98);
        temp16.m1("", (java.lang.Object) 147, (-65536));
        temp16.m1("hi!", (java.lang.Object) 86, 177);
        Temp temp35 = new Temp();
        temp35.m();
        java.lang.Class<?> wildcardClass37 = temp35.getClass();
        temp16.m1("", (java.lang.Object) wildcardClass37, 184);
        temp0.m1("", (java.lang.Object) wildcardClass37, 2);
        temp0.m();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass37);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        Temp temp0 = new Temp();
        temp0.m();
        temp0.m1("hi!", (java.lang.Object) 88, 94);
        temp0.m1("hi!", (java.lang.Object) 131, 98);
        temp0.m1("", (java.lang.Object) 13, 103);
        temp0.m1("hi!", (java.lang.Object) 131, 143);
        temp0.m1("", (java.lang.Object) 195, 118);
        Temp temp23 = new Temp();
        temp23.m();
        temp23.m1("hi!", (java.lang.Object) 88, 94);
        temp23.m1("hi!", (java.lang.Object) 131, 98);
        temp23.m1("", (java.lang.Object) 13, 103);
        temp23.m1("hi!", (java.lang.Object) 131, 143);
        temp23.m1("", (java.lang.Object) 23, 113);
        CopyClassFile copyClassFile46 = new CopyClassFile();
        java.lang.Class<?> wildcardClass47 = copyClassFile46.getClass();
        temp23.m1("hi!", (java.lang.Object) wildcardClass47, 131);
        temp23.m();
        temp23.m1("", (java.lang.Object) 121, (int) (byte) 10);
        temp0.m1("hi!", (java.lang.Object) temp23, 11);
        temp23.m1("hi!", (java.lang.Object) 181, 7);
        java.lang.Class<?> wildcardClass61 = temp23.getClass();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass47);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass61);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        Temp temp0 = new Temp();
        temp0.m1("", (java.lang.Object) 127, 95);
        temp0.m1("hi!", (java.lang.Object) 126, 22);
        temp0.m();
        java.lang.Class<?> wildcardClass10 = temp0.getClass();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass10);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        Temp temp0 = new Temp();
        temp0.m1("", (java.lang.Object) 127, 95);
        Temp temp6 = new Temp();
        temp6.m1("", (java.lang.Object) 127, 95);
        temp6.m1("hi!", (java.lang.Object) 126, 22);
        temp6.m1("hi!", (java.lang.Object) 85, 174);
        temp0.m1("hi!", (java.lang.Object) "hi!", 142);
        java.lang.Class<?> wildcardClass21 = temp0.getClass();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass21);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        Temp temp0 = new Temp();
        temp0.m();
        temp0.m1("hi!", (java.lang.Object) 88, 94);
        temp0.m1("hi!", (java.lang.Object) 131, 98);
        temp0.m1("", (java.lang.Object) 13, 103);
        temp0.m1("hi!", (java.lang.Object) 131, 143);
        temp0.m1("", (java.lang.Object) 23, 113);
        CopyClassFile copyClassFile23 = new CopyClassFile();
        java.lang.Class<?> wildcardClass24 = copyClassFile23.getClass();
        temp0.m1("hi!", (java.lang.Object) wildcardClass24, 131);
        temp0.m1("", (java.lang.Object) 95, 135);
        Temp temp32 = new Temp();
        temp32.m();
        temp32.m1("hi!", (java.lang.Object) 88, 94);
        temp32.m1("hi!", (java.lang.Object) 131, 98);
        temp32.m1("", (java.lang.Object) 13, 103);
        temp32.m1("hi!", (java.lang.Object) 131, 143);
        temp32.m1("", (java.lang.Object) 23, 113);
        temp0.m1("hi!", (java.lang.Object) "", 152);
        temp0.m();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass24);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        Temp temp0 = new Temp();
        temp0.m1("", (java.lang.Object) 127, 95);
        temp0.m();
        temp0.m1("", (java.lang.Object) 1.0d, 130);
        temp0.m();
        Temp temp12 = new Temp();
        temp12.m1("", (java.lang.Object) 127, 95);
        temp12.m1("hi!", (java.lang.Object) 126, 22);
        temp12.m1("", (java.lang.Object) 157, 154);
        ExampleTransformed exampleTransformed26 = new ExampleTransformed();
        temp12.m1("hi!", (java.lang.Object) exampleTransformed26, 10);
        temp12.m();
        temp12.m1("hi!", (java.lang.Object) 256, 51);
        temp12.m();
        temp12.m1("", (java.lang.Object) 2048, 1);
        temp12.m1("hi!", (java.lang.Object) 14, 128);
        temp0.m1("", (java.lang.Object) temp12, 103);
        temp0.m();
        temp0.m();
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        Temp temp0 = new Temp();
        temp0.m();
        temp0.m1("hi!", (java.lang.Object) 88, 94);
        temp0.m1("hi!", (java.lang.Object) 131, 98);
        temp0.m1("", (java.lang.Object) 13, 103);
        temp0.m1("hi!", (java.lang.Object) 131, 143);
        temp0.m1("", (java.lang.Object) 195, 118);
        Temp temp23 = new Temp();
        temp23.m1("", (java.lang.Object) 127, 95);
        temp23.m1("hi!", (java.lang.Object) 126, 22);
        temp23.m1("", (java.lang.Object) 157, 154);
        temp23.m();
        temp23.m();
        temp23.m();
        temp23.m1("hi!", (java.lang.Object) 172, 112);
        temp23.m();
        temp0.m1("", (java.lang.Object) temp23, (-65536));
        temp0.m();
        temp0.m1("", (java.lang.Object) 32, 110);
        java.lang.Object obj52 = null;
        temp0.m1("", obj52, 142);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        Temp temp0 = new Temp();
        temp0.m();
        temp0.m1("hi!", (java.lang.Object) 88, 94);
        temp0.m1("hi!", (java.lang.Object) 131, 98);
        temp0.m1("", (java.lang.Object) 13, 103);
        temp0.m1("hi!", (java.lang.Object) 131, 143);
        temp0.m1("hi!", (java.lang.Object) 161, 132);
        temp0.m1("", (java.lang.Object) 130, 193);
        java.lang.Class<?> wildcardClass26 = temp0.getClass();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass26);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        Temp temp0 = new Temp();
        temp0.m1("", (java.lang.Object) 127, 95);
        temp0.m1("hi!", (java.lang.Object) 126, 22);
        temp0.m1("", (java.lang.Object) 152, 199);
        Temp temp14 = new Temp();
        temp14.m1("", (java.lang.Object) 127, 95);
        temp14.m();
        Temp temp21 = new Temp();
        temp21.m();
        temp21.m1("hi!", (java.lang.Object) 88, 94);
        temp21.m1("hi!", (java.lang.Object) 131, 98);
        temp21.m1("", (java.lang.Object) 13, 103);
        temp14.m1("", (java.lang.Object) temp21, 131);
        temp21.m();
        temp0.m1("hi!", (java.lang.Object) temp21, 137);
        java.lang.Class<?> wildcardClass40 = temp21.getClass();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass40);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        Temp temp0 = new Temp();
        temp0.m();
        temp0.m1("hi!", (java.lang.Object) 88, 94);
        temp0.m1("hi!", (java.lang.Object) 131, 98);
        temp0.m1("", (java.lang.Object) 13, 103);
        temp0.m1("hi!", (java.lang.Object) 131, 143);
        temp0.m1("", (java.lang.Object) 195, 118);
        temp0.m1("", (java.lang.Object) 96, 88);
        temp0.m();
        temp0.m1("", (java.lang.Object) 46, 262144);
        temp0.m();
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        Temp temp0 = new Temp();
        temp0.m();
        temp0.m1("hi!", (java.lang.Object) 88, 94);
        temp0.m1("hi!", (java.lang.Object) 131, 98);
        temp0.m1("", (java.lang.Object) 13, 103);
        Temp temp15 = new Temp();
        temp15.m1("", (java.lang.Object) 127, 95);
        temp15.m1("hi!", (java.lang.Object) 126, 22);
        temp15.m1("", (java.lang.Object) 157, 154);
        temp15.m();
        temp15.m1("", (java.lang.Object) 161, 0);
        temp0.m1("hi!", (java.lang.Object) "", 86);
        java.lang.Object obj36 = null;
        temp0.m1("hi!", obj36, 91);
        Temp temp40 = new Temp();
        temp40.m();
        temp40.m1("hi!", (java.lang.Object) 88, 94);
        temp40.m1("hi!", (java.lang.Object) 131, 98);
        temp40.m1("", (java.lang.Object) 147, (-65536));
        temp40.m1("hi!", (java.lang.Object) 12, 181);
        temp40.m();
        temp0.m1("", (java.lang.Object) temp40, 150);
        java.lang.Class<?> wildcardClass61 = temp40.getClass();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass61);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        Temp temp0 = new Temp();
        temp0.m();
        temp0.m1("hi!", (java.lang.Object) 88, 94);
        temp0.m1("hi!", (java.lang.Object) 131, 98);
        temp0.m1("", (java.lang.Object) 13, 103);
        Temp temp15 = new Temp();
        temp15.m1("", (java.lang.Object) 127, 95);
        temp15.m1("hi!", (java.lang.Object) 126, 22);
        temp15.m1("", (java.lang.Object) 157, 154);
        temp15.m();
        temp15.m1("", (java.lang.Object) 161, 0);
        temp0.m1("hi!", (java.lang.Object) "", 86);
        java.lang.Object obj36 = null;
        temp0.m1("hi!", obj36, 91);
        temp0.m1("", (java.lang.Object) 458752, 195);
        Temp temp44 = new Temp();
        temp44.m1("", (java.lang.Object) 127, 95);
        temp44.m();
        Example example51 = new Example();
        java.lang.Class<?> wildcardClass52 = example51.getClass();
        temp44.m1("", (java.lang.Object) wildcardClass52, 166);
        temp0.m1("hi!", (java.lang.Object) wildcardClass52, 11);
        java.lang.Class<?> wildcardClass57 = temp0.getClass();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass52);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass57);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        Temp temp0 = new Temp();
        temp0.m1("", (java.lang.Object) 127, 95);
        temp0.m1("hi!", (java.lang.Object) 126, 22);
        temp0.m1("", (java.lang.Object) 157, 154);
        ExampleTransformed exampleTransformed14 = new ExampleTransformed();
        temp0.m1("hi!", (java.lang.Object) exampleTransformed14, 10);
        temp0.m();
        temp0.m1("hi!", (java.lang.Object) 256, 51);
        temp0.m();
        temp0.m();
        java.lang.Class<?> wildcardClass24 = temp0.getClass();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass24);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        Temp temp0 = new Temp();
        temp0.m1("hi!", (java.lang.Object) (short) 100, 120);
        temp0.m1("", (java.lang.Object) 172, 32768);
        temp0.m();
        java.lang.Class<?> wildcardClass10 = temp0.getClass();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass10);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        Temp temp0 = new Temp();
        temp0.m1("", (java.lang.Object) 127, 95);
        temp0.m();
        Temp temp7 = new Temp();
        temp7.m();
        temp7.m1("hi!", (java.lang.Object) 88, 94);
        temp7.m1("hi!", (java.lang.Object) 131, 98);
        temp7.m1("", (java.lang.Object) 13, 103);
        temp0.m1("", (java.lang.Object) temp7, 131);
        temp7.m();
        Temp temp25 = new Temp();
        temp25.m();
        temp25.m1("hi!", (java.lang.Object) 88, 94);
        temp25.m1("hi!", (java.lang.Object) 131, 98);
        temp25.m1("", (java.lang.Object) 147, (-65536));
        temp25.m1("hi!", (java.lang.Object) 86, 177);
        Temp temp44 = new Temp();
        temp44.m();
        java.lang.Class<?> wildcardClass46 = temp44.getClass();
        temp25.m1("", (java.lang.Object) wildcardClass46, 184);
        java.lang.Class<?> wildcardClass49 = temp25.getClass();
        temp7.m1("", (java.lang.Object) wildcardClass49, 108);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass46);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass49);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        Temp temp0 = new Temp();
        temp0.m();
        temp0.m1("", (java.lang.Object) 15, 141);
        temp0.m();
        temp0.m1("hi!", (java.lang.Object) 109, 160);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        Temp temp0 = new Temp();
        temp0.m();
        temp0.m1("hi!", (java.lang.Object) 88, 94);
        temp0.m1("hi!", (java.lang.Object) 131, 98);
        temp0.m1("", (java.lang.Object) 13, 103);
        temp0.m();
        temp0.m();
        temp0.m();
        temp0.m1("hi!", (java.lang.Object) 262144, 84);
        temp0.m1("hi!", (java.lang.Object) 141, 103);
        temp0.m();
        temp0.m();
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        Temp temp0 = new Temp();
        Temp temp2 = new Temp();
        temp2.m1("", (java.lang.Object) 127, 95);
        temp2.m1("hi!", (java.lang.Object) 126, 22);
        temp2.m1("", (java.lang.Object) 157, 154);
        ExampleTransformed exampleTransformed16 = new ExampleTransformed();
        temp2.m1("hi!", (java.lang.Object) exampleTransformed16, 10);
        temp2.m();
        temp2.m1("hi!", (java.lang.Object) 256, 51);
        temp2.m();
        temp2.m1("", (java.lang.Object) 2048, 1);
        temp2.m1("hi!", (java.lang.Object) 14, 128);
        temp2.m1("", (java.lang.Object) 146, 118);
        Temp temp38 = new Temp();
        temp38.m();
        temp38.m1("hi!", (java.lang.Object) 88, 94);
        temp38.m();
        temp2.m1("", (java.lang.Object) temp38, 84);
        temp38.m();
        temp0.m1("hi!", (java.lang.Object) temp38, 131);
        temp0.m();
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        Temp temp0 = new Temp();
        temp0.m1("", (java.lang.Object) 127, 95);
        temp0.m1("hi!", (java.lang.Object) 126, 22);
        temp0.m1("", (java.lang.Object) 157, 154);
        ExampleTransformed exampleTransformed14 = new ExampleTransformed();
        temp0.m1("hi!", (java.lang.Object) exampleTransformed14, 10);
        temp0.m1("", (java.lang.Object) 82, 105);
        temp0.m();
        temp0.m();
        java.lang.Class<?> wildcardClass23 = temp0.getClass();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass23);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        Temp temp0 = new Temp();
        temp0.m1("", (java.lang.Object) 127, 95);
        temp0.m1("hi!", (java.lang.Object) 126, 22);
        temp0.m1("", (java.lang.Object) 157, 154);
        ExampleTransformed exampleTransformed14 = new ExampleTransformed();
        temp0.m1("hi!", (java.lang.Object) exampleTransformed14, 10);
        temp0.m();
        temp0.m();
        Temp temp20 = new Temp();
        temp20.m();
        temp20.m1("hi!", (java.lang.Object) 88, 94);
        temp20.m1("hi!", (java.lang.Object) 131, 98);
        temp20.m1("", (java.lang.Object) 13, 103);
        java.lang.Class<?> wildcardClass34 = temp20.getClass();
        temp0.m1("hi!", (java.lang.Object) temp20, 137);
        temp0.m();
        Temp temp39 = new Temp();
        temp39.m1("", (java.lang.Object) 127, 95);
        temp39.m1("hi!", (java.lang.Object) 126, 22);
        temp39.m1("", (java.lang.Object) 157, 154);
        ExampleTransformed exampleTransformed53 = new ExampleTransformed();
        temp39.m1("hi!", (java.lang.Object) exampleTransformed53, 10);
        temp39.m();
        temp39.m1("hi!", (java.lang.Object) 256, 51);
        temp39.m();
        java.lang.Class<?> wildcardClass62 = temp39.getClass();
        temp0.m1("hi!", (java.lang.Object) temp39, 89);
        java.lang.Class<?> wildcardClass65 = temp39.getClass();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass34);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass62);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass65);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        Temp temp0 = new Temp();
        temp0.m();
        temp0.m1("hi!", (java.lang.Object) 88, 94);
        temp0.m1("hi!", (java.lang.Object) 131, 98);
        temp0.m1("", (java.lang.Object) 13, 103);
        temp0.m1("hi!", (java.lang.Object) 131, 143);
        temp0.m1("", (java.lang.Object) 23, 113);
        CopyClassFile copyClassFile23 = new CopyClassFile();
        java.lang.Class<?> wildcardClass24 = copyClassFile23.getClass();
        temp0.m1("hi!", (java.lang.Object) wildcardClass24, 131);
        temp0.m();
        temp0.m();
        temp0.m();
        temp0.m1("", (java.lang.Object) 181, 98);
        temp0.m();
        temp0.m();
        Temp temp37 = new Temp();
        temp37.m();
        temp37.m();
        Temp temp41 = new Temp();
        temp41.m();
        temp41.m1("hi!", (java.lang.Object) 88, 94);
        temp41.m1("hi!", (java.lang.Object) 131, 98);
        temp37.m1("", (java.lang.Object) 131, 5);
        temp0.m1("", (java.lang.Object) temp37, 182);
        temp37.m();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass24);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        Temp temp0 = new Temp();
        temp0.m1("", (java.lang.Object) 127, 95);
        temp0.m();
        Temp temp7 = new Temp();
        temp7.m();
        temp7.m1("hi!", (java.lang.Object) 88, 94);
        temp7.m1("hi!", (java.lang.Object) 131, 98);
        temp7.m1("", (java.lang.Object) 13, 103);
        temp0.m1("", (java.lang.Object) temp7, 131);
        temp0.m1("", (java.lang.Object) 176, 183);
        Temp temp28 = new Temp();
        temp28.m1("", (java.lang.Object) 127, 95);
        temp28.m1("hi!", (java.lang.Object) 126, 22);
        temp28.m1("", (java.lang.Object) 157, 154);
        temp28.m();
        temp28.m();
        temp28.m();
        temp28.m1("hi!", (java.lang.Object) 172, 112);
        temp28.m();
        temp0.m1("hi!", (java.lang.Object) temp28, 15);
        temp28.m();
        Temp temp53 = new Temp();
        temp53.m();
        temp53.m1("hi!", (java.lang.Object) 88, 94);
        temp53.m1("hi!", (java.lang.Object) 131, 98);
        temp53.m1("", (java.lang.Object) 13, 103);
        temp53.m1("hi!", (java.lang.Object) 131, 143);
        temp53.m1("", (java.lang.Object) 195, 118);
        temp28.m1("hi!", (java.lang.Object) 195, 8);
        java.lang.Class<?> wildcardClass77 = temp28.getClass();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass77);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        Temp temp0 = new Temp();
        temp0.m();
        temp0.m1("hi!", (java.lang.Object) 88, 94);
        temp0.m1("hi!", (java.lang.Object) 131, 98);
        temp0.m1("", (java.lang.Object) 13, 103);
        temp0.m1("hi!", (java.lang.Object) 131, 143);
        temp0.m1("hi!", (java.lang.Object) 161, 132);
        temp0.m();
        temp0.m1("", (java.lang.Object) 171, 2);
        Temp temp28 = new Temp();
        temp28.m();
        temp28.m1("hi!", (java.lang.Object) 88, 94);
        temp28.m1("hi!", (java.lang.Object) 131, 98);
        temp28.m1("", (java.lang.Object) 147, (-65536));
        temp28.m1("hi!", (java.lang.Object) 12, 181);
        temp28.m();
        temp0.m1("hi!", (java.lang.Object) temp28, 64);
        temp28.m();
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        Temp temp0 = new Temp();
        temp0.m();
        temp0.m1("hi!", (java.lang.Object) 88, 94);
        temp0.m1("hi!", (java.lang.Object) 131, 98);
        temp0.m1("", (java.lang.Object) 13, 103);
        temp0.m1("hi!", (java.lang.Object) 131, 143);
        temp0.m1("", (java.lang.Object) 23, 113);
        CopyClassFile copyClassFile23 = new CopyClassFile();
        java.lang.Class<?> wildcardClass24 = copyClassFile23.getClass();
        temp0.m1("hi!", (java.lang.Object) wildcardClass24, 131);
        temp0.m1("", (java.lang.Object) 95, 135);
        Temp temp32 = new Temp();
        temp32.m();
        temp32.m1("hi!", (java.lang.Object) 88, 94);
        temp32.m1("hi!", (java.lang.Object) 131, 98);
        temp32.m1("", (java.lang.Object) 13, 103);
        temp32.m1("hi!", (java.lang.Object) 131, 143);
        temp32.m1("", (java.lang.Object) 23, 113);
        temp0.m1("hi!", (java.lang.Object) "", 152);
        temp0.m1("", (java.lang.Object) 81, 51);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass24);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        Temp temp0 = new Temp();
        temp0.m1("", (java.lang.Object) 127, 95);
        temp0.m();
        Temp temp7 = new Temp();
        temp7.m();
        temp7.m1("hi!", (java.lang.Object) 88, 94);
        temp7.m1("hi!", (java.lang.Object) 131, 98);
        temp7.m1("", (java.lang.Object) 13, 103);
        temp0.m1("", (java.lang.Object) temp7, 131);
        temp0.m1("", (java.lang.Object) 176, 183);
        temp0.m1("hi!", (java.lang.Object) 104, 171);
        temp0.m1("hi!", (java.lang.Object) 153, 199);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        Temp temp0 = new Temp();
        temp0.m1("", (java.lang.Object) 127, 95);
        temp0.m();
        temp0.m();
        temp0.m();
        Temp temp9 = new Temp();
        temp9.m1("", (java.lang.Object) 127, 95);
        temp9.m();
        temp9.m();
        temp9.m();
        temp0.m1("", (java.lang.Object) temp9, 186);
        java.lang.Class<?> wildcardClass19 = temp0.getClass();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass19);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        Temp temp0 = new Temp();
        temp0.m();
        temp0.m1("hi!", (java.lang.Object) 88, 94);
        temp0.m1("hi!", (java.lang.Object) 131, 98);
        temp0.m1("", (java.lang.Object) 13, 103);
        temp0.m1("hi!", (java.lang.Object) 131, 143);
        temp0.m1("", (java.lang.Object) 195, 0);
        Temp temp23 = new Temp();
        temp23.m();
        temp23.m1("hi!", (java.lang.Object) 88, 94);
        temp23.m1("hi!", (java.lang.Object) 131, 98);
        temp23.m1("", (java.lang.Object) 13, 103);
        temp23.m1("hi!", (java.lang.Object) 131, 143);
        temp23.m1("", (java.lang.Object) 23, 113);
        CopyClassFile copyClassFile46 = new CopyClassFile();
        java.lang.Class<?> wildcardClass47 = copyClassFile46.getClass();
        temp23.m1("hi!", (java.lang.Object) wildcardClass47, 131);
        temp23.m1("", (java.lang.Object) 95, 135);
        temp0.m1("hi!", (java.lang.Object) temp23, 192);
        java.lang.Class<?> wildcardClass56 = temp23.getClass();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass47);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass56);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        Temp temp0 = new Temp();
        temp0.m();
        temp0.m1("hi!", (java.lang.Object) 88, 94);
        temp0.m1("hi!", (java.lang.Object) 131, 98);
        temp0.m1("", (java.lang.Object) 13, 103);
        temp0.m1("hi!", (java.lang.Object) 131, 143);
        temp0.m1("", (java.lang.Object) 195, 118);
        temp0.m();
        java.lang.Class<?> wildcardClass23 = temp0.getClass();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass23);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        Temp temp0 = new Temp();
        temp0.m1("", (java.lang.Object) 127, 95);
        temp0.m1("hi!", (java.lang.Object) 126, 22);
        temp0.m1("", (java.lang.Object) 157, 154);
        ExampleTransformed exampleTransformed14 = new ExampleTransformed();
        temp0.m1("hi!", (java.lang.Object) exampleTransformed14, 10);
        temp0.m();
        temp0.m1("hi!", (java.lang.Object) 256, 51);
        temp0.m();
        temp0.m1("", (java.lang.Object) 2048, 1);
        temp0.m1("hi!", (java.lang.Object) 14, 128);
        java.lang.Class<?> wildcardClass31 = temp0.getClass();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass31);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        Temp temp0 = new Temp();
        temp0.m();
        temp0.m1("hi!", (java.lang.Object) 88, 94);
        temp0.m1("hi!", (java.lang.Object) 131, 98);
        temp0.m1("", (java.lang.Object) 13, 103);
        temp0.m1("hi!", (java.lang.Object) 131, 143);
        temp0.m1("hi!", (java.lang.Object) 161, 132);
        temp0.m();
        temp0.m1("", (java.lang.Object) 171, 2);
        Temp temp28 = new Temp();
        temp28.m();
        temp28.m1("hi!", (java.lang.Object) 88, 94);
        temp28.m1("hi!", (java.lang.Object) 131, 98);
        temp28.m1("", (java.lang.Object) 13, 103);
        temp28.m1("hi!", (java.lang.Object) 131, 143);
        temp28.m1("hi!", (java.lang.Object) 161, 132);
        temp0.m1("hi!", (java.lang.Object) temp28, 56);
        Temp temp53 = new Temp();
        temp53.m();
        temp53.m1("hi!", (java.lang.Object) 88, 94);
        temp53.m1("hi!", (java.lang.Object) 131, 98);
        temp53.m1("", (java.lang.Object) 13, 103);
        temp53.m1("hi!", (java.lang.Object) 131, 143);
        temp53.m1("", (java.lang.Object) 195, 118);
        temp53.m1("", (java.lang.Object) 96, 88);
        temp28.m1("", (java.lang.Object) temp53, 143);
        temp53.m();
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        Temp temp0 = new Temp();
        temp0.m();
        temp0.m1("hi!", (java.lang.Object) 88, 94);
        temp0.m();
        temp0.m();
        temp0.m1("", (java.lang.Object) (byte) -1, 11);
        temp0.m();
        temp0.m();
        java.lang.Class<?> wildcardClass14 = temp0.getClass();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass14);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        Temp temp0 = new Temp();
        temp0.m1("", (java.lang.Object) 127, 95);
        temp0.m();
        temp0.m();
        Temp temp8 = new Temp();
        temp8.m();
        temp8.m1("hi!", (java.lang.Object) 88, 94);
        temp8.m1("hi!", (java.lang.Object) 131, 98);
        temp8.m1("", (java.lang.Object) 13, 103);
        temp8.m1("hi!", (java.lang.Object) 131, 143);
        temp8.m1("", (java.lang.Object) 23, 113);
        java.lang.Object obj31 = null;
        temp8.m1("hi!", obj31, 58);
        temp0.m1("", (java.lang.Object) temp8, 256);
        temp0.m();
        java.lang.Class<?> wildcardClass37 = temp0.getClass();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass37);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        Temp temp0 = new Temp();
        temp0.m1("", (java.lang.Object) 127, 95);
        temp0.m();
        temp0.m();
        temp0.m();
        temp0.m1("", (java.lang.Object) 176, (int) '#');
        temp0.m();
        java.lang.Class<?> wildcardClass13 = temp0.getClass();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass13);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        Temp temp0 = new Temp();
        temp0.m1("", (java.lang.Object) 127, 95);
        temp0.m1("hi!", (java.lang.Object) 126, 22);
        temp0.m1("", (java.lang.Object) 157, 154);
        ExampleTransformed exampleTransformed14 = new ExampleTransformed();
        temp0.m1("hi!", (java.lang.Object) exampleTransformed14, 10);
        temp0.m();
        temp0.m1("hi!", (java.lang.Object) 256, 51);
        temp0.m();
        temp0.m1("", (java.lang.Object) 2048, 1);
        temp0.m1("hi!", (java.lang.Object) 14, 128);
        temp0.m1("", (java.lang.Object) 146, 118);
        Temp temp36 = new Temp();
        temp36.m();
        temp36.m1("hi!", (java.lang.Object) 88, 94);
        temp36.m();
        temp0.m1("", (java.lang.Object) temp36, 84);
        java.lang.Class<?> wildcardClass45 = temp0.getClass();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass45);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        Temp temp0 = new Temp();
        temp0.m1("", (java.lang.Object) 127, 95);
        temp0.m();
        temp0.m1("", (java.lang.Object) 1.0d, 130);
        temp0.m();
        java.lang.Object obj12 = null;
        temp0.m1("hi!", obj12, 123);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        Temp temp0 = new Temp();
        temp0.m();
        temp0.m1("", (java.lang.Object) 15, 141);
        temp0.m();
        Temp temp8 = new Temp();
        temp8.m();
        temp8.m1("hi!", (java.lang.Object) 88, 94);
        temp8.m1("hi!", (java.lang.Object) 131, 98);
        temp8.m1("", (java.lang.Object) 13, 103);
        temp8.m1("hi!", (java.lang.Object) 131, 143);
        temp0.m1("", (java.lang.Object) 143, 144);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        Temp temp0 = new Temp();
        temp0.m1("", (java.lang.Object) 127, 95);
        temp0.m();
        temp0.m1("", (java.lang.Object) 1.0d, 130);
        temp0.m1("hi!", (java.lang.Object) 129, 118);
        Temp temp15 = new Temp();
        temp15.m();
        temp15.m1("hi!", (java.lang.Object) 88, 94);
        temp15.m1("hi!", (java.lang.Object) 131, 98);
        temp15.m1("", (java.lang.Object) 13, 103);
        temp15.m1("hi!", (java.lang.Object) 131, 143);
        temp15.m1("", (java.lang.Object) 195, 118);
        temp15.m1("", (java.lang.Object) 96, 88);
        temp15.m();
        temp15.m1("", (java.lang.Object) 46, 262144);
        temp0.m1("", (java.lang.Object) 46, 192);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        Temp temp0 = new Temp();
        temp0.m();
        temp0.m1("hi!", (java.lang.Object) 88, 94);
        temp0.m1("hi!", (java.lang.Object) 131, 98);
        temp0.m1("", (java.lang.Object) 13, 103);
        temp0.m1("hi!", (java.lang.Object) 131, 143);
        temp0.m1("", (java.lang.Object) 195, 118);
        java.lang.Object obj23 = null;
        temp0.m1("", obj23, 58);
        temp0.m();
        Temp temp28 = new Temp();
        temp28.m();
        temp28.m1("hi!", (java.lang.Object) 88, 94);
        temp28.m1("hi!", (java.lang.Object) 131, 98);
        temp28.m1("", (java.lang.Object) 13, 103);
        temp28.m();
        temp0.m1("", (java.lang.Object) temp28, (int) (byte) -1);
        Temp temp46 = new Temp();
        temp46.m();
        temp46.m1("hi!", (java.lang.Object) 88, 94);
        temp46.m1("hi!", (java.lang.Object) 131, 98);
        temp46.m1("", (java.lang.Object) 13, 103);
        temp46.m1("hi!", (java.lang.Object) 131, 143);
        temp28.m1("", (java.lang.Object) 131, 96);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        Temp temp0 = new Temp();
        temp0.m1("", (java.lang.Object) 127, 95);
        temp0.m1("hi!", (java.lang.Object) 87, 179);
        temp0.m();
        java.lang.Class<?> wildcardClass10 = temp0.getClass();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass10);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        Temp temp0 = new Temp();
        temp0.m1("", (java.lang.Object) 127, 95);
        temp0.m1("hi!", (java.lang.Object) 126, 22);
        temp0.m1("", (java.lang.Object) 157, 154);
        ExampleTransformed exampleTransformed14 = new ExampleTransformed();
        temp0.m1("hi!", (java.lang.Object) exampleTransformed14, 10);
        temp0.m();
        temp0.m1("hi!", (java.lang.Object) 256, 51);
        temp0.m();
        temp0.m();
        Temp temp25 = new Temp();
        temp25.m();
        temp25.m1("hi!", (java.lang.Object) 88, 94);
        temp25.m1("hi!", (java.lang.Object) 131, 98);
        temp25.m1("", (java.lang.Object) 13, 103);
        temp25.m();
        temp25.m();
        temp25.m();
        temp25.m1("hi!", (java.lang.Object) 262144, 84);
        temp25.m1("", (java.lang.Object) 32768, 91);
        temp25.m();
        temp0.m1("", (java.lang.Object) temp25, 0);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        Temp temp0 = new Temp();
        temp0.m();
        temp0.m1("", (java.lang.Object) 15, 141);
        temp0.m1("", (java.lang.Object) 128, (int) (short) 100);
        temp0.m();
        java.lang.Object obj12 = null;
        temp0.m1("hi!", obj12, 3);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        Temp temp0 = new Temp();
        temp0.m();
        temp0.m1("hi!", (java.lang.Object) 88, 94);
        temp0.m1("hi!", (java.lang.Object) 131, 98);
        temp0.m1("", (java.lang.Object) 13, 103);
        temp0.m1("hi!", (java.lang.Object) 131, 143);
        temp0.m1("", (java.lang.Object) 23, 113);
        Temp temp23 = new Temp();
        temp23.m1("", (java.lang.Object) 127, 95);
        temp23.m1("hi!", (java.lang.Object) 126, 22);
        temp23.m1("", (java.lang.Object) 157, 154);
        ExampleTransformed exampleTransformed37 = new ExampleTransformed();
        temp23.m1("hi!", (java.lang.Object) exampleTransformed37, 10);
        temp23.m();
        temp23.m1("hi!", (java.lang.Object) 256, 51);
        temp23.m();
        temp23.m();
        temp23.m();
        temp0.m1("hi!", (java.lang.Object) temp23, 161);
        Temp temp51 = new Temp();
        temp51.m1("", (java.lang.Object) 127, 95);
        temp51.m1("hi!", (java.lang.Object) 126, 22);
        temp51.m1("", (java.lang.Object) 157, 154);
        ExampleTransformed exampleTransformed65 = new ExampleTransformed();
        temp51.m1("hi!", (java.lang.Object) exampleTransformed65, 10);
        temp23.m1("hi!", (java.lang.Object) temp51, 327680);
        java.lang.Class<?> wildcardClass70 = temp23.getClass();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass70);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        Temp temp0 = new Temp();
        temp0.m();
        temp0.m1("hi!", (java.lang.Object) 88, 94);
        temp0.m1("hi!", (java.lang.Object) 131, 98);
        java.lang.Class<?> wildcardClass10 = temp0.getClass();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass10);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        Temp temp0 = new Temp();
        temp0.m1("", (java.lang.Object) 127, 95);
        temp0.m1("hi!", (java.lang.Object) 126, 22);
        temp0.m1("", (java.lang.Object) 157, 154);
        temp0.m();
        temp0.m();
        temp0.m1("", (java.lang.Object) 11, 136);
        Temp temp20 = new Temp();
        temp20.m();
        temp20.m1("hi!", (java.lang.Object) 88, 94);
        temp20.m1("hi!", (java.lang.Object) 131, 98);
        temp20.m1("", (java.lang.Object) 13, 103);
        temp20.m1("hi!", (java.lang.Object) 131, 143);
        temp20.m1("hi!", (java.lang.Object) 161, 132);
        temp20.m();
        temp20.m();
        temp0.m1("", (java.lang.Object) temp20, 79);
        Temp temp47 = new Temp();
        temp47.m();
        temp47.m1("hi!", (java.lang.Object) 88, 94);
        temp47.m1("hi!", (java.lang.Object) 131, 98);
        temp47.m1("", (java.lang.Object) 13, 103);
        temp47.m1("hi!", (java.lang.Object) 131, 143);
        temp47.m1("", (java.lang.Object) 195, 118);
        java.lang.Object obj70 = null;
        temp47.m1("", obj70, 58);
        java.lang.Class<?> wildcardClass73 = temp47.getClass();
        temp20.m1("hi!", (java.lang.Object) temp47, 161);
        temp47.m1("hi!", (java.lang.Object) 82, (int) (byte) 10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass73);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        Temp temp0 = new Temp();
        temp0.m();
        temp0.m1("hi!", (java.lang.Object) 88, 94);
        temp0.m1("hi!", (java.lang.Object) 131, 98);
        temp0.m1("", (java.lang.Object) 13, 103);
        temp0.m1("hi!", (java.lang.Object) 131, 143);
        temp0.m1("hi!", (java.lang.Object) 161, 132);
        temp0.m();
        temp0.m1("", (java.lang.Object) 171, 2);
        Temp temp28 = new Temp();
        temp28.m();
        temp28.m1("hi!", (java.lang.Object) 88, 94);
        temp28.m1("hi!", (java.lang.Object) 131, 98);
        temp28.m1("", (java.lang.Object) 147, (-65536));
        temp28.m1("hi!", (java.lang.Object) 12, 181);
        temp28.m();
        temp0.m1("hi!", (java.lang.Object) temp28, 64);
        temp0.m();
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        Temp temp0 = new Temp();
        temp0.m();
        temp0.m1("hi!", (java.lang.Object) 88, 94);
        temp0.m1("hi!", (java.lang.Object) 131, 98);
        temp0.m1("", (java.lang.Object) 13, 103);
        temp0.m1("hi!", (java.lang.Object) 131, 143);
        temp0.m1("", (java.lang.Object) 262144, 158);
        temp0.m();
        temp0.m();
        Temp temp25 = new Temp();
        temp25.m();
        temp25.m1("hi!", (java.lang.Object) 88, 94);
        temp25.m1("hi!", (java.lang.Object) 131, 98);
        temp25.m1("", (java.lang.Object) 13, 103);
        temp25.m1("hi!", (java.lang.Object) 131, 143);
        temp25.m1("", (java.lang.Object) 23, 113);
        CopyClassFile copyClassFile48 = new CopyClassFile();
        java.lang.Class<?> wildcardClass49 = copyClassFile48.getClass();
        temp25.m1("hi!", (java.lang.Object) wildcardClass49, 131);
        temp25.m();
        Temp temp54 = new Temp();
        temp54.m();
        temp54.m1("hi!", (java.lang.Object) 88, 94);
        temp54.m1("hi!", (java.lang.Object) 131, 98);
        temp54.m1("", (java.lang.Object) 147, (-65536));
        java.lang.Class<?> wildcardClass68 = temp54.getClass();
        temp25.m1("hi!", (java.lang.Object) temp54, (int) (short) 1);
        temp0.m1("", (java.lang.Object) temp54, 173);
        Temp temp74 = new Temp();
        temp74.m();
        temp74.m1("hi!", (java.lang.Object) 88, 94);
        temp74.m1("hi!", (java.lang.Object) 131, 98);
        temp74.m1("", (java.lang.Object) 13, 103);
        temp74.m1("hi!", (java.lang.Object) 131, 143);
        temp0.m1("", (java.lang.Object) "hi!", 91);
        temp0.m();
        temp0.m();
        temp0.m();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass49);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass68);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        Temp temp0 = new Temp();
        temp0.m1("", (java.lang.Object) 127, 95);
        temp0.m1("hi!", (java.lang.Object) 126, 22);
        temp0.m();
        temp0.m();
        java.lang.Class<?> wildcardClass11 = temp0.getClass();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass11);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        Temp temp0 = new Temp();
        temp0.m();
        temp0.m1("hi!", (java.lang.Object) 88, 94);
        temp0.m1("hi!", (java.lang.Object) 131, 98);
        temp0.m1("", (java.lang.Object) 13, 103);
        temp0.m1("hi!", (java.lang.Object) 131, 143);
        temp0.m1("", (java.lang.Object) 23, 113);
        CopyClassFile copyClassFile23 = new CopyClassFile();
        java.lang.Class<?> wildcardClass24 = copyClassFile23.getClass();
        temp0.m1("hi!", (java.lang.Object) wildcardClass24, 131);
        temp0.m();
        temp0.m1("", (java.lang.Object) 121, (int) (byte) 10);
        temp0.m();
        temp0.m();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass24);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        Temp temp0 = new Temp();
        Generated generated2 = new Generated();
        java.lang.Class<?> wildcardClass3 = generated2.getClass();
        temp0.m1("", (java.lang.Object) wildcardClass3, 96);
        temp0.m();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass3);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        Temp temp0 = new Temp();
        temp0.m1("", (java.lang.Object) 127, 95);
        temp0.m1("hi!", (java.lang.Object) 126, 22);
        temp0.m1("", (java.lang.Object) 152, 199);
        temp0.m();
        java.lang.Class<?> wildcardClass14 = temp0.getClass();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass14);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        Temp temp0 = new Temp();
        temp0.m();
        temp0.m1("hi!", (java.lang.Object) 88, 94);
        temp0.m1("hi!", (java.lang.Object) 131, 98);
        temp0.m1("", (java.lang.Object) 13, 103);
        temp0.m1("hi!", (java.lang.Object) 131, 143);
        temp0.m1("", (java.lang.Object) 195, 0);
        temp0.m();
        Temp temp24 = new Temp();
        temp24.m1("", (java.lang.Object) 127, 95);
        temp24.m1("hi!", (java.lang.Object) 126, 22);
        temp24.m1("", (java.lang.Object) 157, 154);
        ExampleTransformed exampleTransformed38 = new ExampleTransformed();
        temp24.m1("hi!", (java.lang.Object) exampleTransformed38, 10);
        temp24.m1("", (java.lang.Object) 82, 105);
        temp24.m();
        temp0.m1("", (java.lang.Object) temp24, 0);
        temp0.m();
        java.lang.Class<?> wildcardClass49 = temp0.getClass();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass49);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        Temp temp0 = new Temp();
        temp0.m1("", (java.lang.Object) 127, 95);
        temp0.m();
        Temp temp7 = new Temp();
        temp7.m();
        temp7.m1("hi!", (java.lang.Object) 88, 94);
        temp7.m1("hi!", (java.lang.Object) 131, 98);
        temp7.m1("", (java.lang.Object) 13, 103);
        temp0.m1("", (java.lang.Object) temp7, 131);
        temp0.m1("", (java.lang.Object) 176, 183);
        temp0.m();
        temp0.m1("hi!", (java.lang.Object) 194, 54);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        Temp temp0 = new Temp();
        temp0.m();
        temp0.m1("", (java.lang.Object) 15, 141);
        temp0.m();
        temp0.m();
        Temp temp9 = new Temp();
        temp9.m();
        temp9.m1("hi!", (java.lang.Object) 88, 94);
        temp9.m1("hi!", (java.lang.Object) 131, 98);
        temp9.m1("", (java.lang.Object) 13, 103);
        temp9.m1("hi!", (java.lang.Object) 131, 143);
        temp9.m1("", (java.lang.Object) 23, 113);
        java.lang.Object obj32 = null;
        temp9.m1("hi!", obj32, 58);
        temp9.m();
        temp0.m1("", (java.lang.Object) temp9, 139);
        Temp temp39 = new Temp();
        temp39.m();
        temp39.m1("hi!", (java.lang.Object) 88, 94);
        temp39.m1("hi!", (java.lang.Object) 131, 98);
        temp39.m1("", (java.lang.Object) 13, 103);
        temp39.m1("hi!", (java.lang.Object) 131, 143);
        temp39.m1("hi!", (java.lang.Object) 161, 132);
        temp39.m();
        temp39.m();
        temp39.m1("hi!", (java.lang.Object) 155, 83);
        temp0.m1("", (java.lang.Object) 83, 47);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        Temp temp0 = new Temp();
        temp0.m();
        temp0.m();
        Temp temp4 = new Temp();
        temp4.m();
        temp4.m1("hi!", (java.lang.Object) 88, 94);
        temp4.m1("hi!", (java.lang.Object) 131, 98);
        temp0.m1("", (java.lang.Object) 131, 5);
        temp0.m();
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        Temp temp0 = new Temp();
        temp0.m1("hi!", (java.lang.Object) (short) 100, 120);
        temp0.m1("", (java.lang.Object) 172, 32768);
        Temp temp10 = new Temp();
        temp10.m();
        temp10.m1("hi!", (java.lang.Object) 88, 94);
        temp10.m1("hi!", (java.lang.Object) 131, 98);
        temp10.m1("", (java.lang.Object) 13, 103);
        temp10.m1("hi!", (java.lang.Object) 131, 143);
        temp10.m1("hi!", (java.lang.Object) 161, 132);
        temp10.m();
        temp10.m1("", (java.lang.Object) 171, 2);
        Temp temp38 = new Temp();
        temp38.m();
        temp38.m1("hi!", (java.lang.Object) 88, 94);
        temp38.m1("hi!", (java.lang.Object) 131, 98);
        temp38.m1("", (java.lang.Object) 13, 103);
        temp38.m1("hi!", (java.lang.Object) 131, 143);
        temp38.m1("hi!", (java.lang.Object) 161, 132);
        temp10.m1("hi!", (java.lang.Object) temp38, 56);
        java.lang.Class<?> wildcardClass62 = temp10.getClass();
        temp0.m1("hi!", (java.lang.Object) temp10, 187);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass62);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        Temp temp0 = new Temp();
        temp0.m();
        temp0.m1("hi!", (java.lang.Object) 88, 94);
        temp0.m1("hi!", (java.lang.Object) 131, 98);
        temp0.m1("", (java.lang.Object) 13, 103);
        Temp temp15 = new Temp();
        temp15.m1("", (java.lang.Object) 127, 95);
        temp15.m1("hi!", (java.lang.Object) 126, 22);
        temp15.m1("", (java.lang.Object) 157, 154);
        temp15.m();
        temp15.m1("", (java.lang.Object) 161, 0);
        temp0.m1("hi!", (java.lang.Object) "", 86);
        java.lang.Object obj36 = null;
        temp0.m1("hi!", obj36, 91);
        temp0.m();
        temp0.m();
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        Temp temp0 = new Temp();
        temp0.m();
        temp0.m1("hi!", (java.lang.Object) 88, 94);
        temp0.m1("hi!", (java.lang.Object) 131, 98);
        temp0.m1("", (java.lang.Object) 13, 103);
        temp0.m1("hi!", (java.lang.Object) 131, 143);
        temp0.m1("", (java.lang.Object) 23, 113);
        Temp temp23 = new Temp();
        temp23.m1("", (java.lang.Object) 127, 95);
        temp23.m1("hi!", (java.lang.Object) 126, 22);
        temp23.m1("", (java.lang.Object) 157, 154);
        ExampleTransformed exampleTransformed37 = new ExampleTransformed();
        temp23.m1("hi!", (java.lang.Object) exampleTransformed37, 10);
        temp23.m();
        temp23.m1("hi!", (java.lang.Object) 256, 51);
        temp23.m();
        temp23.m();
        temp23.m();
        temp0.m1("hi!", (java.lang.Object) temp23, 161);
        java.lang.Object obj51 = null;
        temp0.m1("hi!", obj51, 100);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        Temp temp0 = new Temp();
        temp0.m1("", (java.lang.Object) 127, 95);
        temp0.m1("hi!", (java.lang.Object) 126, 22);
        temp0.m1("", (java.lang.Object) 157, 154);
        ExampleTransformed exampleTransformed14 = new ExampleTransformed();
        temp0.m1("hi!", (java.lang.Object) exampleTransformed14, 10);
        temp0.m();
        temp0.m1("hi!", (java.lang.Object) 256, 51);
        temp0.m();
        temp0.m1("", (java.lang.Object) 2048, 1);
        temp0.m1("", (java.lang.Object) 190, 0);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        Temp temp0 = new Temp();
        temp0.m1("", (java.lang.Object) 127, 95);
        temp0.m();
        temp0.m();
        temp0.m1("", (java.lang.Object) 81, 139);
        java.lang.Object obj12 = null;
        temp0.m1("", obj12, 7);
        Temp temp16 = new Temp();
        temp16.m();
        temp16.m1("hi!", (java.lang.Object) 88, 94);
        temp16.m1("hi!", (java.lang.Object) 131, 98);
        temp16.m1("", (java.lang.Object) 13, 103);
        temp16.m1("hi!", (java.lang.Object) 131, 143);
        temp16.m1("", (java.lang.Object) 23, 113);
        java.lang.Object obj39 = null;
        temp16.m1("hi!", obj39, 58);
        temp0.m1("", (java.lang.Object) 58, 102);
        temp0.m();
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        Temp temp0 = new Temp();
        temp0.m1("", (java.lang.Object) 127, 95);
        temp0.m1("hi!", (java.lang.Object) 126, 22);
        temp0.m1("", (java.lang.Object) 157, 154);
        ExampleTransformed exampleTransformed14 = new ExampleTransformed();
        temp0.m1("hi!", (java.lang.Object) exampleTransformed14, 10);
        temp0.m();
        temp0.m1("hi!", (java.lang.Object) 256, 51);
        temp0.m();
        temp0.m();
        temp0.m1("hi!", (java.lang.Object) 167, 64);
        temp0.m();
        temp0.m1("hi!", (java.lang.Object) 194, 393216);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        Temp temp0 = new Temp();
        temp0.m1("", (java.lang.Object) 127, 95);
        temp0.m1("hi!", (java.lang.Object) 87, 179);
        temp0.m();
        Temp temp11 = new Temp();
        temp11.m1("", (java.lang.Object) 127, 95);
        temp11.m();
        Temp temp18 = new Temp();
        temp18.m();
        temp18.m1("hi!", (java.lang.Object) 88, 94);
        temp18.m1("hi!", (java.lang.Object) 131, 98);
        temp18.m1("", (java.lang.Object) 13, 103);
        temp11.m1("", (java.lang.Object) temp18, 131);
        temp11.m1("", (java.lang.Object) 176, 183);
        temp11.m();
        temp0.m1("hi!", (java.lang.Object) temp11, 64);
        temp0.m();
        java.lang.Class<?> wildcardClass42 = temp0.getClass();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass42);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        Temp temp0 = new Temp();
        temp0.m();
        temp0.m1("hi!", (java.lang.Object) 88, 94);
        temp0.m1("hi!", (java.lang.Object) 131, 98);
        temp0.m1("", (java.lang.Object) 147, (-65536));
        Temp temp15 = new Temp();
        temp15.m();
        temp15.m1("hi!", (java.lang.Object) 88, 94);
        temp15.m1("hi!", (java.lang.Object) 131, 98);
        temp15.m1("", (java.lang.Object) 13, 103);
        temp15.m1("hi!", (java.lang.Object) 131, 143);
        temp15.m1("hi!", (java.lang.Object) 161, 132);
        temp15.m();
        temp0.m1("hi!", (java.lang.Object) temp15, 262144);
        Temp temp41 = new Temp();
        temp41.m1("", (java.lang.Object) 127, 95);
        temp41.m();
        temp41.m();
        temp41.m();
        temp41.m1("", (java.lang.Object) 176, (int) '#');
        temp41.m();
        temp41.m();
        temp41.m();
        temp15.m1("hi!", (java.lang.Object) temp41, 185);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        Temp temp0 = new Temp();
        temp0.m1("", (java.lang.Object) 127, 95);
        temp0.m1("hi!", (java.lang.Object) 87, 179);
        temp0.m();
        Temp temp11 = new Temp();
        temp11.m();
        temp11.m1("hi!", (java.lang.Object) 88, 94);
        temp11.m1("hi!", (java.lang.Object) 131, 98);
        temp11.m1("", (java.lang.Object) 13, 103);
        Temp temp26 = new Temp();
        temp26.m1("", (java.lang.Object) 127, 95);
        temp26.m1("hi!", (java.lang.Object) 126, 22);
        temp26.m1("", (java.lang.Object) 157, 154);
        temp26.m();
        temp26.m1("", (java.lang.Object) 161, 0);
        temp11.m1("hi!", (java.lang.Object) "", 86);
        temp11.m();
        temp0.m1("hi!", (java.lang.Object) temp11, 13);
        temp11.m();
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        Temp temp0 = new Temp();
        temp0.m();
        temp0.m1("hi!", (java.lang.Object) 88, 94);
        temp0.m1("hi!", (java.lang.Object) 131, 98);
        temp0.m1("", (java.lang.Object) 13, 103);
        temp0.m1("hi!", (java.lang.Object) 131, 143);
        temp0.m1("", (java.lang.Object) 262144, 158);
        temp0.m();
        temp0.m();
        Temp temp25 = new Temp();
        temp25.m();
        temp25.m1("hi!", (java.lang.Object) 88, 94);
        temp25.m1("hi!", (java.lang.Object) 131, 98);
        temp25.m1("", (java.lang.Object) 13, 103);
        temp25.m1("hi!", (java.lang.Object) 131, 143);
        temp25.m1("", (java.lang.Object) 23, 113);
        CopyClassFile copyClassFile48 = new CopyClassFile();
        java.lang.Class<?> wildcardClass49 = copyClassFile48.getClass();
        temp25.m1("hi!", (java.lang.Object) wildcardClass49, 131);
        temp25.m();
        Temp temp54 = new Temp();
        temp54.m();
        temp54.m1("hi!", (java.lang.Object) 88, 94);
        temp54.m1("hi!", (java.lang.Object) 131, 98);
        temp54.m1("", (java.lang.Object) 147, (-65536));
        java.lang.Class<?> wildcardClass68 = temp54.getClass();
        temp25.m1("hi!", (java.lang.Object) temp54, (int) (short) 1);
        temp0.m1("", (java.lang.Object) temp54, 173);
        Temp temp74 = new Temp();
        temp74.m();
        temp74.m1("hi!", (java.lang.Object) 88, 94);
        temp74.m1("hi!", (java.lang.Object) 131, 98);
        temp74.m1("", (java.lang.Object) 13, 103);
        temp74.m1("hi!", (java.lang.Object) 131, 143);
        temp0.m1("", (java.lang.Object) "hi!", 91);
        java.lang.Class<?> wildcardClass94 = temp0.getClass();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass49);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass68);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass94);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        Temp temp0 = new Temp();
        temp0.m1("", (java.lang.Object) 127, 95);
        temp0.m();
        Temp temp7 = new Temp();
        temp7.m1("", (java.lang.Object) 127, 95);
        temp7.m1("hi!", (java.lang.Object) 126, 22);
        temp7.m1("", (java.lang.Object) 157, 154);
        temp7.m();
        temp7.m1("hi!", (java.lang.Object) 10.0d, 124);
        temp0.m1("", (java.lang.Object) 124, (int) (byte) -1);
        Temp temp28 = new Temp();
        temp28.m();
        temp28.m1("hi!", (java.lang.Object) 88, 94);
        temp28.m1("hi!", (java.lang.Object) 131, 98);
        temp28.m1("", (java.lang.Object) 147, (-65536));
        temp28.m1("hi!", (java.lang.Object) 86, 177);
        Temp temp47 = new Temp();
        temp47.m1("", (java.lang.Object) 127, 95);
        temp47.m();
        Temp temp54 = new Temp();
        temp54.m();
        temp54.m1("hi!", (java.lang.Object) 88, 94);
        temp54.m1("hi!", (java.lang.Object) 131, 98);
        temp54.m1("", (java.lang.Object) 13, 103);
        temp47.m1("", (java.lang.Object) temp54, 131);
        temp54.m();
        java.lang.Class<?> wildcardClass71 = temp54.getClass();
        temp28.m1("hi!", (java.lang.Object) temp54, 147);
        temp0.m1("hi!", (java.lang.Object) 147, 131);
        temp0.m1("hi!", (java.lang.Object) 83, 50);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass71);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        Temp temp0 = new Temp();
        temp0.m();
        temp0.m1("hi!", (java.lang.Object) 88, 94);
        temp0.m1("hi!", (java.lang.Object) 131, 98);
        temp0.m1("", (java.lang.Object) 147, (-65536));
        temp0.m();
        Temp temp16 = new Temp();
        temp16.m1("", (java.lang.Object) 127, 95);
        temp16.m();
        Temp temp23 = new Temp();
        temp23.m();
        temp23.m1("hi!", (java.lang.Object) 88, 94);
        temp23.m1("hi!", (java.lang.Object) 131, 98);
        temp23.m1("", (java.lang.Object) 13, 103);
        temp16.m1("", (java.lang.Object) temp23, 131);
        java.lang.Object obj40 = null;
        temp16.m1("hi!", obj40, 173);
        Temp temp44 = new Temp();
        temp44.m();
        temp44.m1("hi!", (java.lang.Object) 88, 94);
        temp44.m1("hi!", (java.lang.Object) 131, 98);
        temp44.m1("", (java.lang.Object) 13, 103);
        temp44.m1("hi!", (java.lang.Object) 131, 143);
        temp44.m1("", (java.lang.Object) 23, 113);
        java.lang.Object obj67 = null;
        temp44.m1("hi!", obj67, 58);
        temp16.m1("hi!", (java.lang.Object) temp44, 131072);
        temp0.m1("hi!", (java.lang.Object) temp44, 13);
        java.lang.Class<?> wildcardClass74 = temp0.getClass();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass74);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        Temp temp0 = new Temp();
        temp0.m1("", (java.lang.Object) 127, 95);
        temp0.m();
        Temp temp7 = new Temp();
        temp7.m();
        temp7.m1("hi!", (java.lang.Object) 88, 94);
        temp7.m1("hi!", (java.lang.Object) 131, 98);
        temp7.m1("", (java.lang.Object) 13, 103);
        temp0.m1("", (java.lang.Object) temp7, 131);
        temp0.m1("", (java.lang.Object) 135, 115);
        temp0.m();
        temp0.m();
        temp0.m();
        temp0.m1("", (java.lang.Object) 181, 0);
        temp0.m1("hi!", (java.lang.Object) 12, 150);
        java.lang.Class<?> wildcardClass38 = temp0.getClass();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass38);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        Temp temp0 = new Temp();
        temp0.m();
        temp0.m1("", (java.lang.Object) 15, 157);
        temp0.m1("hi!", (java.lang.Object) 21, 152);
        temp0.m1("hi!", (java.lang.Object) 53, 53);
        temp0.m();
        temp0.m();
        temp0.m1("hi!", (java.lang.Object) 131072, 162);
        temp0.m1("", (java.lang.Object) 190, 58);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        Temp temp0 = new Temp();
        temp0.m();
        temp0.m1("hi!", (java.lang.Object) 88, 94);
        temp0.m1("hi!", (java.lang.Object) 131, 98);
        temp0.m1("", (java.lang.Object) 13, 103);
        temp0.m1("hi!", (java.lang.Object) 131, 143);
        temp0.m1("", (java.lang.Object) 23, 113);
        CopyClassFile copyClassFile23 = new CopyClassFile();
        java.lang.Class<?> wildcardClass24 = copyClassFile23.getClass();
        temp0.m1("hi!", (java.lang.Object) wildcardClass24, 131);
        Temp temp28 = new Temp();
        temp28.m();
        temp28.m1("hi!", (java.lang.Object) 88, 94);
        temp28.m1("hi!", (java.lang.Object) 131, 98);
        temp28.m1("", (java.lang.Object) 13, 103);
        temp28.m1("hi!", (java.lang.Object) 131, 143);
        temp28.m1("", (java.lang.Object) 262144, 158);
        temp28.m();
        temp28.m1("hi!", (java.lang.Object) 11, 11);
        temp28.m();
        temp0.m1("hi!", (java.lang.Object) temp28, (int) (short) 10);
        temp0.m();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass24);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        Temp temp0 = new Temp();
        temp0.m();
        temp0.m1("hi!", (java.lang.Object) 88, 94);
        temp0.m1("hi!", (java.lang.Object) 131, 98);
        temp0.m1("", (java.lang.Object) 13, 103);
        temp0.m1("hi!", (java.lang.Object) 131, 143);
        temp0.m1("", (java.lang.Object) 195, 118);
        Temp temp23 = new Temp();
        temp23.m1("", (java.lang.Object) 127, 95);
        temp23.m1("hi!", (java.lang.Object) 126, 22);
        temp23.m1("", (java.lang.Object) 157, 154);
        temp23.m();
        temp23.m();
        temp23.m();
        temp23.m1("hi!", (java.lang.Object) 172, 112);
        temp23.m();
        temp0.m1("", (java.lang.Object) temp23, (-65536));
        Temp temp47 = new Temp();
        temp47.m1("", (java.lang.Object) 127, 95);
        temp47.m();
        Temp temp54 = new Temp();
        temp54.m();
        temp54.m1("hi!", (java.lang.Object) 88, 94);
        temp54.m1("hi!", (java.lang.Object) 131, 98);
        temp54.m1("", (java.lang.Object) 13, 103);
        temp47.m1("", (java.lang.Object) temp54, 131);
        temp54.m();
        temp54.m();
        temp54.m1("", (java.lang.Object) 54, 150);
        java.lang.Class<?> wildcardClass76 = temp54.getClass();
        temp23.m1("hi!", (java.lang.Object) temp54, 186);
        java.lang.Object obj80 = null;
        temp23.m1("", obj80, 154);
        java.lang.Class<?> wildcardClass83 = temp23.getClass();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass76);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass83);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        Temp temp0 = new Temp();
        temp0.m();
        temp0.m1("hi!", (java.lang.Object) 88, 94);
        temp0.m1("hi!", (java.lang.Object) 131, 98);
        temp0.m1("", (java.lang.Object) 13, 103);
        temp0.m1("hi!", (java.lang.Object) 131, 143);
        temp0.m1("hi!", (java.lang.Object) 161, 132);
        temp0.m();
        Temp temp24 = new Temp();
        temp24.m();
        temp24.m1("", (java.lang.Object) 15, 141);
        temp0.m1("hi!", (java.lang.Object) 15, 199);
        temp0.m();
        temp0.m();
        Temp temp35 = new Temp();
        temp35.m1("", (java.lang.Object) 127, 95);
        temp35.m1("hi!", (java.lang.Object) 126, 22);
        temp35.m1("", (java.lang.Object) 157, 154);
        ExampleTransformed exampleTransformed49 = new ExampleTransformed();
        temp35.m1("hi!", (java.lang.Object) exampleTransformed49, 10);
        temp35.m();
        temp35.m1("hi!", (java.lang.Object) 256, 51);
        temp35.m();
        temp35.m1("", (java.lang.Object) 2048, 1);
        temp35.m();
        temp0.m1("hi!", (java.lang.Object) temp35, 85);
        java.lang.Class<?> wildcardClass65 = temp0.getClass();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass65);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        Temp temp0 = new Temp();
        temp0.m();
        temp0.m1("hi!", (java.lang.Object) 88, 94);
        temp0.m();
        temp0.m();
        temp0.m1("", (java.lang.Object) (byte) -1, 11);
        Temp temp13 = new Temp();
        temp13.m1("", (java.lang.Object) 127, 95);
        temp13.m1("hi!", (java.lang.Object) 126, 22);
        temp13.m1("", (java.lang.Object) 157, 154);
        ExampleTransformed exampleTransformed27 = new ExampleTransformed();
        temp13.m1("hi!", (java.lang.Object) exampleTransformed27, 10);
        temp13.m();
        temp13.m1("hi!", (java.lang.Object) 256, 51);
        temp13.m();
        temp13.m1("", (java.lang.Object) 2048, 1);
        temp13.m1("hi!", (java.lang.Object) 14, 128);
        temp13.m1("", (java.lang.Object) 146, 118);
        Temp temp49 = new Temp();
        temp49.m();
        temp49.m1("hi!", (java.lang.Object) 88, 94);
        temp49.m();
        temp13.m1("", (java.lang.Object) temp49, 84);
        temp0.m1("hi!", (java.lang.Object) temp49, 163);
        temp49.m();
        java.lang.Class<?> wildcardClass61 = temp49.getClass();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass61);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        Temp temp0 = new Temp();
        temp0.m();
        temp0.m1("hi!", (java.lang.Object) 88, 94);
        temp0.m1("hi!", (java.lang.Object) 131, 98);
        temp0.m1("", (java.lang.Object) 147, (-65536));
        temp0.m();
        Temp temp16 = new Temp();
        temp16.m1("", (java.lang.Object) 127, 95);
        temp16.m();
        Temp temp23 = new Temp();
        temp23.m();
        temp23.m1("hi!", (java.lang.Object) 88, 94);
        temp23.m1("hi!", (java.lang.Object) 131, 98);
        temp23.m1("", (java.lang.Object) 13, 103);
        temp16.m1("", (java.lang.Object) temp23, 131);
        java.lang.Object obj40 = null;
        temp16.m1("hi!", obj40, 173);
        Temp temp44 = new Temp();
        temp44.m();
        temp44.m1("hi!", (java.lang.Object) 88, 94);
        temp44.m1("hi!", (java.lang.Object) 131, 98);
        temp44.m1("", (java.lang.Object) 13, 103);
        temp44.m1("hi!", (java.lang.Object) 131, 143);
        temp44.m1("", (java.lang.Object) 23, 113);
        java.lang.Object obj67 = null;
        temp44.m1("hi!", obj67, 58);
        temp16.m1("hi!", (java.lang.Object) temp44, 131072);
        temp0.m1("hi!", (java.lang.Object) temp44, 13);
        temp0.m();
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        Temp temp0 = new Temp();
        temp0.m1("", (java.lang.Object) 127, 95);
        temp0.m();
        temp0.m();
        temp0.m();
        Temp temp9 = new Temp();
        temp9.m();
        temp9.m1("hi!", (java.lang.Object) 88, 94);
        temp9.m1("hi!", (java.lang.Object) 131, 98);
        temp9.m1("", (java.lang.Object) 13, 103);
        temp9.m1("hi!", (java.lang.Object) 131, 143);
        temp9.m1("", (java.lang.Object) 262144, 158);
        temp9.m();
        temp9.m1("hi!", (java.lang.Object) 161, 85);
        Temp temp37 = new Temp();
        temp37.m1("", (java.lang.Object) 127, 95);
        temp37.m1("hi!", (java.lang.Object) 126, 22);
        temp37.m1("", (java.lang.Object) 157, 154);
        ExampleTransformed exampleTransformed51 = new ExampleTransformed();
        temp37.m1("hi!", (java.lang.Object) exampleTransformed51, 10);
        temp37.m();
        temp37.m();
        Temp temp57 = new Temp();
        temp57.m();
        temp57.m1("hi!", (java.lang.Object) 88, 94);
        temp57.m1("hi!", (java.lang.Object) 131, 98);
        temp57.m1("", (java.lang.Object) 13, 103);
        java.lang.Class<?> wildcardClass71 = temp57.getClass();
        temp37.m1("hi!", (java.lang.Object) temp57, 137);
        temp37.m();
        temp9.m1("hi!", (java.lang.Object) temp37, 4096);
        temp0.m1("", (java.lang.Object) 4096, 183);
        temp0.m();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass71);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        Temp temp0 = new Temp();
        temp0.m1("", (java.lang.Object) 127, 95);
        temp0.m1("hi!", (java.lang.Object) 126, 22);
        temp0.m1("", (java.lang.Object) 152, 199);
        Temp temp14 = new Temp();
        temp14.m1("", (java.lang.Object) 127, 95);
        temp14.m();
        Temp temp21 = new Temp();
        temp21.m();
        temp21.m1("hi!", (java.lang.Object) 88, 94);
        temp21.m1("hi!", (java.lang.Object) 131, 98);
        temp21.m1("", (java.lang.Object) 13, 103);
        temp14.m1("", (java.lang.Object) temp21, 131);
        temp21.m();
        temp0.m1("hi!", (java.lang.Object) temp21, 137);
        temp0.m();
        Temp temp42 = new Temp();
        temp42.m1("", (java.lang.Object) 127, 95);
        temp42.m1("hi!", (java.lang.Object) 126, 22);
        temp42.m1("", (java.lang.Object) 157, 154);
        ExampleTransformed exampleTransformed56 = new ExampleTransformed();
        temp42.m1("hi!", (java.lang.Object) exampleTransformed56, 10);
        temp42.m();
        temp42.m1("hi!", (java.lang.Object) 256, 51);
        temp42.m();
        temp42.m1("", (java.lang.Object) 2048, 1);
        temp42.m1("hi!", (java.lang.Object) 14, 128);
        temp42.m1("", (java.lang.Object) 146, 118);
        temp0.m1("hi!", (java.lang.Object) 146, 79);
        temp0.m();
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        Temp temp0 = new Temp();
        temp0.m1("", (java.lang.Object) 127, 95);
        temp0.m1("hi!", (java.lang.Object) 126, 22);
        temp0.m1("", (java.lang.Object) 157, 154);
        ExampleTransformed exampleTransformed14 = new ExampleTransformed();
        temp0.m1("hi!", (java.lang.Object) exampleTransformed14, 10);
        temp0.m();
        temp0.m1("hi!", (java.lang.Object) 256, 51);
        temp0.m();
        temp0.m();
        temp0.m1("hi!", (java.lang.Object) 167, 64);
        temp0.m1("hi!", (java.lang.Object) 178, 119);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        Temp temp0 = new Temp();
        temp0.m1("", (java.lang.Object) 127, 95);
        temp0.m();
        temp0.m1("", (java.lang.Object) 1.0d, 130);
        Temp temp11 = new Temp();
        temp11.m();
        temp11.m1("hi!", (java.lang.Object) 88, 94);
        temp11.m1("hi!", (java.lang.Object) 131, 98);
        temp11.m1("", (java.lang.Object) 147, (-65536));
        temp11.m1("hi!", (java.lang.Object) 12, 181);
        temp11.m();
        temp0.m1("", (java.lang.Object) temp11, 512);
        java.lang.Class<?> wildcardClass32 = temp0.getClass();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass32);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        Temp temp0 = new Temp();
        temp0.m1("", (java.lang.Object) 127, 95);
        temp0.m();
        Example example7 = new Example();
        java.lang.Class<?> wildcardClass8 = example7.getClass();
        temp0.m1("", (java.lang.Object) wildcardClass8, 166);
        temp0.m1("hi!", (java.lang.Object) 180, 198);
        temp0.m();
        temp0.m();
        temp0.m();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass8);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        Temp temp0 = new Temp();
        temp0.m1("", (java.lang.Object) 127, 95);
        temp0.m();
        Temp temp7 = new Temp();
        temp7.m1("", (java.lang.Object) 127, 95);
        temp7.m1("hi!", (java.lang.Object) 126, 22);
        temp7.m1("", (java.lang.Object) 157, 154);
        temp7.m();
        temp7.m1("hi!", (java.lang.Object) 10.0d, 124);
        temp0.m1("", (java.lang.Object) 124, (int) (byte) -1);
        Temp temp28 = new Temp();
        temp28.m();
        temp28.m1("", (java.lang.Object) 15, 141);
        temp0.m1("", (java.lang.Object) temp28, 190);
        java.lang.Class<?> wildcardClass36 = temp28.getClass();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass36);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        Temp temp0 = new Temp();
        temp0.m1("", (java.lang.Object) 127, 95);
        temp0.m1("hi!", (java.lang.Object) 126, 22);
        temp0.m1("", (java.lang.Object) 157, 154);
        ExampleTransformed exampleTransformed14 = new ExampleTransformed();
        temp0.m1("hi!", (java.lang.Object) exampleTransformed14, 10);
        temp0.m();
        temp0.m1("hi!", (java.lang.Object) 256, 51);
        temp0.m();
        temp0.m();
        Temp temp25 = new Temp();
        temp25.m();
        temp25.m1("hi!", (java.lang.Object) 88, 94);
        temp25.m1("hi!", (java.lang.Object) 131, 98);
        temp25.m1("", (java.lang.Object) 13, 103);
        temp25.m1("hi!", (java.lang.Object) 131, 143);
        temp25.m1("hi!", (java.lang.Object) 161, 132);
        temp25.m();
        Temp temp49 = new Temp();
        temp49.m();
        temp49.m1("", (java.lang.Object) 15, 141);
        temp25.m1("hi!", (java.lang.Object) 15, 199);
        temp0.m1("hi!", (java.lang.Object) 15, 79);
        temp0.m();
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        Temp temp0 = new Temp();
        temp0.m();
        temp0.m1("hi!", (java.lang.Object) 88, 94);
        temp0.m1("hi!", (java.lang.Object) 131, 98);
        temp0.m1("", (java.lang.Object) 13, 103);
        temp0.m1("hi!", (java.lang.Object) 131, 143);
        temp0.m1("", (java.lang.Object) 195, 118);
        temp0.m1("", (java.lang.Object) 96, 88);
        Temp temp27 = new Temp();
        temp27.m1("", (java.lang.Object) 127, 95);
        temp27.m();
        temp27.m();
        Temp temp35 = new Temp();
        temp35.m();
        temp35.m1("hi!", (java.lang.Object) 88, 94);
        temp35.m1("hi!", (java.lang.Object) 131, 98);
        temp35.m1("", (java.lang.Object) 13, 103);
        temp35.m1("hi!", (java.lang.Object) 131, 143);
        temp35.m1("", (java.lang.Object) 23, 113);
        java.lang.Object obj58 = null;
        temp35.m1("hi!", obj58, 58);
        temp27.m1("", (java.lang.Object) temp35, 256);
        java.lang.Class<?> wildcardClass63 = temp27.getClass();
        temp0.m1("", (java.lang.Object) temp27, 185);
        temp27.m1("", (java.lang.Object) 58, 114);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass63);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        Temp temp0 = new Temp();
        temp0.m();
        temp0.m1("hi!", (java.lang.Object) 88, 94);
        temp0.m1("hi!", (java.lang.Object) 131, 98);
        temp0.m1("", (java.lang.Object) 13, 103);
        temp0.m1("hi!", (java.lang.Object) 131, 143);
        temp0.m1("", (java.lang.Object) 23, 113);
        CopyClassFile copyClassFile23 = new CopyClassFile();
        java.lang.Class<?> wildcardClass24 = copyClassFile23.getClass();
        temp0.m1("hi!", (java.lang.Object) wildcardClass24, 131);
        temp0.m();
        temp0.m();
        temp0.m();
        java.lang.Class<?> wildcardClass30 = temp0.getClass();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass24);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass30);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        Temp temp0 = new Temp();
        temp0.m1("", (java.lang.Object) 127, 95);
        temp0.m();
        Temp temp7 = new Temp();
        temp7.m();
        temp7.m1("hi!", (java.lang.Object) 88, 94);
        temp7.m1("hi!", (java.lang.Object) 131, 98);
        temp7.m1("", (java.lang.Object) 13, 103);
        temp0.m1("", (java.lang.Object) temp7, 131);
        temp0.m1("", (java.lang.Object) 176, 183);
        temp0.m();
        java.lang.Class<?> wildcardClass28 = temp0.getClass();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass28);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        Temp temp0 = new Temp();
        temp0.m();
        temp0.m1("", (java.lang.Object) 15, 157);
        temp0.m1("hi!", (java.lang.Object) 21, 152);
        temp0.m1("hi!", (java.lang.Object) 53, 53);
        temp0.m();
        temp0.m1("", (java.lang.Object) 136, 131);
        Temp temp20 = new Temp();
        temp20.m();
        temp20.m1("hi!", (java.lang.Object) 88, 94);
        temp20.m1("hi!", (java.lang.Object) 131, 98);
        temp20.m1("", (java.lang.Object) 13, 103);
        temp20.m1("hi!", (java.lang.Object) 131, 143);
        temp20.m1("hi!", (java.lang.Object) 161, 132);
        temp20.m1("", (java.lang.Object) 130, 193);
        temp20.m();
        temp0.m1("hi!", (java.lang.Object) temp20, 54);
        java.lang.Class<?> wildcardClass49 = temp20.getClass();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass49);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        Temp temp0 = new Temp();
        temp0.m();
        temp0.m1("", (java.lang.Object) 15, 141);
        Temp temp7 = new Temp();
        temp7.m();
        temp7.m1("hi!", (java.lang.Object) 88, 94);
        temp7.m1("hi!", (java.lang.Object) 131, 98);
        temp7.m1("", (java.lang.Object) 13, 103);
        temp7.m1("hi!", (java.lang.Object) 131, 143);
        temp7.m1("", (java.lang.Object) 262144, 158);
        temp7.m();
        temp7.m1("hi!", (java.lang.Object) 161, 85);
        java.lang.Class<?> wildcardClass34 = temp7.getClass();
        temp0.m1("", (java.lang.Object) wildcardClass34, 184);
        Temp temp38 = new Temp();
        temp38.m();
        temp38.m1("", (java.lang.Object) 15, 141);
        temp38.m1("", (java.lang.Object) 128, (int) (short) 100);
        temp38.m();
        temp0.m1("", (java.lang.Object) temp38, 121);
        temp38.m();
        temp38.m();
        temp38.m();
        java.lang.Class<?> wildcardClass54 = temp38.getClass();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass34);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass54);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        Temp temp0 = new Temp();
        temp0.m1("", (java.lang.Object) 127, 95);
        temp0.m1("hi!", (java.lang.Object) 126, 22);
        temp0.m1("", (java.lang.Object) 157, 154);
        ExampleTransformed exampleTransformed14 = new ExampleTransformed();
        temp0.m1("hi!", (java.lang.Object) exampleTransformed14, 10);
        temp0.m();
        temp0.m();
        Temp temp20 = new Temp();
        temp20.m();
        temp20.m1("hi!", (java.lang.Object) 88, 94);
        temp20.m1("hi!", (java.lang.Object) 131, 98);
        temp20.m1("", (java.lang.Object) 13, 103);
        java.lang.Class<?> wildcardClass34 = temp20.getClass();
        temp0.m1("hi!", (java.lang.Object) temp20, 137);
        temp0.m();
        Temp temp39 = new Temp();
        temp39.m1("", (java.lang.Object) 127, 95);
        temp39.m();
        Example example46 = new Example();
        java.lang.Class<?> wildcardClass47 = example46.getClass();
        temp39.m1("", (java.lang.Object) wildcardClass47, 166);
        temp0.m1("", (java.lang.Object) temp39, 90);
        Temp temp53 = new Temp();
        temp53.m();
        temp53.m();
        Temp temp57 = new Temp();
        temp57.m();
        temp57.m1("hi!", (java.lang.Object) 88, 94);
        temp57.m1("hi!", (java.lang.Object) 131, 98);
        temp53.m1("", (java.lang.Object) 131, 5);
        temp53.m1("hi!", (java.lang.Object) 168, 100);
        temp53.m1("", (java.lang.Object) 0, 159);
        temp53.m();
        temp39.m1("", (java.lang.Object) temp53, 7);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass34);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass47);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        Temp temp0 = new Temp();
        temp0.m();
        temp0.m1("hi!", (java.lang.Object) 88, 94);
        temp0.m1("hi!", (java.lang.Object) 131, 98);
        temp0.m1("", (java.lang.Object) 13, 103);
        temp0.m1("hi!", (java.lang.Object) 131, 143);
        temp0.m1("", (java.lang.Object) 23, 113);
        CopyClassFile copyClassFile23 = new CopyClassFile();
        java.lang.Class<?> wildcardClass24 = copyClassFile23.getClass();
        temp0.m1("hi!", (java.lang.Object) wildcardClass24, 131);
        Temp temp28 = new Temp();
        temp28.m();
        temp28.m1("hi!", (java.lang.Object) 88, 94);
        temp28.m1("hi!", (java.lang.Object) 131, 98);
        temp28.m();
        java.lang.Class<?> wildcardClass39 = temp28.getClass();
        temp0.m1("hi!", (java.lang.Object) wildcardClass39, (int) (short) 1);
        temp0.m1("", (java.lang.Object) 1024, 109);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass24);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass39);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        Temp temp0 = new Temp();
        temp0.m1("", (java.lang.Object) 127, 95);
        temp0.m1("hi!", (java.lang.Object) 126, 22);
        temp0.m1("", (java.lang.Object) 157, 154);
        temp0.m();
        temp0.m1("hi!", (java.lang.Object) 10.0d, 124);
        temp0.m();
        temp0.m();
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        Temp temp0 = new Temp();
        temp0.m1("", (java.lang.Object) 127, 95);
        temp0.m1("hi!", (java.lang.Object) 126, 22);
        temp0.m1("", (java.lang.Object) 152, 199);
        temp0.m();
        Temp temp15 = new Temp();
        temp15.m();
        temp15.m1("hi!", (java.lang.Object) 88, 94);
        temp15.m1("hi!", (java.lang.Object) 131, 98);
        temp15.m1("", (java.lang.Object) 13, 103);
        temp15.m1("hi!", (java.lang.Object) 131, 143);
        temp15.m1("", (java.lang.Object) 195, 118);
        Temp temp38 = new Temp();
        temp38.m();
        temp38.m1("hi!", (java.lang.Object) 88, 94);
        temp38.m1("hi!", (java.lang.Object) 131, 98);
        temp38.m1("", (java.lang.Object) 13, 103);
        temp38.m1("hi!", (java.lang.Object) 131, 143);
        temp38.m1("", (java.lang.Object) 23, 113);
        CopyClassFile copyClassFile61 = new CopyClassFile();
        java.lang.Class<?> wildcardClass62 = copyClassFile61.getClass();
        temp38.m1("hi!", (java.lang.Object) wildcardClass62, 131);
        temp38.m();
        temp38.m1("", (java.lang.Object) 121, (int) (byte) 10);
        temp15.m1("hi!", (java.lang.Object) temp38, 11);
        temp38.m1("", (java.lang.Object) 101, 159);
        temp0.m1("hi!", (java.lang.Object) "", 180);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass62);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        Temp temp0 = new Temp();
        temp0.m();
        temp0.m1("", (java.lang.Object) 15, 157);
        temp0.m1("hi!", (java.lang.Object) 21, 152);
        temp0.m();
        temp0.m();
        temp0.m();
        java.lang.Class<?> wildcardClass13 = temp0.getClass();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass13);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        Temp temp0 = new Temp();
        temp0.m();
        temp0.m1("hi!", (java.lang.Object) 88, 94);
        temp0.m1("hi!", (java.lang.Object) 131, 98);
        temp0.m1("", (java.lang.Object) 13, 103);
        temp0.m1("hi!", (java.lang.Object) 131, 143);
        temp0.m1("hi!", (java.lang.Object) 161, 132);
        temp0.m();
        temp0.m1("", (java.lang.Object) 171, 2);
        Temp temp28 = new Temp();
        temp28.m();
        temp28.m1("hi!", (java.lang.Object) 88, 94);
        temp28.m1("hi!", (java.lang.Object) 131, 98);
        temp28.m1("", (java.lang.Object) 13, 103);
        temp28.m1("hi!", (java.lang.Object) 131, 143);
        temp28.m1("hi!", (java.lang.Object) 161, 132);
        temp0.m1("hi!", (java.lang.Object) temp28, 56);
        temp0.m();
        java.lang.Class<?> wildcardClass53 = temp0.getClass();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass53);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        Temp temp0 = new Temp();
        temp0.m();
        temp0.m1("hi!", (java.lang.Object) 88, 94);
        temp0.m1("hi!", (java.lang.Object) 131, 98);
        temp0.m1("", (java.lang.Object) 13, 103);
        temp0.m1("hi!", (java.lang.Object) 131, 143);
        temp0.m();
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        Temp temp0 = new Temp();
        temp0.m1("", (java.lang.Object) 127, 95);
        temp0.m1("hi!", (java.lang.Object) 126, 22);
        temp0.m1("hi!", (java.lang.Object) 85, 174);
        temp0.m();
        temp0.m1("hi!", (java.lang.Object) 112, 180);
        Temp temp19 = new Temp();
        temp19.m();
        temp19.m1("hi!", (java.lang.Object) 88, 94);
        temp19.m1("hi!", (java.lang.Object) 131, 98);
        temp19.m1("", (java.lang.Object) 13, 103);
        temp19.m();
        temp19.m();
        temp19.m();
        temp19.m1("hi!", (java.lang.Object) 262144, 84);
        temp19.m1("hi!", (java.lang.Object) 141, 103);
        java.lang.Class<?> wildcardClass44 = temp19.getClass();
        temp0.m1("", (java.lang.Object) wildcardClass44, 181);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass44);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        Temp temp0 = new Temp();
        temp0.m();
        temp0.m1("hi!", (java.lang.Object) 88, 94);
        temp0.m1("hi!", (java.lang.Object) 131, 98);
        temp0.m1("", (java.lang.Object) 13, 103);
        temp0.m1("hi!", (java.lang.Object) 131, 143);
        temp0.m1("", (java.lang.Object) 262144, 158);
        temp0.m();
        temp0.m();
        Temp temp25 = new Temp();
        temp25.m();
        temp25.m1("hi!", (java.lang.Object) 88, 94);
        temp25.m1("hi!", (java.lang.Object) 131, 98);
        temp25.m1("", (java.lang.Object) 13, 103);
        temp25.m1("hi!", (java.lang.Object) 131, 143);
        temp25.m1("", (java.lang.Object) 23, 113);
        CopyClassFile copyClassFile48 = new CopyClassFile();
        java.lang.Class<?> wildcardClass49 = copyClassFile48.getClass();
        temp25.m1("hi!", (java.lang.Object) wildcardClass49, 131);
        temp25.m();
        Temp temp54 = new Temp();
        temp54.m();
        temp54.m1("hi!", (java.lang.Object) 88, 94);
        temp54.m1("hi!", (java.lang.Object) 131, 98);
        temp54.m1("", (java.lang.Object) 147, (-65536));
        java.lang.Class<?> wildcardClass68 = temp54.getClass();
        temp25.m1("hi!", (java.lang.Object) temp54, (int) (short) 1);
        temp0.m1("", (java.lang.Object) temp54, 173);
        Temp temp74 = new Temp();
        temp74.m();
        temp74.m1("hi!", (java.lang.Object) 88, 94);
        temp74.m1("hi!", (java.lang.Object) 131, 98);
        temp74.m1("", (java.lang.Object) 13, 103);
        temp74.m1("hi!", (java.lang.Object) 131, 143);
        temp0.m1("", (java.lang.Object) "hi!", 91);
        temp0.m();
        java.lang.Class<?> wildcardClass95 = temp0.getClass();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass49);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass68);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass95);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        Temp temp0 = new Temp();
        temp0.m1("", (java.lang.Object) 127, 95);
        temp0.m1("hi!", (java.lang.Object) 126, 22);
        temp0.m1("", (java.lang.Object) 152, 199);
        temp0.m();
        Temp temp15 = new Temp();
        temp15.m();
        temp15.m1("hi!", (java.lang.Object) 88, 94);
        temp15.m1("hi!", (java.lang.Object) 131, 98);
        temp15.m1("", (java.lang.Object) 13, 103);
        temp15.m1("hi!", (java.lang.Object) 131, 143);
        temp15.m1("hi!", (java.lang.Object) 161, 132);
        temp15.m();
        temp15.m1("", (java.lang.Object) 171, 2);
        Temp temp43 = new Temp();
        temp43.m();
        temp43.m1("hi!", (java.lang.Object) 88, 94);
        temp43.m1("hi!", (java.lang.Object) 131, 98);
        temp43.m1("", (java.lang.Object) 13, 103);
        temp43.m1("hi!", (java.lang.Object) 131, 143);
        temp43.m1("hi!", (java.lang.Object) 161, 132);
        temp15.m1("hi!", (java.lang.Object) temp43, 56);
        temp0.m1("hi!", (java.lang.Object) temp43, 22);
        temp43.m();
        java.lang.Class<?> wildcardClass70 = temp43.getClass();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass70);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        Temp temp0 = new Temp();
        temp0.m1("", (java.lang.Object) 127, 95);
        temp0.m();
        java.lang.Class<?> wildcardClass6 = temp0.getClass();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass6);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        Temp temp0 = new Temp();
        temp0.m();
        temp0.m1("", (java.lang.Object) 15, 141);
        temp0.m();
        temp0.m();
        Temp temp9 = new Temp();
        temp9.m();
        temp9.m1("hi!", (java.lang.Object) 88, 94);
        temp9.m1("hi!", (java.lang.Object) 131, 98);
        temp9.m1("", (java.lang.Object) 13, 103);
        temp9.m1("hi!", (java.lang.Object) 131, 143);
        temp9.m1("", (java.lang.Object) 23, 113);
        java.lang.Object obj32 = null;
        temp9.m1("hi!", obj32, 58);
        temp9.m();
        temp0.m1("", (java.lang.Object) temp9, 139);
        temp0.m();
        temp0.m1("hi!", (java.lang.Object) 108, 192);
        java.lang.Class<?> wildcardClass43 = temp0.getClass();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass43);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        Temp temp0 = new Temp();
        temp0.m1("", (java.lang.Object) 127, 95);
        temp0.m();
        temp0.m1("", (java.lang.Object) 1.0d, 130);
        temp0.m();
        Temp temp12 = new Temp();
        temp12.m1("", (java.lang.Object) 127, 95);
        temp12.m1("hi!", (java.lang.Object) 126, 22);
        temp12.m1("", (java.lang.Object) 157, 154);
        ExampleTransformed exampleTransformed26 = new ExampleTransformed();
        temp12.m1("hi!", (java.lang.Object) exampleTransformed26, 10);
        temp12.m();
        temp12.m1("hi!", (java.lang.Object) 256, 51);
        temp12.m();
        temp12.m1("", (java.lang.Object) 2048, 1);
        temp12.m1("hi!", (java.lang.Object) 14, 128);
        temp0.m1("", (java.lang.Object) temp12, 103);
        temp12.m1("", (java.lang.Object) 125, 22);
        java.lang.Class<?> wildcardClass49 = temp12.getClass();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass49);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        Temp temp0 = new Temp();
        temp0.m();
        temp0.m1("hi!", (java.lang.Object) 88, 94);
        temp0.m1("hi!", (java.lang.Object) 131, 98);
        temp0.m1("", (java.lang.Object) 13, 103);
        temp0.m1("hi!", (java.lang.Object) 131, 143);
        temp0.m1("hi!", (java.lang.Object) 161, 132);
        temp0.m();
        Temp temp24 = new Temp();
        temp24.m();
        temp24.m1("", (java.lang.Object) 15, 141);
        temp0.m1("hi!", (java.lang.Object) 15, 199);
        temp0.m();
        temp0.m();
        java.lang.Class<?> wildcardClass34 = temp0.getClass();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass34);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        Temp temp0 = new Temp();
        temp0.m();
        temp0.m1("", (java.lang.Object) 15, 157);
        temp0.m1("hi!", (java.lang.Object) 21, 152);
        temp0.m1("hi!", (java.lang.Object) 53, 53);
        temp0.m();
        temp0.m();
        temp0.m1("hi!", (java.lang.Object) 131072, 162);
        java.lang.Class<?> wildcardClass20 = temp0.getClass();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass20);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        Temp temp0 = new Temp();
        temp0.m1("", (java.lang.Object) 127, 95);
        temp0.m();
        temp0.m1("", (java.lang.Object) 1.0d, 130);
        temp0.m();
        Temp temp12 = new Temp();
        temp12.m1("", (java.lang.Object) 127, 95);
        temp12.m1("hi!", (java.lang.Object) 126, 22);
        temp12.m1("", (java.lang.Object) 157, 154);
        ExampleTransformed exampleTransformed26 = new ExampleTransformed();
        temp12.m1("hi!", (java.lang.Object) exampleTransformed26, 10);
        temp12.m();
        temp12.m1("hi!", (java.lang.Object) 256, 51);
        temp12.m();
        temp12.m1("", (java.lang.Object) 2048, 1);
        temp12.m1("hi!", (java.lang.Object) 14, 128);
        temp0.m1("", (java.lang.Object) temp12, 103);
        temp12.m();
        temp12.m();
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        Temp temp0 = new Temp();
        temp0.m();
        temp0.m1("hi!", (java.lang.Object) 88, 94);
        Temp temp7 = new Temp();
        temp7.m();
        temp7.m1("hi!", (java.lang.Object) 88, 94);
        temp7.m1("hi!", (java.lang.Object) 131, 98);
        temp7.m1("", (java.lang.Object) 147, (-65536));
        temp7.m1("hi!", (java.lang.Object) 86, 177);
        Temp temp26 = new Temp();
        temp26.m1("", (java.lang.Object) 127, 95);
        temp26.m();
        Temp temp33 = new Temp();
        temp33.m();
        temp33.m1("hi!", (java.lang.Object) 88, 94);
        temp33.m1("hi!", (java.lang.Object) 131, 98);
        temp33.m1("", (java.lang.Object) 13, 103);
        temp26.m1("", (java.lang.Object) temp33, 131);
        temp33.m();
        java.lang.Class<?> wildcardClass50 = temp33.getClass();
        temp7.m1("hi!", (java.lang.Object) temp33, 147);
        temp0.m1("hi!", (java.lang.Object) "hi!", 58);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass50);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        Temp temp0 = new Temp();
        Generated generated2 = new Generated();
        java.lang.Class<?> wildcardClass3 = generated2.getClass();
        temp0.m1("", (java.lang.Object) wildcardClass3, 96);
        temp0.m1("", (java.lang.Object) 84, 105);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass3);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        Temp temp0 = new Temp();
        temp0.m1("", (java.lang.Object) 127, 95);
        temp0.m1("hi!", (java.lang.Object) 126, 22);
        temp0.m1("", (java.lang.Object) 157, 154);
        temp0.m();
        temp0.m1("hi!", (java.lang.Object) 10.0d, 124);
        temp0.m1("", (java.lang.Object) 176, 129);
        Temp temp23 = new Temp();
        temp23.m();
        temp23.m1("", (java.lang.Object) 15, 157);
        temp0.m1("", (java.lang.Object) "", (int) (byte) 1);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        Temp temp0 = new Temp();
        temp0.m();
        temp0.m1("", (java.lang.Object) 15, 141);
        Temp temp7 = new Temp();
        temp7.m();
        temp7.m1("hi!", (java.lang.Object) 88, 94);
        temp7.m1("hi!", (java.lang.Object) 131, 98);
        temp7.m1("", (java.lang.Object) 13, 103);
        temp7.m1("hi!", (java.lang.Object) 131, 143);
        temp7.m1("", (java.lang.Object) 262144, 158);
        temp7.m();
        temp7.m1("hi!", (java.lang.Object) 161, 85);
        java.lang.Class<?> wildcardClass34 = temp7.getClass();
        temp0.m1("", (java.lang.Object) wildcardClass34, 184);
        Temp temp38 = new Temp();
        temp38.m();
        temp38.m1("", (java.lang.Object) 15, 141);
        temp38.m1("", (java.lang.Object) 128, (int) (short) 100);
        temp38.m();
        temp0.m1("", (java.lang.Object) temp38, 121);
        temp38.m();
        temp38.m();
        temp38.m1("", (java.lang.Object) 132, 87);
        temp38.m();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass34);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        Temp temp0 = new Temp();
        temp0.m();
        temp0.m1("hi!", (java.lang.Object) 88, 94);
        temp0.m1("hi!", (java.lang.Object) 131, 98);
        temp0.m1("", (java.lang.Object) 13, 103);
        temp0.m1("hi!", (java.lang.Object) 131, 143);
        temp0.m1("", (java.lang.Object) 23, 113);
        CopyClassFile copyClassFile23 = new CopyClassFile();
        java.lang.Class<?> wildcardClass24 = copyClassFile23.getClass();
        temp0.m1("hi!", (java.lang.Object) wildcardClass24, 131);
        Temp temp28 = new Temp();
        temp28.m();
        temp28.m1("hi!", (java.lang.Object) 88, 94);
        temp28.m1("hi!", (java.lang.Object) 131, 98);
        temp28.m();
        java.lang.Class<?> wildcardClass39 = temp28.getClass();
        temp0.m1("hi!", (java.lang.Object) wildcardClass39, (int) (short) 1);
        temp0.m();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass24);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass39);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        Temp temp0 = new Temp();
        temp0.m1("", (java.lang.Object) 127, 95);
        temp0.m1("hi!", (java.lang.Object) 126, 22);
        temp0.m1("hi!", (java.lang.Object) 85, 174);
        Temp temp14 = new Temp();
        temp14.m();
        temp14.m1("hi!", (java.lang.Object) 88, 94);
        temp14.m1("hi!", (java.lang.Object) 131, 98);
        temp14.m1("", (java.lang.Object) 13, 103);
        temp14.m1("hi!", (java.lang.Object) 131, 143);
        temp14.m1("hi!", (java.lang.Object) 161, 132);
        temp14.m();
        temp14.m1("", (java.lang.Object) 171, 2);
        Temp temp42 = new Temp();
        temp42.m();
        temp42.m1("hi!", (java.lang.Object) 88, 94);
        temp42.m1("hi!", (java.lang.Object) 131, 98);
        temp42.m1("", (java.lang.Object) 13, 103);
        temp42.m1("hi!", (java.lang.Object) 131, 143);
        temp42.m1("hi!", (java.lang.Object) 161, 132);
        temp14.m1("hi!", (java.lang.Object) temp42, 56);
        java.lang.Object obj67 = null;
        temp14.m1("hi!", obj67, 161);
        temp0.m1("", obj67, 18);
        temp0.m();
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        Temp temp0 = new Temp();
        temp0.m1("", (java.lang.Object) 127, 95);
        temp0.m1("hi!", (java.lang.Object) 126, 22);
        temp0.m1("", (java.lang.Object) 157, 154);
        ExampleTransformed exampleTransformed14 = new ExampleTransformed();
        temp0.m1("hi!", (java.lang.Object) exampleTransformed14, 10);
        temp0.m();
        temp0.m1("hi!", (java.lang.Object) 256, 51);
        temp0.m();
        temp0.m1("", (java.lang.Object) 2048, 1);
        temp0.m1("hi!", (java.lang.Object) 14, 128);
        temp0.m1("", (java.lang.Object) 146, 118);
        Temp temp36 = new Temp();
        temp36.m();
        temp36.m1("hi!", (java.lang.Object) 88, 94);
        temp36.m();
        temp0.m1("", (java.lang.Object) temp36, 84);
        temp0.m();
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        Temp temp0 = new Temp();
        temp0.m1("", (java.lang.Object) 127, 95);
        temp0.m1("hi!", (java.lang.Object) 126, 22);
        temp0.m1("", (java.lang.Object) 152, 199);
        Temp temp14 = new Temp();
        temp14.m1("", (java.lang.Object) 127, 95);
        temp14.m();
        Temp temp21 = new Temp();
        temp21.m();
        temp21.m1("hi!", (java.lang.Object) 88, 94);
        temp21.m1("hi!", (java.lang.Object) 131, 98);
        temp21.m1("", (java.lang.Object) 13, 103);
        temp14.m1("", (java.lang.Object) temp21, 131);
        temp21.m();
        temp0.m1("hi!", (java.lang.Object) temp21, 137);
        temp0.m();
        temp0.m();
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        Temp temp0 = new Temp();
        temp0.m1("", (java.lang.Object) 127, 95);
        temp0.m1("hi!", (java.lang.Object) 126, 22);
        temp0.m1("", (java.lang.Object) 157, 154);
        ExampleTransformed exampleTransformed14 = new ExampleTransformed();
        temp0.m1("hi!", (java.lang.Object) exampleTransformed14, 10);
        temp0.m();
        temp0.m();
        temp0.m();
        temp0.m();
        java.lang.Class<?> wildcardClass21 = temp0.getClass();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass21);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        Temp temp0 = new Temp();
        temp0.m();
        temp0.m1("hi!", (java.lang.Object) 88, 94);
        temp0.m1("hi!", (java.lang.Object) 131, 98);
        temp0.m1("", (java.lang.Object) 13, 103);
        temp0.m1("hi!", (java.lang.Object) 131, 143);
        temp0.m1("", (java.lang.Object) 23, 113);
        CopyClassFile copyClassFile23 = new CopyClassFile();
        java.lang.Class<?> wildcardClass24 = copyClassFile23.getClass();
        temp0.m1("hi!", (java.lang.Object) wildcardClass24, 131);
        temp0.m();
        temp0.m();
        temp0.m();
        temp0.m();
        temp0.m1("", (java.lang.Object) 162, (int) (byte) 1);
        temp0.m();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass24);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        Temp temp0 = new Temp();
        temp0.m1("", (java.lang.Object) 127, 95);
        temp0.m1("hi!", (java.lang.Object) 126, 22);
        temp0.m();
        java.lang.Object obj11 = null;
        temp0.m1("", obj11, 2);
        temp0.m1("hi!", (java.lang.Object) 85, 195);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        Temp temp0 = new Temp();
        temp0.m1("", (java.lang.Object) 127, 95);
        temp0.m1("hi!", (java.lang.Object) 126, 22);
        temp0.m1("", (java.lang.Object) 157, 154);
        ExampleTransformed exampleTransformed14 = new ExampleTransformed();
        temp0.m1("hi!", (java.lang.Object) exampleTransformed14, 10);
        temp0.m();
        temp0.m1("hi!", (java.lang.Object) 256, 51);
        temp0.m();
        Temp temp24 = new Temp();
        temp24.m();
        temp24.m1("hi!", (java.lang.Object) 88, 94);
        temp24.m1("hi!", (java.lang.Object) 131, 98);
        temp24.m1("", (java.lang.Object) 13, 103);
        temp24.m1("hi!", (java.lang.Object) 131, 143);
        temp24.m1("", (java.lang.Object) 23, 113);
        CopyClassFile copyClassFile47 = new CopyClassFile();
        java.lang.Class<?> wildcardClass48 = copyClassFile47.getClass();
        temp24.m1("hi!", (java.lang.Object) wildcardClass48, 131);
        java.lang.Class<?> wildcardClass51 = temp24.getClass();
        temp0.m1("hi!", (java.lang.Object) wildcardClass51, 131072);
        Temp temp55 = new Temp();
        temp55.m1("", (java.lang.Object) 127, 95);
        temp55.m();
        Temp temp62 = new Temp();
        temp62.m();
        temp62.m1("hi!", (java.lang.Object) 88, 94);
        temp62.m1("hi!", (java.lang.Object) 131, 98);
        temp62.m1("", (java.lang.Object) 13, 103);
        temp55.m1("", (java.lang.Object) temp62, 131);
        temp55.m();
        temp0.m1("", (java.lang.Object) temp55, 100);
        temp0.m();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass48);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass51);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        Temp temp0 = new Temp();
        temp0.m1("", (java.lang.Object) 127, 95);
        temp0.m();
        Temp temp7 = new Temp();
        temp7.m();
        temp7.m1("hi!", (java.lang.Object) 88, 94);
        temp7.m1("hi!", (java.lang.Object) 131, 98);
        temp7.m1("", (java.lang.Object) 13, 103);
        temp0.m1("", (java.lang.Object) temp7, 131);
        temp0.m1("", (java.lang.Object) 176, 183);
        java.lang.Class<?> wildcardClass27 = temp0.getClass();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass27);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        Temp temp0 = new Temp();
        temp0.m();
        temp0.m1("hi!", (java.lang.Object) 88, 94);
        temp0.m1("hi!", (java.lang.Object) 131, 98);
        temp0.m1("", (java.lang.Object) 13, 103);
        temp0.m1("hi!", (java.lang.Object) 131, 143);
        temp0.m1("", (java.lang.Object) 23, 113);
        CopyClassFile copyClassFile23 = new CopyClassFile();
        java.lang.Class<?> wildcardClass24 = copyClassFile23.getClass();
        temp0.m1("hi!", (java.lang.Object) wildcardClass24, 131);
        temp0.m1("", (java.lang.Object) 95, 135);
        Temp temp32 = new Temp();
        temp32.m();
        temp32.m1("hi!", (java.lang.Object) 88, 94);
        temp32.m1("hi!", (java.lang.Object) 131, 98);
        temp32.m1("", (java.lang.Object) 13, 103);
        temp32.m1("hi!", (java.lang.Object) 131, 143);
        temp32.m1("", (java.lang.Object) 23, 113);
        temp0.m1("", (java.lang.Object) "", 180);
        temp0.m();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass24);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        Temp temp0 = new Temp();
        temp0.m1("", (java.lang.Object) 127, 95);
        temp0.m();
        temp0.m();
        temp0.m();
        Temp temp9 = new Temp();
        temp9.m1("", (java.lang.Object) 127, 95);
        temp9.m();
        temp9.m();
        temp9.m();
        temp0.m1("", (java.lang.Object) temp9, 186);
        temp9.m();
        java.lang.Class<?> wildcardClass20 = temp9.getClass();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass20);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        Temp temp0 = new Temp();
        temp0.m();
        temp0.m1("hi!", (java.lang.Object) 88, 94);
        temp0.m1("hi!", (java.lang.Object) 131, 98);
        temp0.m1("", (java.lang.Object) 13, 103);
        temp0.m1("hi!", (java.lang.Object) 131, 143);
        temp0.m1("", (java.lang.Object) 23, 113);
        CopyClassFile copyClassFile23 = new CopyClassFile();
        java.lang.Class<?> wildcardClass24 = copyClassFile23.getClass();
        temp0.m1("hi!", (java.lang.Object) wildcardClass24, 131);
        temp0.m();
        temp0.m();
        temp0.m();
        temp0.m();
        java.lang.Class<?> wildcardClass31 = temp0.getClass();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass24);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass31);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        Temp temp0 = new Temp();
        temp0.m();
        temp0.m1("hi!", (java.lang.Object) 88, 94);
        temp0.m1("hi!", (java.lang.Object) 131, 98);
        temp0.m1("", (java.lang.Object) 13, 103);
        temp0.m1("hi!", (java.lang.Object) 131, 143);
        temp0.m1("", (java.lang.Object) 195, 0);
        temp0.m();
        Temp temp24 = new Temp();
        temp24.m1("", (java.lang.Object) 127, 95);
        temp24.m();
        temp24.m();
        temp24.m1("", (java.lang.Object) 81, 139);
        java.lang.Object obj36 = null;
        temp24.m1("", obj36, 7);
        temp0.m1("", (java.lang.Object) temp24, (int) (byte) -1);
        java.lang.Class<?> wildcardClass41 = temp24.getClass();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass41);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        Temp temp0 = new Temp();
        temp0.m();
        temp0.m1("hi!", (java.lang.Object) 88, 94);
        temp0.m1("hi!", (java.lang.Object) 131, 98);
        temp0.m();
        temp0.m();
        temp0.m();
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        Temp temp0 = new Temp();
        temp0.m1("", (java.lang.Object) 127, 95);
        temp0.m1("hi!", (java.lang.Object) 126, 22);
        temp0.m1("", (java.lang.Object) 157, 154);
        ExampleTransformed exampleTransformed14 = new ExampleTransformed();
        temp0.m1("hi!", (java.lang.Object) exampleTransformed14, 10);
        temp0.m();
        temp0.m1("hi!", (java.lang.Object) 256, 51);
        temp0.m();
        temp0.m();
        temp0.m();
        Temp temp26 = new Temp();
        temp26.m1("", (java.lang.Object) 127, 95);
        temp26.m1("hi!", (java.lang.Object) 126, 22);
        temp26.m1("hi!", (java.lang.Object) 85, 174);
        Temp temp40 = new Temp();
        temp40.m();
        temp40.m1("hi!", (java.lang.Object) 88, 94);
        temp40.m1("hi!", (java.lang.Object) 131, 98);
        temp40.m1("", (java.lang.Object) 13, 103);
        temp40.m1("hi!", (java.lang.Object) 131, 143);
        temp40.m1("", (java.lang.Object) 195, 0);
        temp40.m();
        java.lang.Class<?> wildcardClass63 = temp40.getClass();
        temp26.m1("hi!", (java.lang.Object) temp40, 128);
        temp0.m1("hi!", (java.lang.Object) 128, 1024);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass63);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        Temp temp0 = new Temp();
        temp0.m1("", (java.lang.Object) 127, 95);
        temp0.m1("hi!", (java.lang.Object) 126, 22);
        temp0.m1("", (java.lang.Object) 157, 154);
        ExampleTransformed exampleTransformed14 = new ExampleTransformed();
        temp0.m1("hi!", (java.lang.Object) exampleTransformed14, 10);
        temp0.m();
        temp0.m();
        temp0.m();
        java.lang.Class<?> wildcardClass20 = temp0.getClass();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass20);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        Temp temp0 = new Temp();
        temp0.m1("", (java.lang.Object) 127, 95);
        temp0.m();
        temp0.m();
        temp0.m();
        Temp temp9 = new Temp();
        temp9.m1("", (java.lang.Object) 127, 95);
        temp9.m();
        temp9.m();
        temp9.m();
        temp0.m1("", (java.lang.Object) temp9, 186);
        temp9.m();
        temp9.m1("hi!", (java.lang.Object) 91, 106);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        Temp temp0 = new Temp();
        temp0.m();
        temp0.m1("", (java.lang.Object) 15, 157);
        temp0.m1("hi!", (java.lang.Object) 21, 152);
        temp0.m();
        temp0.m();
        Temp temp13 = new Temp();
        temp13.m1("", (java.lang.Object) 127, 95);
        temp13.m1("hi!", (java.lang.Object) 126, 22);
        temp13.m1("", (java.lang.Object) 157, 154);
        temp0.m1("hi!", (java.lang.Object) 157, 79);
        temp0.m();
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        Temp temp0 = new Temp();
        temp0.m1("", (java.lang.Object) 127, 95);
        temp0.m1("hi!", (java.lang.Object) 87, 179);
        temp0.m();
        Temp temp11 = new Temp();
        temp11.m();
        temp11.m1("hi!", (java.lang.Object) 88, 94);
        temp11.m1("hi!", (java.lang.Object) 131, 98);
        temp11.m1("", (java.lang.Object) 13, 103);
        Temp temp26 = new Temp();
        temp26.m1("", (java.lang.Object) 127, 95);
        temp26.m1("hi!", (java.lang.Object) 126, 22);
        temp26.m1("", (java.lang.Object) 157, 154);
        temp26.m();
        temp26.m1("", (java.lang.Object) 161, 0);
        temp11.m1("hi!", (java.lang.Object) "", 86);
        temp11.m();
        temp0.m1("hi!", (java.lang.Object) temp11, 13);
        java.lang.Class<?> wildcardClass49 = temp11.getClass();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass49);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        Temp temp0 = new Temp();
        temp0.m();
        temp0.m1("hi!", (java.lang.Object) 88, 94);
        temp0.m1("hi!", (java.lang.Object) 131, 98);
        temp0.m1("", (java.lang.Object) 13, 103);
        temp0.m1("hi!", (java.lang.Object) 131, 143);
        temp0.m1("", (java.lang.Object) 195, 118);
        Temp temp23 = new Temp();
        temp23.m1("", (java.lang.Object) 127, 95);
        temp23.m1("hi!", (java.lang.Object) 126, 22);
        temp23.m1("", (java.lang.Object) 157, 154);
        temp23.m();
        temp23.m();
        temp23.m();
        temp23.m1("hi!", (java.lang.Object) 172, 112);
        temp23.m();
        temp0.m1("", (java.lang.Object) temp23, (-65536));
        Temp temp47 = new Temp();
        temp47.m1("", (java.lang.Object) 127, 95);
        temp47.m();
        Temp temp54 = new Temp();
        temp54.m();
        temp54.m1("hi!", (java.lang.Object) 88, 94);
        temp54.m1("hi!", (java.lang.Object) 131, 98);
        temp54.m1("", (java.lang.Object) 13, 103);
        temp47.m1("", (java.lang.Object) temp54, 131);
        temp54.m();
        temp54.m();
        temp54.m1("", (java.lang.Object) 54, 150);
        java.lang.Class<?> wildcardClass76 = temp54.getClass();
        temp23.m1("hi!", (java.lang.Object) temp54, 186);
        java.lang.Object obj80 = null;
        temp23.m1("", obj80, 154);
        temp23.m();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass76);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        Temp temp0 = new Temp();
        temp0.m();
        temp0.m1("hi!", (java.lang.Object) 88, 94);
        temp0.m1("hi!", (java.lang.Object) 131, 98);
        temp0.m1("", (java.lang.Object) 13, 103);
        temp0.m1("hi!", (java.lang.Object) 131, 143);
        temp0.m1("", (java.lang.Object) 195, 118);
        temp0.m1("", (java.lang.Object) 96, 88);
        temp0.m();
        temp0.m();
        java.lang.Class<?> wildcardClass28 = temp0.getClass();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass28);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        ExampleTransformed exampleTransformed0 = new ExampleTransformed();
        java.lang.Class<?> wildcardClass1 = exampleTransformed0.getClass();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass1);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        Temp temp0 = new Temp();
        temp0.m();
        temp0.m1("hi!", (java.lang.Object) 88, 94);
        temp0.m1("hi!", (java.lang.Object) 131, 98);
        temp0.m1("", (java.lang.Object) 13, 103);
        temp0.m1("hi!", (java.lang.Object) 131, 143);
        temp0.m1("hi!", (java.lang.Object) 161, 132);
        temp0.m();
        temp0.m1("", (java.lang.Object) 171, 2);
        Temp temp28 = new Temp();
        temp28.m();
        temp28.m1("hi!", (java.lang.Object) 88, 94);
        temp28.m1("hi!", (java.lang.Object) 131, 98);
        temp28.m1("", (java.lang.Object) 13, 103);
        temp28.m1("hi!", (java.lang.Object) 131, 143);
        temp28.m1("hi!", (java.lang.Object) 161, 132);
        temp0.m1("hi!", (java.lang.Object) temp28, 56);
        Temp temp53 = new Temp();
        temp53.m();
        temp53.m1("hi!", (java.lang.Object) 88, 94);
        temp53.m1("hi!", (java.lang.Object) 131, 98);
        temp53.m1("", (java.lang.Object) 13, 103);
        temp53.m1("hi!", (java.lang.Object) 131, 143);
        temp53.m1("", (java.lang.Object) 195, 118);
        temp53.m1("", (java.lang.Object) 96, 88);
        temp28.m1("", (java.lang.Object) temp53, 143);
        java.lang.Class<?> wildcardClass81 = temp28.getClass();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass81);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        Temp temp0 = new Temp();
        temp0.m();
        temp0.m1("hi!", (java.lang.Object) 88, 94);
        temp0.m1("hi!", (java.lang.Object) 131, 98);
        temp0.m1("", (java.lang.Object) 13, 103);
        temp0.m1("hi!", (java.lang.Object) 131, 143);
        temp0.m1("", (java.lang.Object) 262144, 158);
        temp0.m();
        temp0.m1("hi!", (java.lang.Object) 161, 85);
        Temp temp28 = new Temp();
        temp28.m1("", (java.lang.Object) 127, 95);
        temp28.m();
        Temp temp35 = new Temp();
        temp35.m();
        temp35.m1("hi!", (java.lang.Object) 88, 94);
        temp35.m1("hi!", (java.lang.Object) 131, 98);
        temp35.m1("", (java.lang.Object) 13, 103);
        temp28.m1("", (java.lang.Object) temp35, 131);
        Temp temp52 = new Temp();
        temp52.m1("", (java.lang.Object) 127, 95);
        temp52.m1("hi!", (java.lang.Object) 126, 22);
        temp52.m1("", (java.lang.Object) 157, 154);
        ExampleTransformed exampleTransformed66 = new ExampleTransformed();
        temp52.m1("hi!", (java.lang.Object) exampleTransformed66, 10);
        temp52.m();
        java.lang.Object obj71 = null;
        temp52.m1("hi!", obj71, 182);
        temp28.m1("", (java.lang.Object) temp52, 11);
        temp52.m();
        temp0.m1("", (java.lang.Object) temp52, 8);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        Temp temp0 = new Temp();
        temp0.m();
        temp0.m1("hi!", (java.lang.Object) 88, 94);
        temp0.m1("hi!", (java.lang.Object) 131, 98);
        temp0.m1("", (java.lang.Object) 13, 103);
        temp0.m1("hi!", (java.lang.Object) 131, 143);
        temp0.m1("hi!", (java.lang.Object) 161, 132);
        temp0.m();
        Temp temp24 = new Temp();
        temp24.m();
        temp24.m1("", (java.lang.Object) 15, 141);
        temp0.m1("hi!", (java.lang.Object) 15, 199);
        temp0.m();
        temp0.m();
        Temp temp35 = new Temp();
        temp35.m1("", (java.lang.Object) 127, 95);
        temp35.m1("hi!", (java.lang.Object) 126, 22);
        temp35.m1("", (java.lang.Object) 157, 154);
        ExampleTransformed exampleTransformed49 = new ExampleTransformed();
        temp35.m1("hi!", (java.lang.Object) exampleTransformed49, 10);
        temp35.m();
        temp35.m1("hi!", (java.lang.Object) 256, 51);
        temp35.m();
        temp35.m1("", (java.lang.Object) 2048, 1);
        temp35.m();
        temp0.m1("hi!", (java.lang.Object) temp35, 85);
        temp35.m();
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        Temp temp0 = new Temp();
        temp0.m1("", (java.lang.Object) 127, 95);
        temp0.m();
        Example example7 = new Example();
        java.lang.Class<?> wildcardClass8 = example7.getClass();
        temp0.m1("", (java.lang.Object) wildcardClass8, 166);
        temp0.m();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass8);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        Temp temp0 = new Temp();
        temp0.m1("hi!", (java.lang.Object) (short) 100, 120);
        temp0.m();
        temp0.m();
        temp0.m();
        temp0.m();
        temp0.m();
        temp0.m();
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        Temp temp0 = new Temp();
        temp0.m1("", (java.lang.Object) 127, 95);
        temp0.m();
        Temp temp7 = new Temp();
        temp7.m1("", (java.lang.Object) 127, 95);
        temp7.m1("hi!", (java.lang.Object) 126, 22);
        temp7.m1("", (java.lang.Object) 157, 154);
        temp7.m();
        temp7.m1("hi!", (java.lang.Object) 10.0d, 124);
        temp0.m1("", (java.lang.Object) 124, (int) (byte) -1);
        Temp temp28 = new Temp();
        temp28.m();
        temp28.m1("", (java.lang.Object) 15, 141);
        temp0.m1("", (java.lang.Object) temp28, 190);
        Temp temp37 = new Temp();
        temp37.m();
        temp37.m1("hi!", (java.lang.Object) 88, 94);
        temp37.m1("hi!", (java.lang.Object) 131, 98);
        temp37.m1("", (java.lang.Object) 13, 103);
        Temp temp52 = new Temp();
        temp52.m1("", (java.lang.Object) 127, 95);
        temp52.m1("hi!", (java.lang.Object) 126, 22);
        temp52.m1("", (java.lang.Object) 157, 154);
        java.lang.Class<?> wildcardClass65 = temp52.getClass();
        temp37.m1("", (java.lang.Object) temp52, 180);
        java.lang.Class<?> wildcardClass68 = temp52.getClass();
        temp28.m1("", (java.lang.Object) wildcardClass68, 129);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass65);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass68);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        Temp temp0 = new Temp();
        temp0.m();
        temp0.m1("hi!", (java.lang.Object) 88, 94);
        temp0.m1("hi!", (java.lang.Object) 131, 98);
        temp0.m1("", (java.lang.Object) 13, 103);
        Temp temp15 = new Temp();
        temp15.m1("", (java.lang.Object) 127, 95);
        temp15.m1("hi!", (java.lang.Object) 126, 22);
        temp15.m1("", (java.lang.Object) 157, 154);
        java.lang.Class<?> wildcardClass28 = temp15.getClass();
        temp0.m1("", (java.lang.Object) temp15, 180);
        temp0.m();
        java.lang.Class<?> wildcardClass32 = temp0.getClass();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass28);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass32);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        Temp temp0 = new Temp();
        temp0.m();
        temp0.m1("hi!", (java.lang.Object) 88, 94);
        temp0.m1("hi!", (java.lang.Object) 131, 98);
        temp0.m1("", (java.lang.Object) 13, 103);
        Temp temp15 = new Temp();
        temp15.m1("", (java.lang.Object) 127, 95);
        temp15.m1("hi!", (java.lang.Object) 126, 22);
        temp15.m1("", (java.lang.Object) 157, 154);
        temp15.m();
        temp15.m1("", (java.lang.Object) 161, 0);
        temp0.m1("hi!", (java.lang.Object) "", 86);
        temp0.m();
        Temp temp37 = new Temp();
        temp37.m1("", (java.lang.Object) 127, 95);
        temp37.m();
        Temp temp44 = new Temp();
        temp44.m();
        temp44.m1("hi!", (java.lang.Object) 88, 94);
        temp44.m1("hi!", (java.lang.Object) 131, 98);
        temp44.m1("", (java.lang.Object) 13, 103);
        temp37.m1("", (java.lang.Object) temp44, 131);
        temp37.m1("", (java.lang.Object) 176, 183);
        Temp temp65 = new Temp();
        temp65.m1("", (java.lang.Object) 127, 95);
        temp65.m1("hi!", (java.lang.Object) 126, 22);
        temp65.m1("", (java.lang.Object) 157, 154);
        temp65.m();
        temp65.m();
        temp65.m();
        temp65.m1("hi!", (java.lang.Object) 172, 112);
        temp65.m();
        temp37.m1("hi!", (java.lang.Object) temp65, 15);
        java.lang.Class<?> wildcardClass88 = temp37.getClass();
        temp0.m1("hi!", (java.lang.Object) wildcardClass88, 114);
        java.lang.Class<?> wildcardClass91 = temp0.getClass();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass88);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass91);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        Temp temp0 = new Temp();
        temp0.m1("", (java.lang.Object) 127, 95);
        temp0.m();
        Temp temp7 = new Temp();
        temp7.m();
        temp7.m1("hi!", (java.lang.Object) 88, 94);
        temp7.m1("hi!", (java.lang.Object) 131, 98);
        temp7.m1("", (java.lang.Object) 13, 103);
        temp0.m1("", (java.lang.Object) temp7, 131);
        temp0.m1("", (java.lang.Object) 176, 183);
        Temp temp28 = new Temp();
        temp28.m();
        temp28.m1("hi!", (java.lang.Object) 88, 94);
        temp28.m1("hi!", (java.lang.Object) 131, 98);
        temp28.m1("", (java.lang.Object) 13, 103);
        Temp temp43 = new Temp();
        temp43.m1("", (java.lang.Object) 127, 95);
        temp43.m1("hi!", (java.lang.Object) 126, 22);
        temp43.m1("", (java.lang.Object) 157, 154);
        temp43.m();
        temp43.m1("", (java.lang.Object) 161, 0);
        temp28.m1("hi!", (java.lang.Object) "", 86);
        temp0.m1("hi!", (java.lang.Object) 86, 2048);
        temp0.m();
        temp0.m();
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        Temp temp0 = new Temp();
        temp0.m1("", (java.lang.Object) 127, 95);
        temp0.m();
        Temp temp7 = new Temp();
        temp7.m1("", (java.lang.Object) 127, 95);
        temp7.m1("hi!", (java.lang.Object) 126, 22);
        temp7.m1("", (java.lang.Object) 157, 154);
        temp7.m();
        temp7.m1("hi!", (java.lang.Object) 10.0d, 124);
        temp0.m1("", (java.lang.Object) 124, (int) (byte) -1);
        Temp temp28 = new Temp();
        temp28.m();
        temp28.m1("", (java.lang.Object) 15, 141);
        temp0.m1("", (java.lang.Object) temp28, 190);
        Temp temp37 = new Temp();
        temp37.m1("", (java.lang.Object) 127, 95);
        temp37.m1("hi!", (java.lang.Object) 126, 22);
        temp37.m1("", (java.lang.Object) 152, 199);
        temp37.m();
        temp28.m1("hi!", (java.lang.Object) temp37, 185);
        java.lang.Class<?> wildcardClass53 = temp28.getClass();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass53);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        Temp temp0 = new Temp();
        temp0.m();
        temp0.m1("hi!", (java.lang.Object) 88, 94);
        temp0.m1("hi!", (java.lang.Object) 131, 98);
        temp0.m1("", (java.lang.Object) 13, 103);
        temp0.m1("hi!", (java.lang.Object) 131, 143);
        temp0.m1("", (java.lang.Object) 23, 113);
        Temp temp23 = new Temp();
        temp23.m1("", (java.lang.Object) 127, 95);
        temp23.m1("hi!", (java.lang.Object) 126, 22);
        temp23.m1("", (java.lang.Object) 157, 154);
        ExampleTransformed exampleTransformed37 = new ExampleTransformed();
        temp23.m1("hi!", (java.lang.Object) exampleTransformed37, 10);
        temp23.m();
        temp23.m1("hi!", (java.lang.Object) 256, 51);
        temp23.m();
        temp23.m();
        temp23.m();
        temp0.m1("hi!", (java.lang.Object) temp23, 161);
        temp23.m1("hi!", (java.lang.Object) 96, 84);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        Temp temp0 = new Temp();
        temp0.m1("", (java.lang.Object) 127, 95);
        temp0.m();
        Temp temp7 = new Temp();
        temp7.m();
        temp7.m1("hi!", (java.lang.Object) 88, 94);
        temp7.m1("hi!", (java.lang.Object) 131, 98);
        temp7.m1("", (java.lang.Object) 13, 103);
        temp0.m1("", (java.lang.Object) temp7, 131);
        temp7.m();
        temp7.m();
        temp7.m1("", (java.lang.Object) 54, 150);
        temp7.m();
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        Temp temp0 = new Temp();
        temp0.m();
        temp0.m1("hi!", (java.lang.Object) 88, 94);
        temp0.m1("hi!", (java.lang.Object) 131, 98);
        temp0.m1("", (java.lang.Object) 13, 103);
        temp0.m1("hi!", (java.lang.Object) 131, 143);
        temp0.m1("", (java.lang.Object) 262144, 158);
        temp0.m();
        temp0.m1("hi!", (java.lang.Object) 161, 85);
        Temp temp28 = new Temp();
        temp28.m1("", (java.lang.Object) 127, 95);
        temp28.m1("hi!", (java.lang.Object) 126, 22);
        temp28.m1("", (java.lang.Object) 157, 154);
        ExampleTransformed exampleTransformed42 = new ExampleTransformed();
        temp28.m1("hi!", (java.lang.Object) exampleTransformed42, 10);
        temp28.m();
        temp28.m();
        Temp temp48 = new Temp();
        temp48.m();
        temp48.m1("hi!", (java.lang.Object) 88, 94);
        temp48.m1("hi!", (java.lang.Object) 131, 98);
        temp48.m1("", (java.lang.Object) 13, 103);
        java.lang.Class<?> wildcardClass62 = temp48.getClass();
        temp28.m1("hi!", (java.lang.Object) temp48, 137);
        temp28.m();
        temp0.m1("hi!", (java.lang.Object) temp28, 4096);
        temp28.m();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass62);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        Temp temp0 = new Temp();
        temp0.m1("", (java.lang.Object) 127, 95);
        temp0.m1("hi!", (java.lang.Object) 126, 22);
        temp0.m1("", (java.lang.Object) 157, 154);
        temp0.m();
        temp0.m();
        temp0.m();
        temp0.m1("hi!", (java.lang.Object) 172, 112);
        temp0.m1("", (java.lang.Object) 51, 105);
        java.lang.Class<?> wildcardClass24 = temp0.getClass();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass24);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        Temp temp0 = new Temp();
        temp0.m1("", (java.lang.Object) 127, 95);
        temp0.m();
        temp0.m1("", (java.lang.Object) 1.0d, 130);
        temp0.m();
        temp0.m();
        java.lang.Class<?> wildcardClass12 = temp0.getClass();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass12);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        Temp temp0 = new Temp();
        temp0.m1("", (java.lang.Object) 127, 95);
        temp0.m1("hi!", (java.lang.Object) 126, 22);
        temp0.m1("hi!", (java.lang.Object) 85, 174);
        Temp temp14 = new Temp();
        temp14.m();
        temp14.m1("hi!", (java.lang.Object) 88, 94);
        temp14.m1("hi!", (java.lang.Object) 131, 98);
        temp14.m1("", (java.lang.Object) 13, 103);
        temp14.m1("hi!", (java.lang.Object) 131, 143);
        temp14.m1("hi!", (java.lang.Object) 161, 132);
        temp14.m();
        temp14.m1("", (java.lang.Object) 171, 2);
        Temp temp42 = new Temp();
        temp42.m();
        temp42.m1("hi!", (java.lang.Object) 88, 94);
        temp42.m1("hi!", (java.lang.Object) 131, 98);
        temp42.m1("", (java.lang.Object) 13, 103);
        temp42.m1("hi!", (java.lang.Object) 131, 143);
        temp42.m1("hi!", (java.lang.Object) 161, 132);
        temp14.m1("hi!", (java.lang.Object) temp42, 56);
        java.lang.Object obj67 = null;
        temp14.m1("hi!", obj67, 161);
        temp0.m1("", obj67, 18);
        java.lang.Class<?> wildcardClass72 = temp0.getClass();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass72);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        Temp temp0 = new Temp();
        temp0.m();
        temp0.m1("", (java.lang.Object) 15, 157);
        temp0.m1("hi!", (java.lang.Object) 21, 152);
        temp0.m1("hi!", (java.lang.Object) 53, 53);
        temp0.m1("", (java.lang.Object) 100.0d, 3);
        temp0.m1("hi!", (java.lang.Object) 16, 46);
        java.lang.Class<?> wildcardClass22 = temp0.getClass();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass22);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        Temp temp0 = new Temp();
        temp0.m();
        temp0.m1("hi!", (java.lang.Object) 88, 94);
        temp0.m1("hi!", (java.lang.Object) 131, 98);
        temp0.m1("", (java.lang.Object) 13, 103);
        temp0.m1("hi!", (java.lang.Object) 131, 143);
        temp0.m1("hi!", (java.lang.Object) 161, 132);
        temp0.m();
        temp0.m1("", (java.lang.Object) 171, 2);
        Temp temp28 = new Temp();
        temp28.m();
        temp28.m1("hi!", (java.lang.Object) 88, 94);
        temp28.m1("hi!", (java.lang.Object) 131, 98);
        temp28.m1("", (java.lang.Object) 13, 103);
        temp28.m1("hi!", (java.lang.Object) 131, 143);
        temp28.m1("hi!", (java.lang.Object) 161, 132);
        temp0.m1("hi!", (java.lang.Object) temp28, 56);
        temp0.m();
        temp0.m1("", (java.lang.Object) "", (int) (byte) -1);
        temp0.m();
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        Temp temp0 = new Temp();
        temp0.m1("", (java.lang.Object) 127, 95);
        temp0.m();
        temp0.m();
        Temp temp8 = new Temp();
        temp8.m();
        temp8.m1("hi!", (java.lang.Object) 88, 94);
        temp8.m1("hi!", (java.lang.Object) 131, 98);
        temp8.m1("", (java.lang.Object) 13, 103);
        temp8.m1("hi!", (java.lang.Object) 131, 143);
        temp8.m1("", (java.lang.Object) 23, 113);
        java.lang.Object obj31 = null;
        temp8.m1("hi!", obj31, 58);
        temp0.m1("", (java.lang.Object) temp8, 256);
        temp8.m();
        temp8.m();
        java.lang.Class<?> wildcardClass38 = temp8.getClass();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass38);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        Temp temp0 = new Temp();
        temp0.m();
        temp0.m1("hi!", (java.lang.Object) 88, 94);
        temp0.m1("hi!", (java.lang.Object) 131, 98);
        temp0.m1("", (java.lang.Object) 13, 103);
        temp0.m1("hi!", (java.lang.Object) 131, 143);
        temp0.m1("", (java.lang.Object) 195, 0);
        Temp temp23 = new Temp();
        temp23.m();
        temp23.m1("hi!", (java.lang.Object) 88, 94);
        temp23.m1("hi!", (java.lang.Object) 131, 98);
        temp23.m1("", (java.lang.Object) 13, 103);
        temp23.m1("hi!", (java.lang.Object) 131, 143);
        temp23.m1("", (java.lang.Object) 23, 113);
        CopyClassFile copyClassFile46 = new CopyClassFile();
        java.lang.Class<?> wildcardClass47 = copyClassFile46.getClass();
        temp23.m1("hi!", (java.lang.Object) wildcardClass47, 131);
        temp23.m1("", (java.lang.Object) 95, 135);
        temp0.m1("hi!", (java.lang.Object) temp23, 192);
        temp0.m();
        java.lang.Class<?> wildcardClass57 = temp0.getClass();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass47);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass57);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        Temp temp0 = new Temp();
        temp0.m1("", (java.lang.Object) 127, 95);
        temp0.m();
        Temp temp7 = new Temp();
        temp7.m();
        temp7.m1("hi!", (java.lang.Object) 88, 94);
        temp7.m1("hi!", (java.lang.Object) 131, 98);
        temp7.m1("", (java.lang.Object) 13, 103);
        temp0.m1("", (java.lang.Object) temp7, 131);
        temp0.m1("", (java.lang.Object) 135, 115);
        temp0.m();
        temp0.m();
        Temp temp30 = new Temp();
        temp30.m1("", (java.lang.Object) 127, 95);
        temp30.m1("hi!", (java.lang.Object) 126, 22);
        temp30.m1("", (java.lang.Object) 157, 154);
        temp30.m();
        temp30.m1("hi!", (java.lang.Object) 10.0d, 124);
        java.lang.Class<?> wildcardClass48 = temp30.getClass();
        temp0.m1("", (java.lang.Object) temp30, 102);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass48);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        Temp temp0 = new Temp();
        temp0.m1("", (java.lang.Object) 127, 95);
        temp0.m();
        temp0.m1("", (java.lang.Object) 1.0d, 130);
        temp0.m();
        Temp temp12 = new Temp();
        temp12.m1("", (java.lang.Object) 127, 95);
        temp12.m1("hi!", (java.lang.Object) 126, 22);
        temp12.m1("", (java.lang.Object) 157, 154);
        ExampleTransformed exampleTransformed26 = new ExampleTransformed();
        temp12.m1("hi!", (java.lang.Object) exampleTransformed26, 10);
        temp12.m();
        temp12.m1("hi!", (java.lang.Object) 256, 51);
        temp12.m();
        temp12.m1("", (java.lang.Object) 2048, 1);
        temp12.m1("hi!", (java.lang.Object) 14, 128);
        temp0.m1("", (java.lang.Object) temp12, 103);
        Temp temp46 = new Temp();
        temp46.m1("", (java.lang.Object) 127, 95);
        temp46.m();
        Temp temp53 = new Temp();
        temp53.m();
        temp53.m1("hi!", (java.lang.Object) 88, 94);
        temp53.m1("hi!", (java.lang.Object) 131, 98);
        temp53.m1("", (java.lang.Object) 13, 103);
        temp46.m1("", (java.lang.Object) temp53, 131);
        Temp temp70 = new Temp();
        temp70.m1("", (java.lang.Object) 127, 95);
        temp70.m1("hi!", (java.lang.Object) 126, 22);
        temp70.m1("", (java.lang.Object) 157, 154);
        ExampleTransformed exampleTransformed84 = new ExampleTransformed();
        temp70.m1("hi!", (java.lang.Object) exampleTransformed84, 10);
        temp70.m();
        java.lang.Object obj89 = null;
        temp70.m1("hi!", obj89, 182);
        temp46.m1("", (java.lang.Object) temp70, 11);
        temp0.m1("", (java.lang.Object) temp46, 181);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        Temp temp0 = new Temp();
        temp0.m();
        temp0.m1("hi!", (java.lang.Object) 88, 94);
        temp0.m1("hi!", (java.lang.Object) 131, 98);
        temp0.m1("", (java.lang.Object) 13, 103);
        temp0.m1("hi!", (java.lang.Object) 131, 143);
        temp0.m1("", (java.lang.Object) 195, 118);
        temp0.m1("", (java.lang.Object) 96, 88);
        temp0.m();
        Temp temp28 = new Temp();
        temp28.m();
        temp28.m1("hi!", (java.lang.Object) 88, 94);
        temp28.m();
        temp28.m();
        temp28.m1("", (java.lang.Object) (byte) -1, 11);
        java.lang.Class<?> wildcardClass40 = temp28.getClass();
        temp0.m1("hi!", (java.lang.Object) wildcardClass40, (int) (short) -1);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass40);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        Temp temp0 = new Temp();
        temp0.m1("", (java.lang.Object) 127, 95);
        temp0.m1("hi!", (java.lang.Object) 126, 22);
        temp0.m1("", (java.lang.Object) 157, 154);
        ExampleTransformed exampleTransformed14 = new ExampleTransformed();
        temp0.m1("hi!", (java.lang.Object) exampleTransformed14, 10);
        temp0.m();
        temp0.m1("hi!", (java.lang.Object) 256, 51);
        temp0.m();
        temp0.m1("", (java.lang.Object) 2048, 1);
        temp0.m();
        temp0.m();
        Temp temp30 = new Temp();
        temp30.m1("", (java.lang.Object) 127, 95);
        temp30.m();
        Temp temp37 = new Temp();
        temp37.m();
        temp37.m1("hi!", (java.lang.Object) 88, 94);
        temp37.m1("hi!", (java.lang.Object) 131, 98);
        temp37.m1("", (java.lang.Object) 13, 103);
        temp30.m1("", (java.lang.Object) temp37, 131);
        Temp temp54 = new Temp();
        temp54.m1("", (java.lang.Object) 127, 95);
        temp54.m1("hi!", (java.lang.Object) 126, 22);
        temp54.m1("", (java.lang.Object) 157, 154);
        ExampleTransformed exampleTransformed68 = new ExampleTransformed();
        temp54.m1("hi!", (java.lang.Object) exampleTransformed68, 10);
        temp54.m();
        java.lang.Object obj73 = null;
        temp54.m1("hi!", obj73, 182);
        temp30.m1("", (java.lang.Object) temp54, 11);
        temp30.m();
        temp0.m1("hi!", (java.lang.Object) temp30, 124);
        java.lang.Class<?> wildcardClass81 = temp0.getClass();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass81);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        Temp temp0 = new Temp();
        temp0.m();
        temp0.m1("", (java.lang.Object) 15, 141);
        Temp temp7 = new Temp();
        temp7.m();
        temp7.m1("hi!", (java.lang.Object) 88, 94);
        temp7.m1("hi!", (java.lang.Object) 131, 98);
        temp7.m1("", (java.lang.Object) 13, 103);
        temp7.m1("hi!", (java.lang.Object) 131, 143);
        temp7.m1("", (java.lang.Object) 262144, 158);
        temp7.m();
        temp7.m1("hi!", (java.lang.Object) 161, 85);
        java.lang.Class<?> wildcardClass34 = temp7.getClass();
        temp0.m1("", (java.lang.Object) wildcardClass34, 184);
        Temp temp38 = new Temp();
        temp38.m();
        temp38.m1("hi!", (java.lang.Object) 88, 94);
        temp38.m1("hi!", (java.lang.Object) 131, 98);
        temp38.m1("", (java.lang.Object) 13, 103);
        temp38.m1("hi!", (java.lang.Object) 131, 143);
        temp38.m1("hi!", (java.lang.Object) 161, 132);
        temp38.m();
        Temp temp62 = new Temp();
        temp62.m();
        temp62.m1("", (java.lang.Object) 15, 141);
        temp38.m1("hi!", (java.lang.Object) 15, 199);
        temp38.m();
        temp38.m1("hi!", (java.lang.Object) 79, 148);
        temp0.m1("", (java.lang.Object) 79, 97);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass34);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        Temp temp0 = new Temp();
        temp0.m();
        temp0.m1("", (java.lang.Object) 15, 157);
        temp0.m1("hi!", (java.lang.Object) 21, 152);
        java.lang.Class<?> wildcardClass10 = temp0.getClass();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass10);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        Temp temp0 = new Temp();
        temp0.m();
        temp0.m1("hi!", (java.lang.Object) 88, 94);
        temp0.m();
        temp0.m();
        temp0.m1("", (java.lang.Object) (byte) -1, 11);
        temp0.m();
        Temp temp14 = new Temp();
        temp14.m1("", (java.lang.Object) 127, 95);
        temp14.m1("hi!", (java.lang.Object) 126, 22);
        temp14.m1("", (java.lang.Object) 152, 199);
        Temp temp28 = new Temp();
        temp28.m1("", (java.lang.Object) 127, 95);
        temp28.m();
        Temp temp35 = new Temp();
        temp35.m();
        temp35.m1("hi!", (java.lang.Object) 88, 94);
        temp35.m1("hi!", (java.lang.Object) 131, 98);
        temp35.m1("", (java.lang.Object) 13, 103);
        temp28.m1("", (java.lang.Object) temp35, 131);
        temp35.m();
        temp14.m1("hi!", (java.lang.Object) temp35, 137);
        java.lang.Class<?> wildcardClass54 = temp14.getClass();
        temp0.m1("hi!", (java.lang.Object) temp14, 25);
        java.lang.Class<?> wildcardClass57 = temp0.getClass();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass54);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass57);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        Temp temp0 = new Temp();
        temp0.m1("hi!", (java.lang.Object) (short) 100, 120);
        temp0.m();
        temp0.m1("hi!", (java.lang.Object) 131072, 176);
        temp0.m();
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        Temp temp0 = new Temp();
        temp0.m();
        temp0.m1("hi!", (java.lang.Object) 88, 94);
        temp0.m1("hi!", (java.lang.Object) 131, 98);
        temp0.m1("", (java.lang.Object) 13, 103);
        Temp temp15 = new Temp();
        temp15.m1("", (java.lang.Object) 127, 95);
        temp15.m1("hi!", (java.lang.Object) 126, 22);
        temp15.m1("", (java.lang.Object) 157, 154);
        temp15.m();
        temp15.m1("", (java.lang.Object) 161, 0);
        temp0.m1("hi!", (java.lang.Object) "", 86);
        temp0.m();
        temp0.m();
        java.lang.Class<?> wildcardClass37 = temp0.getClass();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass37);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        Temp temp0 = new Temp();
        temp0.m();
        temp0.m1("", (java.lang.Object) 15, 141);
        temp0.m();
        temp0.m();
        temp0.m();
        java.lang.Object obj10 = null;
        temp0.m1("", obj10, 96);
        java.lang.Class<?> wildcardClass13 = temp0.getClass();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass13);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        Temp temp0 = new Temp();
        temp0.m();
        temp0.m1("hi!", (java.lang.Object) 88, 94);
        temp0.m1("hi!", (java.lang.Object) 131, 98);
        temp0.m1("", (java.lang.Object) 13, 103);
        Temp temp15 = new Temp();
        temp15.m1("", (java.lang.Object) 127, 95);
        temp15.m1("hi!", (java.lang.Object) 126, 22);
        temp15.m1("", (java.lang.Object) 157, 154);
        temp15.m();
        temp15.m1("", (java.lang.Object) 161, 0);
        temp0.m1("hi!", (java.lang.Object) "", 86);
        java.lang.Object obj36 = null;
        temp0.m1("hi!", obj36, 91);
        temp0.m1("", (java.lang.Object) 458752, 195);
        temp0.m();
        temp0.m();
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        Temp temp0 = new Temp();
        temp0.m();
        temp0.m1("", (java.lang.Object) 15, 141);
        temp0.m();
        temp0.m();
        temp0.m();
        Temp temp10 = new Temp();
        temp10.m();
        temp10.m1("hi!", (java.lang.Object) 88, 94);
        Temp temp17 = new Temp();
        temp17.m1("", (java.lang.Object) 127, 95);
        temp17.m1("hi!", (java.lang.Object) 126, 22);
        temp17.m1("", (java.lang.Object) 157, 154);
        ExampleTransformed exampleTransformed31 = new ExampleTransformed();
        temp17.m1("hi!", (java.lang.Object) exampleTransformed31, 10);
        java.lang.Class<?> wildcardClass34 = temp17.getClass();
        temp10.m1("", (java.lang.Object) wildcardClass34, 106);
        temp0.m1("", (java.lang.Object) "", 108);
        Temp temp40 = new Temp();
        temp40.m();
        temp40.m1("hi!", (java.lang.Object) 88, 94);
        temp40.m1("hi!", (java.lang.Object) 131, 98);
        temp40.m1("", (java.lang.Object) 13, 103);
        temp40.m1("hi!", (java.lang.Object) 131, 143);
        temp40.m1("", (java.lang.Object) 262144, 158);
        temp40.m();
        temp40.m();
        temp0.m1("hi!", (java.lang.Object) temp40, 8192);
        Example example67 = new Example();
        temp40.m1("hi!", (java.lang.Object) example67, 56);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass34);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        Temp temp0 = new Temp();
        temp0.m1("", (java.lang.Object) 127, 95);
        temp0.m1("hi!", (java.lang.Object) 126, 22);
        temp0.m1("", (java.lang.Object) 157, 154);
        ExampleTransformed exampleTransformed14 = new ExampleTransformed();
        temp0.m1("hi!", (java.lang.Object) exampleTransformed14, 10);
        temp0.m();
        temp0.m();
        Temp temp20 = new Temp();
        temp20.m1("", (java.lang.Object) 127, 95);
        temp20.m();
        Temp temp27 = new Temp();
        temp27.m();
        temp27.m1("hi!", (java.lang.Object) 88, 94);
        temp27.m1("hi!", (java.lang.Object) 131, 98);
        temp27.m1("", (java.lang.Object) 13, 103);
        temp20.m1("", (java.lang.Object) temp27, 131);
        Temp temp44 = new Temp();
        temp44.m();
        temp44.m1("hi!", (java.lang.Object) 88, 94);
        temp44.m1("hi!", (java.lang.Object) 131, 98);
        temp44.m1("", (java.lang.Object) 13, 103);
        temp44.m1("hi!", (java.lang.Object) 131, 143);
        temp44.m1("", (java.lang.Object) 195, 118);
        Temp temp67 = new Temp();
        temp67.m1("", (java.lang.Object) 127, 95);
        temp67.m1("hi!", (java.lang.Object) 126, 22);
        temp67.m1("", (java.lang.Object) 157, 154);
        temp67.m();
        temp67.m();
        temp67.m();
        temp67.m1("hi!", (java.lang.Object) 172, 112);
        temp67.m();
        temp44.m1("", (java.lang.Object) temp67, (-65536));
        temp20.m1("hi!", (java.lang.Object) temp44, 112);
        temp0.m1("", (java.lang.Object) "hi!", 22);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        Temp temp0 = new Temp();
        temp0.m1("hi!", (java.lang.Object) (short) 100, 120);
        temp0.m();
        temp0.m();
        temp0.m();
        temp0.m();
        java.lang.Class<?> wildcardClass9 = temp0.getClass();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass9);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        Temp temp0 = new Temp();
        temp0.m1("", (java.lang.Object) 127, 95);
        temp0.m1("hi!", (java.lang.Object) 126, 22);
        temp0.m1("", (java.lang.Object) 152, 199);
        temp0.m();
        Temp temp15 = new Temp();
        temp15.m();
        temp15.m1("hi!", (java.lang.Object) 88, 94);
        temp15.m1("hi!", (java.lang.Object) 131, 98);
        temp15.m1("", (java.lang.Object) 13, 103);
        temp15.m1("hi!", (java.lang.Object) 131, 143);
        temp15.m1("hi!", (java.lang.Object) 161, 132);
        temp15.m();
        temp15.m1("", (java.lang.Object) 171, 2);
        Temp temp43 = new Temp();
        temp43.m();
        temp43.m1("hi!", (java.lang.Object) 88, 94);
        temp43.m1("hi!", (java.lang.Object) 131, 98);
        temp43.m1("", (java.lang.Object) 13, 103);
        temp43.m1("hi!", (java.lang.Object) 131, 143);
        temp43.m1("hi!", (java.lang.Object) 161, 132);
        temp15.m1("hi!", (java.lang.Object) temp43, 56);
        temp0.m1("hi!", (java.lang.Object) temp43, 22);
        temp0.m1("hi!", (java.lang.Object) 97, 149);
        temp0.m();
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        Temp temp0 = new Temp();
        temp0.m();
        Temp temp3 = new Temp();
        temp3.m();
        temp3.m1("hi!", (java.lang.Object) 88, 94);
        temp3.m1("hi!", (java.lang.Object) 131, 98);
        temp3.m1("", (java.lang.Object) 13, 103);
        Temp temp18 = new Temp();
        temp18.m1("", (java.lang.Object) 127, 95);
        temp18.m1("hi!", (java.lang.Object) 126, 22);
        temp18.m1("", (java.lang.Object) 157, 154);
        temp18.m();
        temp18.m1("", (java.lang.Object) 161, 0);
        temp3.m1("hi!", (java.lang.Object) "", 86);
        java.lang.Object obj39 = null;
        temp3.m1("hi!", obj39, 91);
        java.lang.Class<?> wildcardClass42 = temp3.getClass();
        temp0.m1("", (java.lang.Object) temp3, 143);
        java.lang.Class<?> wildcardClass45 = temp3.getClass();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass42);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass45);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        Temp temp0 = new Temp();
        temp0.m();
        temp0.m1("hi!", (java.lang.Object) 88, 94);
        temp0.m1("hi!", (java.lang.Object) 131, 98);
        temp0.m1("", (java.lang.Object) 13, 103);
        temp0.m1("hi!", (java.lang.Object) 131, 143);
        temp0.m1("", (java.lang.Object) 262144, 158);
        temp0.m();
        temp0.m1("hi!", (java.lang.Object) 161, 85);
        Temp temp28 = new Temp();
        temp28.m();
        temp28.m1("hi!", (java.lang.Object) 88, 94);
        temp28.m1("hi!", (java.lang.Object) 131, 98);
        temp28.m1("", (java.lang.Object) 13, 103);
        Temp temp43 = new Temp();
        temp43.m1("", (java.lang.Object) 127, 95);
        temp43.m1("hi!", (java.lang.Object) 126, 22);
        temp43.m1("", (java.lang.Object) 157, 154);
        temp43.m();
        temp43.m1("", (java.lang.Object) 161, 0);
        temp28.m1("hi!", (java.lang.Object) "", 86);
        java.lang.Class<?> wildcardClass63 = temp28.getClass();
        temp0.m1("hi!", (java.lang.Object) wildcardClass63, 15);
        temp0.m();
        temp0.m();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass63);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        Temp temp0 = new Temp();
        temp0.m1("", (java.lang.Object) 127, 95);
        temp0.m();
        temp0.m();
        temp0.m1("", (java.lang.Object) 81, 139);
        java.lang.Object obj12 = null;
        temp0.m1("", obj12, 7);
        java.lang.Class<?> wildcardClass15 = temp0.getClass();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass15);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        Temp temp0 = new Temp();
        temp0.m();
        temp0.m1("hi!", (java.lang.Object) 88, 94);
        temp0.m1("hi!", (java.lang.Object) 131, 98);
        temp0.m1("", (java.lang.Object) 13, 103);
        temp0.m1("hi!", (java.lang.Object) 131, 143);
        temp0.m1("", (java.lang.Object) 195, 0);
        temp0.m();
        Temp temp24 = new Temp();
        temp24.m1("", (java.lang.Object) 127, 95);
        temp24.m1("hi!", (java.lang.Object) 126, 22);
        temp24.m1("", (java.lang.Object) 157, 154);
        ExampleTransformed exampleTransformed38 = new ExampleTransformed();
        temp24.m1("hi!", (java.lang.Object) exampleTransformed38, 10);
        temp24.m1("", (java.lang.Object) 82, 105);
        temp24.m();
        temp0.m1("", (java.lang.Object) temp24, 0);
        temp0.m();
        temp0.m();
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        Temp temp0 = new Temp();
        temp0.m();
        temp0.m1("", (java.lang.Object) 15, 157);
        temp0.m1("hi!", (java.lang.Object) 21, 152);
        temp0.m1("hi!", (java.lang.Object) 53, 53);
        temp0.m();
        temp0.m();
        temp0.m1("hi!", (java.lang.Object) 131072, 162);
        temp0.m();
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        Temp temp0 = new Temp();
        temp0.m();
        temp0.m1("hi!", (java.lang.Object) 88, 94);
        temp0.m1("hi!", (java.lang.Object) 131, 98);
        temp0.m1("", (java.lang.Object) 147, (-65536));
        Temp temp15 = new Temp();
        temp15.m();
        temp15.m1("hi!", (java.lang.Object) 88, 94);
        temp15.m1("hi!", (java.lang.Object) 131, 98);
        temp15.m1("", (java.lang.Object) 13, 103);
        temp15.m1("hi!", (java.lang.Object) 131, 143);
        temp15.m1("hi!", (java.lang.Object) 161, 132);
        temp15.m();
        temp0.m1("hi!", (java.lang.Object) temp15, 262144);
        Temp temp41 = new Temp();
        temp41.m();
        temp41.m1("", (java.lang.Object) 15, 141);
        temp41.m1("", (java.lang.Object) 128, (int) (short) 100);
        temp41.m();
        temp41.m();
        temp0.m1("hi!", (java.lang.Object) temp41, 109);
    }
}

