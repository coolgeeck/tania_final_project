import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test501() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test501");
        Temp temp0 = new Temp();
        temp0.m();
        temp0.m1("hi!", (java.lang.Object) 88, 94);
        temp0.m1("hi!", (java.lang.Object) 131, 98);
        temp0.m1("", (java.lang.Object) 13, 103);
        temp0.m1("hi!", (java.lang.Object) 131, 143);
        temp0.m1("", (java.lang.Object) 262144, 158);
        temp0.m();
        temp0.m1("hi!", (java.lang.Object) 161, 85);
        Temp temp28 = new Temp();
        temp28.m1("", (java.lang.Object) 127, 95);
        temp28.m1("hi!", (java.lang.Object) 126, 22);
        temp28.m1("", (java.lang.Object) 157, 154);
        ExampleTransformed exampleTransformed42 = new ExampleTransformed();
        temp28.m1("hi!", (java.lang.Object) exampleTransformed42, 10);
        temp28.m();
        temp28.m();
        Temp temp48 = new Temp();
        temp48.m();
        temp48.m1("hi!", (java.lang.Object) 88, 94);
        temp48.m1("hi!", (java.lang.Object) 131, 98);
        temp48.m1("", (java.lang.Object) 13, 103);
        java.lang.Class<?> wildcardClass62 = temp48.getClass();
        temp28.m1("hi!", (java.lang.Object) temp48, 137);
        temp28.m();
        temp0.m1("hi!", (java.lang.Object) temp28, 4096);
        temp0.m();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass62);
    }

    @Test
    public void test502() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test502");
        Temp temp0 = new Temp();
        temp0.m();
        temp0.m1("hi!", (java.lang.Object) 88, 94);
        temp0.m1("hi!", (java.lang.Object) 131, 98);
        temp0.m1("", (java.lang.Object) 13, 103);
        temp0.m1("hi!", (java.lang.Object) 131, 143);
        temp0.m1("", (java.lang.Object) 23, 113);
        CopyClassFile copyClassFile23 = new CopyClassFile();
        java.lang.Class<?> wildcardClass24 = copyClassFile23.getClass();
        temp0.m1("hi!", (java.lang.Object) wildcardClass24, 131);
        temp0.m();
        temp0.m();
        temp0.m();
        temp0.m1("", (java.lang.Object) 181, 98);
        temp0.m();
        temp0.m();
        temp0.m1("hi!", (java.lang.Object) 4096, 0);
        Temp temp41 = new Temp();
        temp41.m();
        temp41.m1("hi!", (java.lang.Object) 88, 94);
        temp41.m1("hi!", (java.lang.Object) 131, 98);
        temp41.m1("", (java.lang.Object) 13, 103);
        temp41.m();
        temp41.m();
        temp41.m();
        temp41.m1("hi!", (java.lang.Object) 262144, 84);
        java.lang.Object obj63 = new java.lang.Object();
        temp41.m1("", obj63, 0);
        temp0.m1("", (java.lang.Object) "", 2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass24);
    }

    @Test
    public void test503() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test503");
        Temp temp0 = new Temp();
        temp0.m1("", (java.lang.Object) 127, 95);
        temp0.m1("hi!", (java.lang.Object) 126, 22);
        temp0.m1("", (java.lang.Object) 157, 154);
        temp0.m();
        temp0.m();
        temp0.m1("", (java.lang.Object) 11, 136);
        Temp temp20 = new Temp();
        temp20.m();
        temp20.m1("hi!", (java.lang.Object) 88, 94);
        temp20.m1("hi!", (java.lang.Object) 131, 98);
        temp20.m1("", (java.lang.Object) 13, 103);
        temp20.m1("hi!", (java.lang.Object) 131, 143);
        temp20.m1("hi!", (java.lang.Object) 161, 132);
        temp20.m();
        temp20.m();
        temp0.m1("", (java.lang.Object) temp20, 79);
        java.lang.Class<?> wildcardClass46 = temp0.getClass();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass46);
    }

    @Test
    public void test504() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test504");
        Temp temp0 = new Temp();
        temp0.m();
        temp0.m1("hi!", (java.lang.Object) 88, 94);
        temp0.m1("hi!", (java.lang.Object) 131, 98);
        temp0.m1("", (java.lang.Object) 13, 103);
        temp0.m1("hi!", (java.lang.Object) 131, 143);
        temp0.m1("", (java.lang.Object) 23, 113);
        Temp temp23 = new Temp();
        temp23.m1("", (java.lang.Object) 127, 95);
        temp23.m1("hi!", (java.lang.Object) 126, 22);
        temp23.m1("", (java.lang.Object) 157, 154);
        ExampleTransformed exampleTransformed37 = new ExampleTransformed();
        temp23.m1("hi!", (java.lang.Object) exampleTransformed37, 10);
        temp23.m();
        temp23.m1("hi!", (java.lang.Object) 256, 51);
        temp23.m();
        temp23.m();
        temp23.m();
        temp0.m1("hi!", (java.lang.Object) temp23, 161);
        Temp temp51 = new Temp();
        temp51.m1("", (java.lang.Object) 127, 95);
        temp51.m1("hi!", (java.lang.Object) 126, 22);
        temp51.m1("", (java.lang.Object) 157, 154);
        ExampleTransformed exampleTransformed65 = new ExampleTransformed();
        temp51.m1("hi!", (java.lang.Object) exampleTransformed65, 10);
        temp23.m1("hi!", (java.lang.Object) temp51, 327680);
        temp23.m1("hi!", (java.lang.Object) 148, (int) (short) 1);
        temp23.m1("hi!", (java.lang.Object) 58, 46);
        temp23.m();
        java.lang.Class<?> wildcardClass79 = temp23.getClass();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass79);
    }

    @Test
    public void test505() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test505");
        Temp temp0 = new Temp();
        temp0.m();
        temp0.m1("hi!", (java.lang.Object) 88, 94);
        temp0.m1("hi!", (java.lang.Object) 131, 98);
        temp0.m1("", (java.lang.Object) 13, 103);
        temp0.m1("hi!", (java.lang.Object) 131, 143);
        temp0.m1("", (java.lang.Object) 23, 113);
        CopyClassFile copyClassFile23 = new CopyClassFile();
        java.lang.Class<?> wildcardClass24 = copyClassFile23.getClass();
        temp0.m1("hi!", (java.lang.Object) wildcardClass24, 131);
        temp0.m();
        temp0.m();
        temp0.m();
        temp0.m1("", (java.lang.Object) 181, 98);
        temp0.m();
        Temp temp36 = new Temp();
        temp0.m1("", (java.lang.Object) temp36, 196653);
        temp0.m1("hi!", (java.lang.Object) 187, 58);
        temp0.m();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass24);
    }

    @Test
    public void test506() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test506");
        Temp temp0 = new Temp();
        temp0.m();
        temp0.m();
        Temp temp4 = new Temp();
        temp4.m();
        temp4.m1("hi!", (java.lang.Object) 88, 94);
        temp4.m1("hi!", (java.lang.Object) 131, 98);
        temp0.m1("", (java.lang.Object) 131, 5);
        Temp temp17 = new Temp();
        temp17.m1("", (java.lang.Object) 127, 95);
        temp17.m1("hi!", (java.lang.Object) 87, 179);
        temp17.m();
        temp0.m1("", (java.lang.Object) temp17, 2048);
    }

    @Test
    public void test507() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test507");
        Temp temp0 = new Temp();
        temp0.m();
        temp0.m1("hi!", (java.lang.Object) 88, 94);
        temp0.m1("hi!", (java.lang.Object) 131, 98);
        temp0.m1("", (java.lang.Object) 147, (-65536));
        Temp temp15 = new Temp();
        temp15.m();
        temp15.m1("hi!", (java.lang.Object) 88, 94);
        temp15.m1("hi!", (java.lang.Object) 131, 98);
        temp15.m1("", (java.lang.Object) 13, 103);
        temp15.m1("hi!", (java.lang.Object) 131, 143);
        temp15.m1("hi!", (java.lang.Object) 161, 132);
        temp15.m();
        temp0.m1("hi!", (java.lang.Object) temp15, 262144);
        temp15.m();
    }

    @Test
    public void test508() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test508");
        Temp temp0 = new Temp();
        temp0.m1("", (java.lang.Object) 127, 95);
        temp0.m();
        Temp temp7 = new Temp();
        temp7.m();
        temp7.m1("hi!", (java.lang.Object) 88, 94);
        temp7.m1("hi!", (java.lang.Object) 131, 98);
        temp7.m1("", (java.lang.Object) 13, 103);
        temp0.m1("", (java.lang.Object) temp7, 131);
        Temp temp24 = new Temp();
        temp24.m();
        temp24.m1("hi!", (java.lang.Object) 88, 94);
        temp24.m1("hi!", (java.lang.Object) 131, 98);
        temp24.m1("", (java.lang.Object) 13, 103);
        temp24.m1("hi!", (java.lang.Object) 131, 143);
        temp24.m1("", (java.lang.Object) 195, 118);
        Temp temp47 = new Temp();
        temp47.m1("", (java.lang.Object) 127, 95);
        temp47.m1("hi!", (java.lang.Object) 126, 22);
        temp47.m1("", (java.lang.Object) 157, 154);
        temp47.m();
        temp47.m();
        temp47.m();
        temp47.m1("hi!", (java.lang.Object) 172, 112);
        temp47.m();
        temp24.m1("", (java.lang.Object) temp47, (-65536));
        temp0.m1("hi!", (java.lang.Object) temp24, 112);
        temp24.m1("hi!", (java.lang.Object) 137, 100);
    }

    @Test
    public void test509() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test509");
        Temp temp0 = new Temp();
        temp0.m1("", (java.lang.Object) 127, 95);
        temp0.m();
        temp0.m();
        temp0.m();
        Temp temp9 = new Temp();
        temp9.m1("", (java.lang.Object) 127, 95);
        temp9.m();
        temp9.m();
        temp9.m();
        temp0.m1("", (java.lang.Object) temp9, 186);
        temp9.m1("", (java.lang.Object) 186, 126);
    }

    @Test
    public void test510() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test510");
        Temp temp0 = new Temp();
        temp0.m();
        temp0.m1("hi!", (java.lang.Object) 88, 94);
        temp0.m1("hi!", (java.lang.Object) 131, 98);
        temp0.m1("", (java.lang.Object) 13, 103);
        temp0.m1("hi!", (java.lang.Object) 131, 143);
        temp0.m1("", (java.lang.Object) 23, 113);
        CopyClassFile copyClassFile23 = new CopyClassFile();
        java.lang.Class<?> wildcardClass24 = copyClassFile23.getClass();
        temp0.m1("hi!", (java.lang.Object) wildcardClass24, 131);
        temp0.m();
        temp0.m();
        temp0.m();
        temp0.m1("", (java.lang.Object) 181, 98);
        temp0.m();
        Temp temp36 = new Temp();
        temp0.m1("", (java.lang.Object) temp36, 196653);
        temp36.m();
        temp36.m();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass24);
    }

    @Test
    public void test511() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test511");
        Temp temp0 = new Temp();
        temp0.m1("", (java.lang.Object) 127, 95);
        temp0.m();
        temp0.m();
        temp0.m();
        Temp temp9 = new Temp();
        temp9.m1("", (java.lang.Object) 127, 95);
        temp9.m();
        temp9.m();
        temp9.m();
        temp0.m1("", (java.lang.Object) temp9, 186);
        temp9.m1("hi!", (java.lang.Object) 0.0d, 90);
        temp9.m();
    }

    @Test
    public void test512() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test512");
        Temp temp0 = new Temp();
        temp0.m();
        temp0.m1("hi!", (java.lang.Object) 88, 94);
        temp0.m1("hi!", (java.lang.Object) 131, 98);
        temp0.m1("", (java.lang.Object) 13, 103);
        temp0.m1("hi!", (java.lang.Object) 131, 143);
        temp0.m1("hi!", (java.lang.Object) 161, 132);
        temp0.m();
        temp0.m();
        Temp temp25 = new Temp();
        temp25.m();
        temp25.m1("hi!", (java.lang.Object) 88, 94);
        temp25.m1("hi!", (java.lang.Object) 131, 98);
        temp25.m1("", (java.lang.Object) 13, 103);
        temp25.m1("hi!", (java.lang.Object) 131, 143);
        temp25.m1("", (java.lang.Object) 195, 118);
        java.lang.Object obj48 = null;
        temp25.m1("", obj48, 58);
        temp25.m();
        Temp temp53 = new Temp();
        temp53.m();
        temp53.m1("hi!", (java.lang.Object) 88, 94);
        temp53.m1("hi!", (java.lang.Object) 131, 98);
        temp53.m1("", (java.lang.Object) 13, 103);
        temp53.m();
        temp25.m1("", (java.lang.Object) temp53, (int) (byte) -1);
        temp0.m1("hi!", (java.lang.Object) (byte) -1, 123);
    }

    @Test
    public void test513() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test513");
        Temp temp0 = new Temp();
        temp0.m1("", (java.lang.Object) 127, 95);
        temp0.m1("hi!", (java.lang.Object) 126, 22);
        temp0.m1("", (java.lang.Object) 157, 154);
        ExampleTransformed exampleTransformed14 = new ExampleTransformed();
        temp0.m1("hi!", (java.lang.Object) exampleTransformed14, 10);
        temp0.m();
        temp0.m();
        Temp temp20 = new Temp();
        temp20.m();
        temp20.m1("hi!", (java.lang.Object) 88, 94);
        temp20.m1("hi!", (java.lang.Object) 131, 98);
        temp20.m1("", (java.lang.Object) 13, 103);
        java.lang.Class<?> wildcardClass34 = temp20.getClass();
        temp0.m1("hi!", (java.lang.Object) temp20, 137);
        temp0.m();
        Temp temp39 = new Temp();
        temp39.m1("", (java.lang.Object) 127, 95);
        temp39.m();
        Example example46 = new Example();
        java.lang.Class<?> wildcardClass47 = example46.getClass();
        temp39.m1("", (java.lang.Object) wildcardClass47, 166);
        temp0.m1("", (java.lang.Object) temp39, 90);
        temp39.m();
        java.lang.Class<?> wildcardClass53 = temp39.getClass();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass34);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass47);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass53);
    }

    @Test
    public void test514() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test514");
        Temp temp0 = new Temp();
        temp0.m();
        temp0.m1("hi!", (java.lang.Object) 88, 94);
        temp0.m1("hi!", (java.lang.Object) 131, 98);
        temp0.m1("", (java.lang.Object) 13, 103);
        Temp temp15 = new Temp();
        temp15.m1("", (java.lang.Object) 127, 95);
        temp15.m1("hi!", (java.lang.Object) 126, 22);
        temp15.m1("", (java.lang.Object) 157, 154);
        temp15.m();
        temp15.m1("", (java.lang.Object) 161, 0);
        temp0.m1("hi!", (java.lang.Object) "", 86);
        java.lang.Object obj36 = null;
        temp0.m1("hi!", obj36, 91);
        temp0.m1("", (java.lang.Object) 160, 177);
    }

    @Test
    public void test515() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test515");
        Temp temp0 = new Temp();
        temp0.m1("", (java.lang.Object) 127, 95);
        temp0.m();
        Temp temp7 = new Temp();
        temp7.m();
        temp7.m1("hi!", (java.lang.Object) 88, 94);
        temp7.m1("hi!", (java.lang.Object) 131, 98);
        temp7.m1("", (java.lang.Object) 13, 103);
        temp0.m1("", (java.lang.Object) temp7, 131);
        temp0.m1("", (java.lang.Object) 176, 183);
        Temp temp28 = new Temp();
        temp28.m1("", (java.lang.Object) 127, 95);
        temp28.m1("hi!", (java.lang.Object) 126, 22);
        temp28.m1("", (java.lang.Object) 157, 154);
        temp28.m();
        temp28.m();
        temp28.m();
        temp28.m1("hi!", (java.lang.Object) 172, 112);
        temp28.m();
        temp0.m1("hi!", (java.lang.Object) temp28, 15);
        temp0.m();
        java.lang.Class<?> wildcardClass52 = temp0.getClass();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass52);
    }

    @Test
    public void test516() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test516");
        Temp temp0 = new Temp();
        temp0.m1("", (java.lang.Object) 127, 95);
        temp0.m();
        Temp temp7 = new Temp();
        temp7.m1("", (java.lang.Object) 127, 95);
        temp7.m1("hi!", (java.lang.Object) 126, 22);
        temp7.m1("", (java.lang.Object) 157, 154);
        temp7.m();
        temp7.m1("hi!", (java.lang.Object) 10.0d, 124);
        temp0.m1("", (java.lang.Object) 124, (int) (byte) -1);
        temp0.m();
    }

    @Test
    public void test517() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test517");
        Temp temp0 = new Temp();
        temp0.m();
        temp0.m1("hi!", (java.lang.Object) 88, 94);
        temp0.m1("hi!", (java.lang.Object) 131, 98);
        temp0.m1("", (java.lang.Object) 13, 103);
        temp0.m1("hi!", (java.lang.Object) 131, 143);
        temp0.m1("", (java.lang.Object) 195, 118);
        Temp temp23 = new Temp();
        temp23.m();
        temp23.m1("hi!", (java.lang.Object) 88, 94);
        temp23.m1("hi!", (java.lang.Object) 131, 98);
        temp23.m1("", (java.lang.Object) 13, 103);
        temp23.m1("hi!", (java.lang.Object) 131, 143);
        temp23.m1("", (java.lang.Object) 23, 113);
        CopyClassFile copyClassFile46 = new CopyClassFile();
        java.lang.Class<?> wildcardClass47 = copyClassFile46.getClass();
        temp23.m1("hi!", (java.lang.Object) wildcardClass47, 131);
        temp23.m();
        temp23.m1("", (java.lang.Object) 121, (int) (byte) 10);
        temp0.m1("hi!", (java.lang.Object) temp23, 11);
        temp0.m();
        temp0.m();
        java.lang.Class<?> wildcardClass59 = temp0.getClass();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass47);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass59);
    }

    @Test
    public void test518() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test518");
        Temp temp0 = new Temp();
        temp0.m();
        temp0.m1("hi!", (java.lang.Object) 88, 94);
        Temp temp7 = new Temp();
        temp7.m1("", (java.lang.Object) 127, 95);
        temp7.m1("hi!", (java.lang.Object) 126, 22);
        temp7.m1("", (java.lang.Object) 157, 154);
        ExampleTransformed exampleTransformed21 = new ExampleTransformed();
        temp7.m1("hi!", (java.lang.Object) exampleTransformed21, 10);
        java.lang.Class<?> wildcardClass24 = temp7.getClass();
        temp0.m1("", (java.lang.Object) wildcardClass24, 106);
        temp0.m1("hi!", (java.lang.Object) 52, 25);
        temp0.m1("", (java.lang.Object) 512, 120);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass24);
    }

    @Test
    public void test519() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test519");
        Temp temp0 = new Temp();
        temp0.m1("", (java.lang.Object) 127, 95);
        temp0.m1("hi!", (java.lang.Object) 126, 22);
        temp0.m1("", (java.lang.Object) 157, 154);
        ExampleTransformed exampleTransformed14 = new ExampleTransformed();
        temp0.m1("hi!", (java.lang.Object) exampleTransformed14, 10);
        temp0.m();
        temp0.m();
        temp0.m();
        temp0.m();
        Temp temp22 = new Temp();
        temp22.m();
        temp22.m1("", (java.lang.Object) 15, 141);
        temp22.m();
        temp22.m();
        Temp temp31 = new Temp();
        temp31.m();
        temp31.m1("hi!", (java.lang.Object) 88, 94);
        temp31.m1("hi!", (java.lang.Object) 131, 98);
        temp31.m1("", (java.lang.Object) 13, 103);
        temp31.m1("hi!", (java.lang.Object) 131, 143);
        temp31.m1("", (java.lang.Object) 23, 113);
        java.lang.Object obj54 = null;
        temp31.m1("hi!", obj54, 58);
        temp31.m();
        temp22.m1("", (java.lang.Object) temp31, 139);
        temp22.m1("hi!", (java.lang.Object) 48, 256);
        temp0.m1("", (java.lang.Object) temp22, 128);
        Temp temp67 = new Temp();
        temp67.m();
        temp67.m1("", (java.lang.Object) 15, 157);
        temp67.m1("", (java.lang.Object) "hi!", 181);
        temp67.m1("hi!", (java.lang.Object) 9, 6);
        temp22.m1("hi!", (java.lang.Object) 9, 93);
        java.lang.Class<?> wildcardClass83 = temp22.getClass();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass83);
    }

    @Test
    public void test520() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test520");
        Temp temp0 = new Temp();
        temp0.m1("", (java.lang.Object) 127, 95);
        temp0.m1("hi!", (java.lang.Object) 126, 22);
        temp0.m1("", (java.lang.Object) 152, 199);
        Temp temp14 = new Temp();
        temp14.m1("", (java.lang.Object) 127, 95);
        temp14.m();
        Temp temp21 = new Temp();
        temp21.m();
        temp21.m1("hi!", (java.lang.Object) 88, 94);
        temp21.m1("hi!", (java.lang.Object) 131, 98);
        temp21.m1("", (java.lang.Object) 13, 103);
        temp14.m1("", (java.lang.Object) temp21, 131);
        temp21.m();
        temp0.m1("hi!", (java.lang.Object) temp21, 137);
        temp21.m1("", (java.lang.Object) 15, 5);
        java.lang.Class<?> wildcardClass44 = temp21.getClass();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass44);
    }

    @Test
    public void test521() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test521");
        Temp temp0 = new Temp();
        temp0.m();
        temp0.m1("hi!", (java.lang.Object) 88, 94);
        temp0.m1("hi!", (java.lang.Object) 131, 98);
        temp0.m1("", (java.lang.Object) 147, (-65536));
        temp0.m1("hi!", (java.lang.Object) 86, 177);
        temp0.m();
        temp0.m();
    }

    @Test
    public void test522() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test522");
        Temp temp0 = new Temp();
        temp0.m();
        temp0.m1("hi!", (java.lang.Object) 88, 94);
        temp0.m1("hi!", (java.lang.Object) 131, 98);
        temp0.m1("", (java.lang.Object) 147, (-65536));
        Temp temp15 = new Temp();
        temp15.m();
        temp15.m1("hi!", (java.lang.Object) 88, 94);
        temp15.m1("hi!", (java.lang.Object) 131, 98);
        temp15.m1("", (java.lang.Object) 13, 103);
        temp15.m1("hi!", (java.lang.Object) 131, 143);
        temp15.m1("hi!", (java.lang.Object) 161, 132);
        temp15.m();
        temp0.m1("hi!", (java.lang.Object) temp15, 262144);
        java.lang.Class<?> wildcardClass40 = temp0.getClass();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass40);
    }

    @Test
    public void test523() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test523");
        Temp temp0 = new Temp();
        temp0.m();
        temp0.m1("hi!", (java.lang.Object) 88, 94);
        temp0.m1("hi!", (java.lang.Object) 131, 98);
        temp0.m1("", (java.lang.Object) 13, 103);
        Temp temp15 = new Temp();
        temp15.m1("", (java.lang.Object) 127, 95);
        temp15.m1("hi!", (java.lang.Object) 126, 22);
        temp15.m1("", (java.lang.Object) 157, 154);
        java.lang.Class<?> wildcardClass28 = temp15.getClass();
        temp0.m1("", (java.lang.Object) temp15, 180);
        Temp temp32 = new Temp();
        temp32.m();
        temp32.m1("hi!", (java.lang.Object) 88, 94);
        Temp temp39 = new Temp();
        temp39.m();
        temp39.m1("", (java.lang.Object) 15, 157);
        temp39.m1("hi!", (java.lang.Object) 21, 152);
        temp39.m1("hi!", (java.lang.Object) 53, 53);
        temp39.m1("", (java.lang.Object) 100.0d, 3);
        temp32.m1("", (java.lang.Object) 100.0d, 135);
        temp0.m1("hi!", (java.lang.Object) temp32, 184);
        temp32.m1("", (java.lang.Object) 100.0f, 9);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass28);
    }

    @Test
    public void test524() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test524");
        Temp temp0 = new Temp();
        temp0.m1("", (java.lang.Object) 127, 95);
        temp0.m1("hi!", (java.lang.Object) 87, 179);
        java.lang.Class<?> wildcardClass9 = temp0.getClass();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass9);
    }

    @Test
    public void test525() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test525");
        Temp temp0 = new Temp();
        temp0.m1("", (java.lang.Object) 127, 95);
        temp0.m();
        Temp temp7 = new Temp();
        temp7.m1("", (java.lang.Object) 127, 95);
        temp7.m1("hi!", (java.lang.Object) 126, 22);
        temp7.m1("", (java.lang.Object) 157, 154);
        temp7.m();
        temp7.m1("hi!", (java.lang.Object) 10.0d, 124);
        temp0.m1("", (java.lang.Object) 124, (int) (byte) -1);
        Temp temp28 = new Temp();
        temp28.m();
        temp28.m1("", (java.lang.Object) 15, 141);
        temp0.m1("", (java.lang.Object) temp28, 190);
        temp0.m();
        java.lang.Class<?> wildcardClass37 = temp0.getClass();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass37);
    }

    @Test
    public void test526() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test526");
        Temp temp0 = new Temp();
        temp0.m1("", (java.lang.Object) 127, 95);
        temp0.m();
        temp0.m();
        temp0.m1("", (java.lang.Object) 81, 139);
        Temp temp12 = new Temp();
        temp12.m();
        temp12.m1("", (java.lang.Object) 15, 157);
        temp12.m1("hi!", (java.lang.Object) 21, 152);
        temp12.m1("hi!", (java.lang.Object) 53, 53);
        temp12.m();
        temp0.m1("hi!", (java.lang.Object) temp12, 133);
    }

    @Test
    public void test527() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test527");
        Temp temp0 = new Temp();
        temp0.m();
        temp0.m1("hi!", (java.lang.Object) 88, 94);
        temp0.m1("hi!", (java.lang.Object) 131, 98);
        temp0.m1("", (java.lang.Object) 13, 103);
        temp0.m1("hi!", (java.lang.Object) 131, 143);
        temp0.m1("", (java.lang.Object) 23, 113);
        CopyClassFile copyClassFile23 = new CopyClassFile();
        java.lang.Class<?> wildcardClass24 = copyClassFile23.getClass();
        temp0.m1("hi!", (java.lang.Object) wildcardClass24, 131);
        Temp temp28 = new Temp();
        temp28.m();
        temp28.m1("hi!", (java.lang.Object) 88, 94);
        temp28.m1("hi!", (java.lang.Object) 131, 98);
        temp28.m1("", (java.lang.Object) 13, 103);
        temp28.m1("hi!", (java.lang.Object) 131, 143);
        temp28.m1("", (java.lang.Object) 262144, 158);
        temp28.m();
        temp28.m1("hi!", (java.lang.Object) 11, 11);
        temp28.m();
        temp0.m1("hi!", (java.lang.Object) temp28, (int) (short) 10);
        java.lang.Class<?> wildcardClass58 = temp28.getClass();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass24);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass58);
    }

    @Test
    public void test528() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test528");
        Temp temp0 = new Temp();
        temp0.m1("hi!", (java.lang.Object) (short) 100, 120);
        temp0.m1("", (java.lang.Object) 172, 32768);
        temp0.m();
        Temp temp11 = new Temp();
        temp11.m();
        temp11.m1("", (java.lang.Object) 15, 141);
        temp11.m();
        temp11.m1("hi!", (java.lang.Object) 121, 170);
        temp0.m1("", (java.lang.Object) 170, 159);
        temp0.m();
    }

    @Test
    public void test529() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test529");
        Temp temp0 = new Temp();
        temp0.m1("", (java.lang.Object) 127, 95);
        temp0.m1("hi!", (java.lang.Object) 126, 22);
        temp0.m1("", (java.lang.Object) 157, 154);
        temp0.m();
        temp0.m1("hi!", (java.lang.Object) 10.0d, 124);
        temp0.m1("", (java.lang.Object) 176, 129);
        temp0.m();
    }

    @Test
    public void test530() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test530");
        Temp temp0 = new Temp();
        temp0.m1("", (java.lang.Object) 127, 95);
        temp0.m1("hi!", (java.lang.Object) 126, 22);
        temp0.m1("", (java.lang.Object) 157, 154);
        ExampleTransformed exampleTransformed14 = new ExampleTransformed();
        temp0.m1("hi!", (java.lang.Object) exampleTransformed14, 10);
        temp0.m1("", (java.lang.Object) 82, 105);
        temp0.m();
        temp0.m();
        Temp temp24 = new Temp();
        temp24.m();
        temp24.m1("", (java.lang.Object) 15, 157);
        temp24.m1("hi!", (java.lang.Object) 21, 152);
        temp24.m1("hi!", (java.lang.Object) 53, 53);
        temp24.m();
        java.lang.Class<?> wildcardClass39 = temp24.getClass();
        temp0.m1("hi!", (java.lang.Object) wildcardClass39, 114);
        java.lang.Class<?> wildcardClass42 = temp0.getClass();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass39);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass42);
    }

    @Test
    public void test531() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test531");
        Temp temp0 = new Temp();
        temp0.m1("", (java.lang.Object) 127, 95);
        temp0.m1("hi!", (java.lang.Object) 126, 22);
        temp0.m();
        temp0.m();
        temp0.m();
    }

    @Test
    public void test532() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test532");
        GenerateClassFile generateClassFile0 = new GenerateClassFile();
        java.lang.Class<?> wildcardClass1 = generateClassFile0.getClass();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass1);
    }

    @Test
    public void test533() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test533");
        Temp temp0 = new Temp();
        temp0.m1("", (java.lang.Object) 127, 95);
        temp0.m();
        temp0.m();
        temp0.m();
        Temp temp9 = new Temp();
        temp9.m1("", (java.lang.Object) 127, 95);
        temp9.m();
        temp9.m();
        temp9.m();
        temp0.m1("", (java.lang.Object) temp9, 186);
        Temp temp20 = new Temp();
        temp20.m();
        temp20.m1("hi!", (java.lang.Object) 88, 94);
        temp20.m1("hi!", (java.lang.Object) 131, 98);
        temp20.m1("", (java.lang.Object) 13, 103);
        temp20.m1("hi!", (java.lang.Object) 131, 143);
        temp20.m1("", (java.lang.Object) 195, 118);
        temp20.m1("", (java.lang.Object) 96, 88);
        temp20.m();
        temp20.m1("", (java.lang.Object) 46, 262144);
        temp20.m1("hi!", (java.lang.Object) 46, 46);
        temp9.m1("hi!", (java.lang.Object) 46, 141);
        Generated generated58 = new Generated();
        java.lang.Class<?> wildcardClass59 = generated58.getClass();
        temp9.m1("hi!", (java.lang.Object) generated58, 145);
        temp9.m();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass59);
    }

    @Test
    public void test534() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test534");
        Temp temp0 = new Temp();
        temp0.m1("", (java.lang.Object) 127, 95);
        temp0.m();
        temp0.m();
        temp0.m();
        Temp temp9 = new Temp();
        temp9.m1("", (java.lang.Object) 127, 95);
        temp9.m();
        temp9.m();
        temp9.m();
        temp0.m1("", (java.lang.Object) temp9, 186);
        Temp temp20 = new Temp();
        temp20.m();
        temp20.m1("hi!", (java.lang.Object) 88, 94);
        temp20.m1("hi!", (java.lang.Object) 131, 98);
        temp20.m1("", (java.lang.Object) 13, 103);
        temp20.m1("hi!", (java.lang.Object) 131, 143);
        temp20.m1("", (java.lang.Object) 195, 118);
        temp20.m1("", (java.lang.Object) 96, 88);
        temp20.m();
        temp20.m1("", (java.lang.Object) 46, 262144);
        temp20.m1("hi!", (java.lang.Object) 46, 46);
        temp9.m1("hi!", (java.lang.Object) 46, 141);
        Generated generated58 = new Generated();
        java.lang.Class<?> wildcardClass59 = generated58.getClass();
        temp9.m1("hi!", (java.lang.Object) generated58, 145);
        java.lang.Class<?> wildcardClass62 = generated58.getClass();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass59);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass62);
    }

    @Test
    public void test535() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test535");
        Temp temp0 = new Temp();
        temp0.m();
        temp0.m1("hi!", (java.lang.Object) 88, 94);
        temp0.m1("hi!", (java.lang.Object) 131, 98);
        temp0.m1("", (java.lang.Object) 13, 103);
        temp0.m1("hi!", (java.lang.Object) 131, 143);
        temp0.m1("", (java.lang.Object) 195, 118);
        Temp temp23 = new Temp();
        temp23.m1("", (java.lang.Object) 127, 95);
        temp23.m1("hi!", (java.lang.Object) 126, 22);
        temp23.m1("", (java.lang.Object) 157, 154);
        temp23.m();
        temp23.m();
        temp23.m();
        temp23.m1("hi!", (java.lang.Object) 172, 112);
        temp23.m();
        temp0.m1("", (java.lang.Object) temp23, (-65536));
        temp0.m();
        temp0.m1("", (java.lang.Object) 32, 110);
        java.lang.Class<?> wildcardClass51 = temp0.getClass();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass51);
    }

    @Test
    public void test536() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test536");
        Temp temp0 = new Temp();
        temp0.m1("", (java.lang.Object) 127, 95);
        temp0.m1("hi!", (java.lang.Object) 126, 22);
        temp0.m1("", (java.lang.Object) 157, 154);
        temp0.m();
        temp0.m();
        temp0.m1("", (java.lang.Object) 11, 136);
        Temp temp20 = new Temp();
        temp20.m();
        temp20.m1("hi!", (java.lang.Object) 88, 94);
        temp20.m1("hi!", (java.lang.Object) 131, 98);
        temp20.m1("", (java.lang.Object) 13, 103);
        temp20.m1("hi!", (java.lang.Object) 131, 143);
        temp20.m1("hi!", (java.lang.Object) 161, 132);
        temp20.m();
        temp20.m();
        temp0.m1("", (java.lang.Object) temp20, 79);
        Temp temp47 = new Temp();
        temp47.m();
        temp47.m1("hi!", (java.lang.Object) 88, 94);
        temp47.m1("hi!", (java.lang.Object) 131, 98);
        temp47.m1("", (java.lang.Object) 13, 103);
        temp47.m1("hi!", (java.lang.Object) 131, 143);
        temp47.m1("", (java.lang.Object) 195, 118);
        java.lang.Object obj70 = null;
        temp47.m1("", obj70, 58);
        java.lang.Class<?> wildcardClass73 = temp47.getClass();
        temp20.m1("hi!", (java.lang.Object) temp47, 161);
        java.lang.Class<?> wildcardClass76 = temp20.getClass();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass73);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass76);
    }

    @Test
    public void test537() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test537");
        Temp temp0 = new Temp();
        temp0.m();
        temp0.m1("hi!", (java.lang.Object) 88, 94);
        temp0.m1("hi!", (java.lang.Object) 131, 98);
        temp0.m1("", (java.lang.Object) 13, 103);
        temp0.m1("hi!", (java.lang.Object) 131, 143);
        temp0.m1("hi!", (java.lang.Object) 161, 132);
        temp0.m1("", (java.lang.Object) 130, 193);
        temp0.m();
        temp0.m();
        java.lang.Class<?> wildcardClass28 = temp0.getClass();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass28);
    }

    @Test
    public void test538() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test538");
        Temp temp0 = new Temp();
        temp0.m();
        temp0.m1("hi!", (java.lang.Object) 88, 94);
        temp0.m1("hi!", (java.lang.Object) 131, 98);
        temp0.m1("", (java.lang.Object) 13, 103);
        temp0.m1("hi!", (java.lang.Object) 131, 143);
        temp0.m1("hi!", (java.lang.Object) 161, 132);
        temp0.m();
        Temp temp24 = new Temp();
        temp24.m();
        temp24.m1("", (java.lang.Object) 15, 141);
        temp0.m1("hi!", (java.lang.Object) 15, 199);
        temp0.m();
        temp0.m();
        Temp temp35 = new Temp();
        temp35.m1("", (java.lang.Object) 127, 95);
        temp35.m1("hi!", (java.lang.Object) 126, 22);
        temp35.m1("", (java.lang.Object) 157, 154);
        ExampleTransformed exampleTransformed49 = new ExampleTransformed();
        temp35.m1("hi!", (java.lang.Object) exampleTransformed49, 10);
        temp35.m();
        temp35.m1("hi!", (java.lang.Object) 256, 51);
        temp35.m();
        temp35.m1("", (java.lang.Object) 2048, 1);
        temp35.m();
        temp0.m1("hi!", (java.lang.Object) temp35, 85);
        java.lang.Object obj66 = null;
        temp0.m1("hi!", obj66, 2048);
    }

    @Test
    public void test539() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test539");
        Temp temp0 = new Temp();
        temp0.m();
        temp0.m1("hi!", (java.lang.Object) 88, 94);
        temp0.m1("hi!", (java.lang.Object) 131, 98);
        temp0.m1("", (java.lang.Object) 13, 103);
        temp0.m1("hi!", (java.lang.Object) 131, 143);
        temp0.m1("hi!", (java.lang.Object) 161, 132);
        temp0.m();
        temp0.m();
        temp0.m1("hi!", (java.lang.Object) 155, 83);
        Temp temp29 = new Temp();
        temp29.m1("", (java.lang.Object) 127, 95);
        temp29.m();
        Temp temp36 = new Temp();
        temp36.m();
        temp36.m1("hi!", (java.lang.Object) 88, 94);
        temp36.m1("hi!", (java.lang.Object) 131, 98);
        temp36.m1("", (java.lang.Object) 13, 103);
        temp29.m1("", (java.lang.Object) temp36, 131);
        temp29.m1("", (java.lang.Object) 176, 183);
        Temp temp57 = new Temp();
        temp57.m();
        temp57.m1("hi!", (java.lang.Object) 88, 94);
        temp57.m1("hi!", (java.lang.Object) 131, 98);
        temp57.m1("", (java.lang.Object) 13, 103);
        Temp temp72 = new Temp();
        temp72.m1("", (java.lang.Object) 127, 95);
        temp72.m1("hi!", (java.lang.Object) 126, 22);
        temp72.m1("", (java.lang.Object) 157, 154);
        temp72.m();
        temp72.m1("", (java.lang.Object) 161, 0);
        temp57.m1("hi!", (java.lang.Object) "", 86);
        temp29.m1("hi!", (java.lang.Object) 86, 2048);
        java.lang.Class<?> wildcardClass94 = temp29.getClass();
        temp0.m1("hi!", (java.lang.Object) wildcardClass94, 7);
        temp0.m();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass94);
    }

    @Test
    public void test540() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test540");
        Temp temp0 = new Temp();
        temp0.m1("", (java.lang.Object) 127, 95);
        temp0.m1("hi!", (java.lang.Object) 126, 22);
        temp0.m1("", (java.lang.Object) 157, 154);
        ExampleTransformed exampleTransformed14 = new ExampleTransformed();
        temp0.m1("hi!", (java.lang.Object) exampleTransformed14, 10);
        temp0.m();
        java.lang.Object obj19 = null;
        temp0.m1("hi!", obj19, 182);
        java.lang.Class<?> wildcardClass22 = temp0.getClass();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass22);
    }

    @Test
    public void test541() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test541");
        Temp temp0 = new Temp();
        temp0.m1("", (java.lang.Object) 127, 95);
        temp0.m1("hi!", (java.lang.Object) 126, 22);
        temp0.m1("", (java.lang.Object) 157, 154);
        ExampleTransformed exampleTransformed14 = new ExampleTransformed();
        temp0.m1("hi!", (java.lang.Object) exampleTransformed14, 10);
        temp0.m();
        temp0.m1("hi!", (java.lang.Object) 256, 51);
        temp0.m();
        temp0.m1("", (java.lang.Object) 2048, 1);
        temp0.m();
        temp0.m();
        temp0.m();
        temp0.m();
    }

    @Test
    public void test542() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test542");
        Temp temp0 = new Temp();
        temp0.m();
        temp0.m1("hi!", (java.lang.Object) 88, 94);
        temp0.m1("hi!", (java.lang.Object) 131, 98);
        temp0.m1("", (java.lang.Object) 13, 103);
        temp0.m1("hi!", (java.lang.Object) 131, 143);
        temp0.m1("hi!", (java.lang.Object) 161, 132);
        temp0.m();
        temp0.m1("", (java.lang.Object) 171, 2);
        Temp temp28 = new Temp();
        temp28.m();
        temp28.m1("hi!", (java.lang.Object) 88, 94);
        temp28.m1("hi!", (java.lang.Object) 131, 98);
        temp28.m1("", (java.lang.Object) 13, 103);
        temp28.m1("hi!", (java.lang.Object) 131, 143);
        temp28.m1("hi!", (java.lang.Object) 161, 132);
        temp0.m1("hi!", (java.lang.Object) temp28, 56);
        Temp temp53 = new Temp();
        temp53.m();
        temp53.m1("hi!", (java.lang.Object) 88, 94);
        temp53.m1("hi!", (java.lang.Object) 131, 98);
        temp53.m1("", (java.lang.Object) 13, 103);
        temp53.m1("hi!", (java.lang.Object) 131, 143);
        temp53.m1("", (java.lang.Object) 195, 118);
        temp53.m1("", (java.lang.Object) 96, 88);
        temp28.m1("", (java.lang.Object) temp53, 143);
        temp28.m();
        temp28.m();
    }

    @Test
    public void test543() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test543");
        Temp temp0 = new Temp();
        temp0.m1("", (java.lang.Object) 127, 95);
        temp0.m();
        Temp temp7 = new Temp();
        temp7.m();
        temp7.m1("hi!", (java.lang.Object) 88, 94);
        temp7.m1("hi!", (java.lang.Object) 131, 98);
        temp7.m1("", (java.lang.Object) 13, 103);
        temp0.m1("", (java.lang.Object) temp7, 131);
        temp0.m1("", (java.lang.Object) 176, 183);
        Temp temp28 = new Temp();
        temp28.m1("", (java.lang.Object) 127, 95);
        temp28.m1("hi!", (java.lang.Object) 126, 22);
        temp28.m1("", (java.lang.Object) 157, 154);
        temp28.m();
        temp28.m();
        temp28.m();
        temp28.m1("hi!", (java.lang.Object) 172, 112);
        temp28.m();
        temp0.m1("hi!", (java.lang.Object) temp28, 15);
        java.lang.Class<?> wildcardClass51 = temp28.getClass();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass51);
    }

    @Test
    public void test544() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test544");
        Temp temp0 = new Temp();
        temp0.m1("", (java.lang.Object) 127, 95);
        temp0.m();
        Temp temp7 = new Temp();
        temp7.m();
        temp7.m1("hi!", (java.lang.Object) 88, 94);
        temp7.m1("hi!", (java.lang.Object) 131, 98);
        temp7.m1("", (java.lang.Object) 13, 103);
        temp0.m1("", (java.lang.Object) temp7, 131);
        temp0.m1("", (java.lang.Object) 135, 115);
        temp0.m();
        temp0.m();
        temp0.m();
        Temp temp31 = new Temp();
        temp31.m1("", (java.lang.Object) 127, 95);
        temp31.m();
        temp31.m();
        temp31.m();
        temp31.m1("", (java.lang.Object) 176, (int) '#');
        temp31.m();
        temp31.m();
        temp31.m();
        temp0.m1("", (java.lang.Object) temp31, 0);
        java.lang.Class<?> wildcardClass48 = temp31.getClass();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass48);
    }

    @Test
    public void test545() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test545");
        Temp temp0 = new Temp();
        temp0.m1("", (java.lang.Object) 127, 95);
        temp0.m();
        temp0.m1("", (java.lang.Object) 1.0d, 130);
        Temp temp11 = new Temp();
        temp11.m();
        temp11.m1("hi!", (java.lang.Object) 88, 94);
        temp11.m1("hi!", (java.lang.Object) 131, 98);
        temp11.m1("", (java.lang.Object) 147, (-65536));
        temp11.m1("hi!", (java.lang.Object) 12, 181);
        temp11.m();
        temp0.m1("", (java.lang.Object) temp11, 512);
        java.lang.Class<?> wildcardClass32 = temp11.getClass();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass32);
    }

    @Test
    public void test546() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test546");
        Temp temp0 = new Temp();
        temp0.m();
        temp0.m1("hi!", (java.lang.Object) 88, 94);
        temp0.m1("hi!", (java.lang.Object) 131, 98);
        temp0.m1("", (java.lang.Object) 13, 103);
        temp0.m1("hi!", (java.lang.Object) 131, 143);
        temp0.m1("", (java.lang.Object) 195, 0);
        temp0.m();
        Temp temp24 = new Temp();
        temp24.m1("", (java.lang.Object) 127, 95);
        temp24.m();
        temp24.m();
        temp24.m1("", (java.lang.Object) 81, 139);
        java.lang.Object obj36 = null;
        temp24.m1("", obj36, 7);
        temp0.m1("", (java.lang.Object) temp24, (int) (byte) -1);
        temp24.m();
        temp24.m();
        temp24.m1("", (java.lang.Object) 1024, 1024);
    }

    @Test
    public void test547() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test547");
        Temp temp0 = new Temp();
        temp0.m1("", (java.lang.Object) 127, 95);
        temp0.m1("hi!", (java.lang.Object) 126, 22);
        temp0.m();
        Temp temp11 = new Temp();
        temp11.m1("", (java.lang.Object) 127, 95);
        temp11.m1("hi!", (java.lang.Object) 126, 22);
        temp11.m1("", (java.lang.Object) 157, 154);
        ExampleTransformed exampleTransformed25 = new ExampleTransformed();
        temp11.m1("hi!", (java.lang.Object) exampleTransformed25, 10);
        temp11.m();
        temp11.m();
        Temp temp31 = new Temp();
        temp31.m();
        temp31.m1("hi!", (java.lang.Object) 88, 94);
        temp31.m1("hi!", (java.lang.Object) 131, 98);
        temp31.m1("", (java.lang.Object) 13, 103);
        java.lang.Class<?> wildcardClass45 = temp31.getClass();
        temp11.m1("hi!", (java.lang.Object) temp31, 137);
        temp11.m();
        Temp temp50 = new Temp();
        temp50.m1("", (java.lang.Object) 127, 95);
        temp50.m();
        Example example57 = new Example();
        java.lang.Class<?> wildcardClass58 = example57.getClass();
        temp50.m1("", (java.lang.Object) wildcardClass58, 166);
        temp11.m1("", (java.lang.Object) temp50, 90);
        temp0.m1("", (java.lang.Object) temp50, 86);
        Temp temp66 = new Temp();
        temp66.m();
        temp66.m1("hi!", (java.lang.Object) 88, 94);
        temp66.m1("hi!", (java.lang.Object) 131, 98);
        temp66.m1("", (java.lang.Object) 13, 103);
        temp66.m1("hi!", (java.lang.Object) 131, 143);
        temp66.m1("", (java.lang.Object) 262144, 158);
        temp66.m();
        temp66.m1("", (java.lang.Object) false, 22);
        temp50.m1("", (java.lang.Object) temp66, 124);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass45);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass58);
    }

    @Test
    public void test548() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test548");
        Temp temp0 = new Temp();
        temp0.m();
        temp0.m1("hi!", (java.lang.Object) 88, 94);
        temp0.m1("hi!", (java.lang.Object) 131, 98);
        temp0.m1("", (java.lang.Object) 13, 103);
        temp0.m1("hi!", (java.lang.Object) 131, 143);
        temp0.m1("hi!", (java.lang.Object) 161, 132);
        temp0.m1("hi!", (java.lang.Object) 164, 180);
    }

    @Test
    public void test549() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test549");
        Temp temp0 = new Temp();
        temp0.m();
        temp0.m1("hi!", (java.lang.Object) 88, 94);
        temp0.m1("hi!", (java.lang.Object) 131, 98);
        temp0.m1("", (java.lang.Object) 13, 103);
        temp0.m1("hi!", (java.lang.Object) 131, 143);
        temp0.m1("", (java.lang.Object) 262144, 158);
        temp0.m();
        temp0.m1("hi!", (java.lang.Object) 161, 85);
        Temp temp28 = new Temp();
        temp28.m();
        temp28.m1("hi!", (java.lang.Object) 88, 94);
        temp28.m1("hi!", (java.lang.Object) 131, 98);
        temp28.m1("", (java.lang.Object) 13, 103);
        Temp temp43 = new Temp();
        temp43.m1("", (java.lang.Object) 127, 95);
        temp43.m1("hi!", (java.lang.Object) 126, 22);
        temp43.m1("", (java.lang.Object) 157, 154);
        temp43.m();
        temp43.m1("", (java.lang.Object) 161, 0);
        temp28.m1("hi!", (java.lang.Object) "", 86);
        java.lang.Class<?> wildcardClass63 = temp28.getClass();
        temp0.m1("hi!", (java.lang.Object) wildcardClass63, 15);
        Temp temp67 = new Temp();
        temp67.m1("", (java.lang.Object) 127, 95);
        temp67.m1("hi!", (java.lang.Object) 126, 22);
        temp67.m1("", (java.lang.Object) 157, 154);
        ExampleTransformed exampleTransformed81 = new ExampleTransformed();
        temp67.m1("hi!", (java.lang.Object) exampleTransformed81, 10);
        temp67.m();
        temp67.m1("hi!", (java.lang.Object) 256, 51);
        temp67.m();
        temp67.m1("", (java.lang.Object) 2048, 1);
        temp67.m();
        java.lang.Class<?> wildcardClass95 = temp67.getClass();
        temp0.m1("", (java.lang.Object) wildcardClass95, 193);
        java.lang.Class<?> wildcardClass98 = temp0.getClass();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass63);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass95);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass98);
    }

    @Test
    public void test550() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test550");
        Temp temp0 = new Temp();
        temp0.m();
        temp0.m1("hi!", (java.lang.Object) 88, 94);
        temp0.m1("hi!", (java.lang.Object) 131, 98);
        temp0.m1("", (java.lang.Object) 13, 103);
        temp0.m1("hi!", (java.lang.Object) 131, 143);
        temp0.m1("", (java.lang.Object) 195, 118);
        java.lang.Object obj23 = null;
        temp0.m1("", obj23, 58);
        Temp temp27 = new Temp();
        temp27.m1("", (java.lang.Object) 127, 95);
        temp27.m1("hi!", (java.lang.Object) 126, 22);
        temp27.m1("", (java.lang.Object) 152, 199);
        temp27.m();
        temp0.m1("", (java.lang.Object) temp27, 50);
        java.lang.Class<?> wildcardClass43 = temp0.getClass();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass43);
    }

    @Test
    public void test551() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test551");
        Temp temp0 = new Temp();
        temp0.m();
        temp0.m1("hi!", (java.lang.Object) 88, 94);
        temp0.m1("hi!", (java.lang.Object) 131, 98);
        temp0.m1("", (java.lang.Object) 13, 103);
        temp0.m1("hi!", (java.lang.Object) 131, 143);
        temp0.m1("", (java.lang.Object) 23, 113);
        Temp temp23 = new Temp();
        temp23.m1("", (java.lang.Object) 127, 95);
        temp23.m1("hi!", (java.lang.Object) 126, 22);
        temp23.m1("", (java.lang.Object) 157, 154);
        ExampleTransformed exampleTransformed37 = new ExampleTransformed();
        temp23.m1("hi!", (java.lang.Object) exampleTransformed37, 10);
        temp23.m();
        temp23.m1("hi!", (java.lang.Object) 256, 51);
        temp23.m();
        temp23.m();
        temp23.m();
        temp0.m1("hi!", (java.lang.Object) temp23, 161);
        temp23.m();
        Temp temp52 = new Temp();
        temp52.m();
        temp52.m1("", (java.lang.Object) 15, 141);
        temp52.m();
        temp52.m1("hi!", (java.lang.Object) 121, 170);
        temp23.m1("", (java.lang.Object) "hi!", 171);
        temp23.m1("", (java.lang.Object) 118, 131);
    }

    @Test
    public void test552() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test552");
        Temp temp0 = new Temp();
        temp0.m();
        temp0.m1("hi!", (java.lang.Object) 88, 94);
        temp0.m1("hi!", (java.lang.Object) 131, 98);
        temp0.m1("", (java.lang.Object) 13, 103);
        temp0.m1("hi!", (java.lang.Object) 131, 143);
        temp0.m1("", (java.lang.Object) 195, 118);
        Temp temp23 = new Temp();
        temp23.m();
        temp23.m1("hi!", (java.lang.Object) 88, 94);
        temp23.m1("hi!", (java.lang.Object) 131, 98);
        temp23.m1("", (java.lang.Object) 13, 103);
        temp23.m1("hi!", (java.lang.Object) 131, 143);
        temp23.m1("", (java.lang.Object) 23, 113);
        CopyClassFile copyClassFile46 = new CopyClassFile();
        java.lang.Class<?> wildcardClass47 = copyClassFile46.getClass();
        temp23.m1("hi!", (java.lang.Object) wildcardClass47, 131);
        temp23.m();
        temp23.m1("", (java.lang.Object) 121, (int) (byte) 10);
        temp0.m1("hi!", (java.lang.Object) temp23, 11);
        Temp temp58 = new Temp();
        temp58.m();
        temp58.m1("hi!", (java.lang.Object) 88, 94);
        temp58.m1("hi!", (java.lang.Object) 131, 98);
        temp58.m1("", (java.lang.Object) 13, 103);
        Temp temp73 = new Temp();
        temp73.m1("", (java.lang.Object) 127, 95);
        temp73.m1("hi!", (java.lang.Object) 126, 22);
        temp73.m1("", (java.lang.Object) 157, 154);
        java.lang.Class<?> wildcardClass86 = temp73.getClass();
        temp58.m1("", (java.lang.Object) temp73, 180);
        temp58.m();
        temp58.m();
        temp0.m1("hi!", (java.lang.Object) temp58, 0);
        java.lang.Class<?> wildcardClass93 = temp0.getClass();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass47);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass86);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass93);
    }

    @Test
    public void test553() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test553");
        Temp temp0 = new Temp();
        temp0.m();
        temp0.m1("hi!", (java.lang.Object) 88, 94);
        temp0.m1("hi!", (java.lang.Object) 131, 98);
        temp0.m1("", (java.lang.Object) 13, 103);
        temp0.m1("hi!", (java.lang.Object) 131, 143);
        temp0.m1("", (java.lang.Object) 23, 113);
        Temp temp23 = new Temp();
        temp23.m1("", (java.lang.Object) 127, 95);
        temp23.m1("hi!", (java.lang.Object) 126, 22);
        temp23.m1("", (java.lang.Object) 157, 154);
        ExampleTransformed exampleTransformed37 = new ExampleTransformed();
        temp23.m1("hi!", (java.lang.Object) exampleTransformed37, 10);
        temp23.m();
        temp23.m1("hi!", (java.lang.Object) 256, 51);
        temp23.m();
        temp23.m();
        temp23.m();
        temp0.m1("hi!", (java.lang.Object) temp23, 161);
        temp0.m();
    }

    @Test
    public void test554() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test554");
        Temp temp0 = new Temp();
        temp0.m();
        temp0.m1("", (java.lang.Object) 15, 157);
        temp0.m1("hi!", (java.lang.Object) 21, 152);
        temp0.m();
        temp0.m1("hi!", (java.lang.Object) 32, 104);
        temp0.m();
    }

    @Test
    public void test555() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test555");
        Temp temp0 = new Temp();
        temp0.m();
        temp0.m1("hi!", (java.lang.Object) 88, 94);
        temp0.m1("hi!", (java.lang.Object) 131, 98);
        temp0.m1("", (java.lang.Object) 13, 103);
        temp0.m1("hi!", (java.lang.Object) 131, 143);
        temp0.m1("", (java.lang.Object) 23, 113);
        Temp temp23 = new Temp();
        temp23.m1("", (java.lang.Object) 127, 95);
        temp23.m1("hi!", (java.lang.Object) 126, 22);
        temp23.m1("", (java.lang.Object) 157, 154);
        ExampleTransformed exampleTransformed37 = new ExampleTransformed();
        temp23.m1("hi!", (java.lang.Object) exampleTransformed37, 10);
        temp23.m();
        temp23.m1("hi!", (java.lang.Object) 256, 51);
        temp23.m();
        temp23.m();
        temp23.m();
        temp0.m1("hi!", (java.lang.Object) temp23, 161);
        Temp temp51 = new Temp();
        temp51.m1("", (java.lang.Object) 127, 95);
        temp51.m();
        temp51.m1("", (java.lang.Object) 1.0d, 130);
        temp51.m();
        Temp temp63 = new Temp();
        temp63.m1("", (java.lang.Object) 127, 95);
        temp63.m1("hi!", (java.lang.Object) 126, 22);
        temp63.m1("", (java.lang.Object) 157, 154);
        ExampleTransformed exampleTransformed77 = new ExampleTransformed();
        temp63.m1("hi!", (java.lang.Object) exampleTransformed77, 10);
        temp63.m();
        temp63.m1("hi!", (java.lang.Object) 256, 51);
        temp63.m();
        temp63.m1("", (java.lang.Object) 2048, 1);
        temp63.m1("hi!", (java.lang.Object) 14, 128);
        temp51.m1("", (java.lang.Object) temp63, 103);
        temp23.m1("", (java.lang.Object) temp63, 54);
        temp63.m();
    }

    @Test
    public void test556() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test556");
        Temp temp0 = new Temp();
        temp0.m1("", (java.lang.Object) 127, 95);
        temp0.m1("hi!", (java.lang.Object) 126, 22);
        temp0.m1("", (java.lang.Object) 157, 154);
        temp0.m();
        temp0.m();
        temp0.m();
        temp0.m();
        Temp temp18 = new Temp();
        temp18.m1("", (java.lang.Object) 127, 95);
        temp18.m1("hi!", (java.lang.Object) 126, 22);
        temp18.m1("", (java.lang.Object) 157, 154);
        ExampleTransformed exampleTransformed32 = new ExampleTransformed();
        temp18.m1("hi!", (java.lang.Object) exampleTransformed32, 10);
        temp18.m();
        temp18.m1("hi!", (java.lang.Object) 256, 51);
        temp18.m();
        temp18.m1("", (java.lang.Object) 2048, 1);
        temp18.m1("hi!", (java.lang.Object) 14, 128);
        temp18.m1("", (java.lang.Object) 146, 118);
        Temp temp54 = new Temp();
        temp54.m();
        temp54.m1("hi!", (java.lang.Object) 88, 94);
        temp54.m();
        temp18.m1("", (java.lang.Object) temp54, 84);
        temp0.m1("", (java.lang.Object) 84, 193);
    }

    @Test
    public void test557() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test557");
        Temp temp0 = new Temp();
        temp0.m1("", (java.lang.Object) 127, 95);
        temp0.m1("hi!", (java.lang.Object) 126, 22);
        temp0.m1("", (java.lang.Object) 157, 154);
        ExampleTransformed exampleTransformed14 = new ExampleTransformed();
        temp0.m1("hi!", (java.lang.Object) exampleTransformed14, 10);
        temp0.m();
        temp0.m1("hi!", (java.lang.Object) 256, 51);
        temp0.m();
        temp0.m1("", (java.lang.Object) 2048, 1);
        temp0.m1("hi!", (java.lang.Object) 14, 128);
        temp0.m1("", (java.lang.Object) 146, 118);
        Temp temp36 = new Temp();
        temp36.m();
        temp36.m1("hi!", (java.lang.Object) 88, 94);
        temp36.m();
        temp0.m1("", (java.lang.Object) temp36, 84);
        temp0.m1("hi!", (java.lang.Object) 94, 125);
        Generated generated50 = new Generated();
        temp0.m1("", (java.lang.Object) generated50, 178);
    }

    @Test
    public void test558() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test558");
        Temp temp0 = new Temp();
        temp0.m1("", (java.lang.Object) 127, 95);
        temp0.m();
        temp0.m();
        temp0.m();
        Temp temp9 = new Temp();
        temp9.m();
        temp9.m1("hi!", (java.lang.Object) 88, 94);
        temp9.m1("hi!", (java.lang.Object) 131, 98);
        temp9.m1("", (java.lang.Object) 13, 103);
        temp9.m1("hi!", (java.lang.Object) 131, 143);
        temp9.m1("", (java.lang.Object) 262144, 158);
        temp9.m();
        temp9.m1("hi!", (java.lang.Object) 161, 85);
        Temp temp37 = new Temp();
        temp37.m1("", (java.lang.Object) 127, 95);
        temp37.m1("hi!", (java.lang.Object) 126, 22);
        temp37.m1("", (java.lang.Object) 157, 154);
        ExampleTransformed exampleTransformed51 = new ExampleTransformed();
        temp37.m1("hi!", (java.lang.Object) exampleTransformed51, 10);
        temp37.m();
        temp37.m();
        Temp temp57 = new Temp();
        temp57.m();
        temp57.m1("hi!", (java.lang.Object) 88, 94);
        temp57.m1("hi!", (java.lang.Object) 131, 98);
        temp57.m1("", (java.lang.Object) 13, 103);
        java.lang.Class<?> wildcardClass71 = temp57.getClass();
        temp37.m1("hi!", (java.lang.Object) temp57, 137);
        temp37.m();
        temp9.m1("hi!", (java.lang.Object) temp37, 4096);
        temp0.m1("", (java.lang.Object) 4096, 183);
        java.lang.Class<?> wildcardClass79 = temp0.getClass();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass71);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass79);
    }

    @Test
    public void test559() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test559");
        Temp temp0 = new Temp();
        temp0.m();
        temp0.m1("", (java.lang.Object) 15, 157);
        temp0.m1("hi!", (java.lang.Object) 21, 152);
        temp0.m();
        temp0.m();
        temp0.m();
        Temp temp14 = new Temp();
        temp14.m();
        temp14.m1("hi!", (java.lang.Object) 88, 94);
        temp14.m1("hi!", (java.lang.Object) 131, 98);
        temp14.m1("", (java.lang.Object) 13, 103);
        temp14.m();
        temp14.m();
        temp0.m1("hi!", (java.lang.Object) temp14, (-1));
        java.lang.Class<?> wildcardClass32 = temp14.getClass();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass32);
    }

    @Test
    public void test560() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test560");
        Temp temp0 = new Temp();
        temp0.m();
        temp0.m1("", (java.lang.Object) 15, 157);
        temp0.m1("hi!", (java.lang.Object) 21, 152);
        temp0.m();
        temp0.m1("hi!", (java.lang.Object) 32, 104);
        java.lang.Class<?> wildcardClass15 = temp0.getClass();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass15);
    }

    @Test
    public void test561() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test561");
        Temp temp0 = new Temp();
        temp0.m1("", (java.lang.Object) 127, 95);
        temp0.m();
        Temp temp7 = new Temp();
        temp7.m();
        temp7.m1("hi!", (java.lang.Object) 88, 94);
        temp7.m1("hi!", (java.lang.Object) 131, 98);
        temp7.m1("", (java.lang.Object) 13, 103);
        temp0.m1("", (java.lang.Object) temp7, 131);
        temp0.m1("", (java.lang.Object) 135, 115);
        temp0.m();
        temp0.m();
        temp0.m();
        temp0.m();
    }

    @Test
    public void test562() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test562");
        Temp temp0 = new Temp();
        temp0.m1("", (java.lang.Object) 127, 95);
        temp0.m1("hi!", (java.lang.Object) 126, 22);
        temp0.m1("hi!", (java.lang.Object) 85, 174);
        Temp temp14 = new Temp();
        temp14.m();
        temp14.m1("hi!", (java.lang.Object) 88, 94);
        temp14.m1("hi!", (java.lang.Object) 131, 98);
        temp14.m1("", (java.lang.Object) 13, 103);
        temp14.m1("hi!", (java.lang.Object) 131, 143);
        temp14.m1("", (java.lang.Object) 195, 0);
        temp14.m();
        java.lang.Class<?> wildcardClass37 = temp14.getClass();
        temp0.m1("hi!", (java.lang.Object) temp14, 128);
        Temp temp41 = new Temp();
        temp41.m();
        temp41.m1("", (java.lang.Object) 15, 157);
        temp41.m1("hi!", (java.lang.Object) 21, 152);
        temp41.m();
        temp41.m();
        temp41.m();
        Temp temp55 = new Temp();
        temp55.m();
        temp55.m1("hi!", (java.lang.Object) 88, 94);
        temp55.m1("hi!", (java.lang.Object) 131, 98);
        temp55.m1("", (java.lang.Object) 13, 103);
        temp55.m();
        temp55.m();
        temp41.m1("hi!", (java.lang.Object) temp55, (-1));
        temp0.m1("hi!", (java.lang.Object) temp41, 16);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass37);
    }

    @Test
    public void test563() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test563");
        Temp temp0 = new Temp();
        temp0.m1("", (java.lang.Object) 127, 95);
        temp0.m();
        temp0.m1("", (java.lang.Object) 1.0d, 130);
        temp0.m();
        Temp temp12 = new Temp();
        temp12.m();
        temp12.m1("hi!", (java.lang.Object) 88, 94);
        temp12.m1("hi!", (java.lang.Object) 131, 98);
        temp12.m1("", (java.lang.Object) 13, 103);
        temp12.m1("hi!", (java.lang.Object) 131, 143);
        temp12.m1("", (java.lang.Object) 23, 113);
        Temp temp35 = new Temp();
        temp35.m1("", (java.lang.Object) 127, 95);
        temp35.m1("hi!", (java.lang.Object) 126, 22);
        temp35.m1("", (java.lang.Object) 157, 154);
        ExampleTransformed exampleTransformed49 = new ExampleTransformed();
        temp35.m1("hi!", (java.lang.Object) exampleTransformed49, 10);
        temp35.m();
        temp35.m1("hi!", (java.lang.Object) 256, 51);
        temp35.m();
        temp35.m();
        temp35.m();
        temp12.m1("hi!", (java.lang.Object) temp35, 161);
        java.lang.Class<?> wildcardClass62 = temp12.getClass();
        temp0.m1("hi!", (java.lang.Object) wildcardClass62, 6);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass62);
    }

    @Test
    public void test564() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test564");
        Temp temp0 = new Temp();
        temp0.m1("", (java.lang.Object) 127, 95);
        temp0.m();
        temp0.m();
        Temp temp8 = new Temp();
        temp8.m();
        temp8.m1("hi!", (java.lang.Object) 88, 94);
        temp8.m1("hi!", (java.lang.Object) 131, 98);
        temp8.m1("", (java.lang.Object) 13, 103);
        temp8.m1("hi!", (java.lang.Object) 131, 143);
        temp8.m1("", (java.lang.Object) 23, 113);
        java.lang.Object obj31 = null;
        temp8.m1("hi!", obj31, 58);
        temp0.m1("", (java.lang.Object) temp8, 256);
        temp0.m();
        temp0.m();
        temp0.m1("hi!", (java.lang.Object) 105, 137);
        Temp temp43 = new Temp();
        temp43.m1("", (java.lang.Object) 127, 95);
        temp43.m();
        Example example50 = new Example();
        java.lang.Class<?> wildcardClass51 = example50.getClass();
        temp43.m1("", (java.lang.Object) wildcardClass51, 166);
        temp0.m1("", (java.lang.Object) 166, 7);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass51);
    }

    @Test
    public void test565() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test565");
        Temp temp0 = new Temp();
        temp0.m1("hi!", (java.lang.Object) (short) 100, 120);
        temp0.m1("", (java.lang.Object) 172, 32768);
        temp0.m();
        Temp temp11 = new Temp();
        temp11.m1("hi!", (java.lang.Object) (short) 100, 120);
        temp11.m();
        temp11.m();
        temp11.m();
        java.lang.Class<?> wildcardClass19 = temp11.getClass();
        temp0.m1("", (java.lang.Object) wildcardClass19, 151);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass19);
    }

    @Test
    public void test566() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test566");
        Temp temp0 = new Temp();
        temp0.m();
        temp0.m1("", (java.lang.Object) 15, 141);
        Temp temp7 = new Temp();
        temp7.m();
        temp7.m1("hi!", (java.lang.Object) 88, 94);
        temp7.m1("hi!", (java.lang.Object) 131, 98);
        temp7.m1("", (java.lang.Object) 13, 103);
        temp7.m1("hi!", (java.lang.Object) 131, 143);
        temp7.m1("", (java.lang.Object) 262144, 158);
        temp7.m();
        temp7.m1("hi!", (java.lang.Object) 161, 85);
        java.lang.Class<?> wildcardClass34 = temp7.getClass();
        temp0.m1("", (java.lang.Object) wildcardClass34, 184);
        Temp temp38 = new Temp();
        temp38.m();
        temp38.m1("", (java.lang.Object) 15, 141);
        temp38.m1("", (java.lang.Object) 128, (int) (short) 100);
        temp38.m();
        temp0.m1("", (java.lang.Object) temp38, 121);
        Temp temp52 = new Temp();
        temp52.m1("", (java.lang.Object) 127, 95);
        temp52.m1("hi!", (java.lang.Object) 126, 22);
        temp52.m1("", (java.lang.Object) 157, 154);
        ExampleTransformed exampleTransformed66 = new ExampleTransformed();
        temp52.m1("hi!", (java.lang.Object) exampleTransformed66, 10);
        temp52.m();
        temp52.m1("hi!", (java.lang.Object) 256, 51);
        temp52.m();
        temp52.m1("", (java.lang.Object) 2048, 1);
        java.lang.Class<?> wildcardClass79 = temp52.getClass();
        temp38.m1("hi!", (java.lang.Object) wildcardClass79, 93);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass34);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass79);
    }

    @Test
    public void test567() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test567");
        Temp temp0 = new Temp();
        temp0.m1("", (java.lang.Object) 127, 95);
        temp0.m();
        Temp temp7 = new Temp();
        temp7.m();
        temp7.m1("hi!", (java.lang.Object) 88, 94);
        temp7.m1("hi!", (java.lang.Object) 131, 98);
        temp7.m1("", (java.lang.Object) 13, 103);
        temp0.m1("", (java.lang.Object) temp7, 131);
        Temp temp24 = new Temp();
        temp24.m1("", (java.lang.Object) 127, 95);
        temp24.m1("hi!", (java.lang.Object) 126, 22);
        temp24.m1("", (java.lang.Object) 157, 154);
        ExampleTransformed exampleTransformed38 = new ExampleTransformed();
        temp24.m1("hi!", (java.lang.Object) exampleTransformed38, 10);
        temp24.m();
        java.lang.Object obj43 = null;
        temp24.m1("hi!", obj43, 182);
        temp0.m1("", (java.lang.Object) temp24, 11);
        temp24.m();
        Temp temp50 = new Temp();
        temp50.m1("", (java.lang.Object) 127, 95);
        temp50.m();
        Temp temp57 = new Temp();
        temp57.m();
        temp57.m1("hi!", (java.lang.Object) 88, 94);
        temp57.m1("hi!", (java.lang.Object) 131, 98);
        temp57.m1("", (java.lang.Object) 13, 103);
        temp50.m1("", (java.lang.Object) temp57, 131);
        temp50.m1("", (java.lang.Object) 176, 183);
        temp50.m();
        temp24.m1("", (java.lang.Object) temp50, 0);
    }

    @Test
    public void test568() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test568");
        Temp temp0 = new Temp();
        temp0.m1("", (java.lang.Object) 127, 95);
        temp0.m();
        Temp temp7 = new Temp();
        temp7.m();
        temp7.m1("hi!", (java.lang.Object) 88, 94);
        temp7.m1("hi!", (java.lang.Object) 131, 98);
        temp7.m1("", (java.lang.Object) 13, 103);
        temp0.m1("", (java.lang.Object) temp7, 131);
        temp0.m1("", (java.lang.Object) 135, 115);
        temp0.m();
        java.lang.Class<?> wildcardClass28 = temp0.getClass();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass28);
    }

    @Test
    public void test569() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test569");
        Temp temp0 = new Temp();
        temp0.m1("hi!", (java.lang.Object) (short) 100, 120);
        temp0.m();
        temp0.m1("hi!", (java.lang.Object) 131072, 176);
        Temp temp11 = new Temp();
        temp11.m();
        temp11.m1("hi!", (java.lang.Object) 88, 94);
        temp11.m1("hi!", (java.lang.Object) 131, 98);
        temp11.m1("", (java.lang.Object) 13, 103);
        temp11.m1("hi!", (java.lang.Object) 131, 143);
        temp11.m1("hi!", (java.lang.Object) 161, 132);
        temp11.m();
        temp11.m1("", (java.lang.Object) 171, 2);
        Temp temp39 = new Temp();
        temp39.m();
        temp39.m1("hi!", (java.lang.Object) 88, 94);
        temp39.m1("hi!", (java.lang.Object) 131, 98);
        temp39.m1("", (java.lang.Object) 13, 103);
        temp39.m1("hi!", (java.lang.Object) 131, 143);
        temp39.m1("hi!", (java.lang.Object) 161, 132);
        temp11.m1("hi!", (java.lang.Object) temp39, 56);
        temp11.m();
        temp0.m1("hi!", (java.lang.Object) temp11, 93);
    }

    @Test
    public void test570() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test570");
        Temp temp0 = new Temp();
        temp0.m();
        temp0.m1("hi!", (java.lang.Object) 88, 94);
        temp0.m1("hi!", (java.lang.Object) 131, 98);
        temp0.m1("", (java.lang.Object) 13, 103);
        temp0.m1("hi!", (java.lang.Object) 131, 143);
        temp0.m1("", (java.lang.Object) 23, 113);
        CopyClassFile copyClassFile23 = new CopyClassFile();
        java.lang.Class<?> wildcardClass24 = copyClassFile23.getClass();
        temp0.m1("hi!", (java.lang.Object) wildcardClass24, 131);
        temp0.m();
        temp0.m();
        temp0.m();
        temp0.m1("", (java.lang.Object) 181, 98);
        java.lang.Class<?> wildcardClass34 = temp0.getClass();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass24);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass34);
    }

    @Test
    public void test571() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test571");
        Temp temp0 = new Temp();
        temp0.m1("", (java.lang.Object) 127, 95);
        temp0.m1("hi!", (java.lang.Object) 126, 22);
        temp0.m1("", (java.lang.Object) 157, 154);
        ExampleTransformed exampleTransformed14 = new ExampleTransformed();
        temp0.m1("hi!", (java.lang.Object) exampleTransformed14, 10);
        temp0.m();
        temp0.m1("hi!", (java.lang.Object) 256, 51);
        temp0.m();
        temp0.m1("", (java.lang.Object) 2048, 1);
        temp0.m1("hi!", (java.lang.Object) 14, 128);
        temp0.m1("", (java.lang.Object) 146, 118);
        Temp temp36 = new Temp();
        temp36.m();
        temp36.m1("hi!", (java.lang.Object) 88, 94);
        temp36.m();
        temp0.m1("", (java.lang.Object) temp36, 84);
        temp36.m();
        temp36.m();
        temp36.m();
    }

    @Test
    public void test572() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test572");
        Temp temp0 = new Temp();
        temp0.m1("", (java.lang.Object) 127, 95);
        temp0.m();
        temp0.m();
        temp0.m();
        Temp temp9 = new Temp();
        temp9.m1("", (java.lang.Object) 127, 95);
        temp9.m();
        temp9.m();
        temp9.m();
        temp0.m1("", (java.lang.Object) temp9, 186);
        Temp temp20 = new Temp();
        temp20.m();
        temp20.m1("hi!", (java.lang.Object) 88, 94);
        temp20.m1("hi!", (java.lang.Object) 131, 98);
        temp20.m1("", (java.lang.Object) 13, 103);
        temp20.m1("hi!", (java.lang.Object) 131, 143);
        temp20.m1("", (java.lang.Object) 195, 118);
        temp20.m1("", (java.lang.Object) 96, 88);
        temp20.m();
        temp20.m1("", (java.lang.Object) 46, 262144);
        temp20.m1("hi!", (java.lang.Object) 46, 46);
        temp9.m1("hi!", (java.lang.Object) 46, 141);
        java.lang.Object obj58 = null;
        temp9.m1("hi!", obj58, 58);
    }

    @Test
    public void test573() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test573");
        Temp temp0 = new Temp();
        temp0.m();
        temp0.m1("hi!", (java.lang.Object) 88, 94);
        temp0.m1("hi!", (java.lang.Object) 131, 98);
        temp0.m1("", (java.lang.Object) 13, 103);
        temp0.m1("hi!", (java.lang.Object) 131, 143);
        temp0.m1("", (java.lang.Object) 195, 0);
        Temp temp23 = new Temp();
        temp23.m();
        temp23.m1("hi!", (java.lang.Object) 88, 94);
        temp23.m1("hi!", (java.lang.Object) 131, 98);
        temp23.m1("", (java.lang.Object) 13, 103);
        temp23.m1("hi!", (java.lang.Object) 131, 143);
        temp23.m1("", (java.lang.Object) 23, 113);
        CopyClassFile copyClassFile46 = new CopyClassFile();
        java.lang.Class<?> wildcardClass47 = copyClassFile46.getClass();
        temp23.m1("hi!", (java.lang.Object) wildcardClass47, 131);
        temp23.m1("", (java.lang.Object) 95, 135);
        temp0.m1("hi!", (java.lang.Object) temp23, 192);
        Temp temp57 = new Temp();
        temp57.m();
        temp57.m1("", (java.lang.Object) 15, 141);
        Temp temp64 = new Temp();
        temp64.m();
        temp64.m1("hi!", (java.lang.Object) 88, 94);
        temp64.m1("hi!", (java.lang.Object) 131, 98);
        temp64.m1("", (java.lang.Object) 13, 103);
        temp64.m1("hi!", (java.lang.Object) 131, 143);
        temp64.m1("", (java.lang.Object) 262144, 158);
        temp64.m();
        temp64.m1("hi!", (java.lang.Object) 161, 85);
        java.lang.Class<?> wildcardClass91 = temp64.getClass();
        temp57.m1("", (java.lang.Object) wildcardClass91, 184);
        temp57.m1("hi!", (java.lang.Object) 18, 0);
        temp0.m1("", (java.lang.Object) 18, 142);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass47);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass91);
    }

    @Test
    public void test574() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test574");
        Temp temp0 = new Temp();
        temp0.m();
        temp0.m1("hi!", (java.lang.Object) 88, 94);
        temp0.m1("hi!", (java.lang.Object) 131, 98);
        temp0.m();
        temp0.m();
        Temp temp13 = new Temp();
        temp13.m();
        temp13.m1("", (java.lang.Object) 15, 141);
        temp13.m();
        temp13.m();
        Temp temp22 = new Temp();
        temp22.m();
        temp22.m1("hi!", (java.lang.Object) 88, 94);
        temp22.m1("hi!", (java.lang.Object) 131, 98);
        temp22.m1("", (java.lang.Object) 13, 103);
        temp22.m1("hi!", (java.lang.Object) 131, 143);
        temp22.m1("", (java.lang.Object) 23, 113);
        java.lang.Object obj45 = null;
        temp22.m1("hi!", obj45, 58);
        temp22.m();
        temp13.m1("", (java.lang.Object) temp22, 139);
        temp13.m1("hi!", (java.lang.Object) 48, 256);
        Temp temp56 = new Temp();
        temp56.m1("", (java.lang.Object) 127, 95);
        temp56.m1("hi!", (java.lang.Object) 126, 22);
        temp56.m1("", (java.lang.Object) 157, 154);
        ExampleTransformed exampleTransformed70 = new ExampleTransformed();
        temp56.m1("hi!", (java.lang.Object) exampleTransformed70, 10);
        temp56.m();
        temp56.m1("hi!", (java.lang.Object) 256, 51);
        temp56.m();
        temp13.m1("hi!", (java.lang.Object) temp56, 144);
        temp0.m1("hi!", (java.lang.Object) temp56, (int) (byte) 1);
    }

    @Test
    public void test575() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test575");
        Temp temp0 = new Temp();
        temp0.m1("", (java.lang.Object) 127, 95);
        temp0.m1("hi!", (java.lang.Object) 126, 22);
        temp0.m1("", (java.lang.Object) 157, 154);
        temp0.m();
        temp0.m();
        temp0.m1("", (java.lang.Object) 11, 136);
        Temp temp20 = new Temp();
        temp20.m();
        temp20.m1("hi!", (java.lang.Object) 88, 94);
        temp20.m1("hi!", (java.lang.Object) 131, 98);
        temp20.m1("", (java.lang.Object) 13, 103);
        temp20.m1("hi!", (java.lang.Object) 131, 143);
        temp20.m1("hi!", (java.lang.Object) 161, 132);
        temp20.m();
        temp20.m();
        temp0.m1("", (java.lang.Object) temp20, 79);
        java.lang.Class<?> wildcardClass46 = temp20.getClass();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass46);
    }

    @Test
    public void test576() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test576");
        Temp temp0 = new Temp();
        temp0.m();
        temp0.m1("hi!", (java.lang.Object) 88, 94);
        temp0.m1("hi!", (java.lang.Object) 131, 98);
        temp0.m1("", (java.lang.Object) 13, 103);
        temp0.m1("hi!", (java.lang.Object) 131, 143);
        temp0.m1("hi!", (java.lang.Object) 161, 132);
        temp0.m();
        Temp temp24 = new Temp();
        temp24.m();
        temp24.m1("", (java.lang.Object) 15, 141);
        temp0.m1("hi!", (java.lang.Object) 15, 199);
        java.lang.Class<?> wildcardClass32 = temp0.getClass();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass32);
    }

    @Test
    public void test577() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test577");
        Temp temp0 = new Temp();
        temp0.m1("", (java.lang.Object) 127, 95);
        temp0.m1("hi!", (java.lang.Object) 126, 22);
        temp0.m();
        Temp temp11 = new Temp();
        temp11.m1("", (java.lang.Object) 127, 95);
        temp11.m1("hi!", (java.lang.Object) 126, 22);
        temp11.m1("", (java.lang.Object) 157, 154);
        ExampleTransformed exampleTransformed25 = new ExampleTransformed();
        temp11.m1("hi!", (java.lang.Object) exampleTransformed25, 10);
        temp11.m();
        temp11.m();
        Temp temp31 = new Temp();
        temp31.m();
        temp31.m1("hi!", (java.lang.Object) 88, 94);
        temp31.m1("hi!", (java.lang.Object) 131, 98);
        temp31.m1("", (java.lang.Object) 13, 103);
        java.lang.Class<?> wildcardClass45 = temp31.getClass();
        temp11.m1("hi!", (java.lang.Object) temp31, 137);
        temp11.m();
        Temp temp50 = new Temp();
        temp50.m1("", (java.lang.Object) 127, 95);
        temp50.m();
        Example example57 = new Example();
        java.lang.Class<?> wildcardClass58 = example57.getClass();
        temp50.m1("", (java.lang.Object) wildcardClass58, 166);
        temp11.m1("", (java.lang.Object) temp50, 90);
        temp0.m1("", (java.lang.Object) temp50, 86);
        temp50.m();
        temp50.m();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass45);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass58);
    }

    @Test
    public void test578() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test578");
        Temp temp0 = new Temp();
        temp0.m();
        temp0.m1("hi!", (java.lang.Object) 88, 94);
        temp0.m1("hi!", (java.lang.Object) 131, 98);
        temp0.m1("", (java.lang.Object) 13, 103);
        temp0.m1("hi!", (java.lang.Object) 131, 143);
        temp0.m1("", (java.lang.Object) 262144, 158);
        temp0.m();
        temp0.m1("hi!", (java.lang.Object) 11, 11);
        temp0.m1("hi!", (java.lang.Object) 116, 32768);
        Temp temp32 = new Temp();
        temp32.m();
        temp32.m1("hi!", (java.lang.Object) 88, 94);
        temp32.m1("hi!", (java.lang.Object) 131, 98);
        temp32.m1("", (java.lang.Object) 13, 103);
        temp32.m1("hi!", (java.lang.Object) 131, 143);
        temp32.m1("", (java.lang.Object) 262144, 158);
        temp32.m();
        temp32.m1("", (java.lang.Object) false, 22);
        temp32.m1("hi!", (java.lang.Object) 136, 168);
        java.lang.Class<?> wildcardClass63 = temp32.getClass();
        temp0.m1("hi!", (java.lang.Object) wildcardClass63, 10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass63);
    }

    @Test
    public void test579() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test579");
        Temp temp0 = new Temp();
        temp0.m1("", (java.lang.Object) 127, 95);
        temp0.m();
        Temp temp7 = new Temp();
        temp7.m();
        temp7.m1("hi!", (java.lang.Object) 88, 94);
        temp7.m1("hi!", (java.lang.Object) 131, 98);
        temp7.m1("", (java.lang.Object) 13, 103);
        temp0.m1("", (java.lang.Object) temp7, 131);
        temp7.m();
        temp7.m();
        temp7.m1("", (java.lang.Object) 54, 150);
        Temp temp30 = new Temp();
        temp30.m();
        temp30.m1("hi!", (java.lang.Object) 88, 94);
        Temp temp37 = new Temp();
        temp37.m1("", (java.lang.Object) 127, 95);
        temp37.m1("hi!", (java.lang.Object) 126, 22);
        temp37.m1("", (java.lang.Object) 157, 154);
        ExampleTransformed exampleTransformed51 = new ExampleTransformed();
        temp37.m1("hi!", (java.lang.Object) exampleTransformed51, 10);
        java.lang.Class<?> wildcardClass54 = temp37.getClass();
        temp30.m1("", (java.lang.Object) wildcardClass54, 106);
        temp7.m1("", (java.lang.Object) "", 141);
        temp7.m();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass54);
    }

    @Test
    public void test580() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test580");
        Temp temp0 = new Temp();
        temp0.m();
        temp0.m1("hi!", (java.lang.Object) 88, 94);
        temp0.m1("hi!", (java.lang.Object) 131, 98);
        temp0.m1("", (java.lang.Object) 13, 103);
        temp0.m1("hi!", (java.lang.Object) 131, 143);
        temp0.m1("", (java.lang.Object) 262144, 158);
        temp0.m();
        temp0.m1("hi!", (java.lang.Object) 161, 85);
        Temp temp28 = new Temp();
        temp28.m();
        temp28.m1("hi!", (java.lang.Object) 88, 94);
        temp28.m1("hi!", (java.lang.Object) 131, 98);
        temp28.m1("", (java.lang.Object) 13, 103);
        Temp temp43 = new Temp();
        temp43.m1("", (java.lang.Object) 127, 95);
        temp43.m1("hi!", (java.lang.Object) 126, 22);
        temp43.m1("", (java.lang.Object) 157, 154);
        temp43.m();
        temp43.m1("", (java.lang.Object) 161, 0);
        temp28.m1("hi!", (java.lang.Object) "", 86);
        java.lang.Class<?> wildcardClass63 = temp28.getClass();
        temp0.m1("hi!", (java.lang.Object) wildcardClass63, 15);
        Temp temp67 = new Temp();
        temp67.m1("", (java.lang.Object) 127, 95);
        temp67.m1("hi!", (java.lang.Object) 126, 22);
        temp67.m1("", (java.lang.Object) 157, 154);
        ExampleTransformed exampleTransformed81 = new ExampleTransformed();
        temp67.m1("hi!", (java.lang.Object) exampleTransformed81, 10);
        temp67.m1("", (java.lang.Object) 82, 105);
        temp67.m();
        temp67.m();
        temp0.m1("hi!", (java.lang.Object) temp67, 145);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass63);
    }

    @Test
    public void test581() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test581");
        Temp temp0 = new Temp();
        temp0.m1("", (java.lang.Object) 127, 95);
        temp0.m();
        Temp temp7 = new Temp();
        temp7.m();
        temp7.m1("hi!", (java.lang.Object) 88, 94);
        temp7.m1("hi!", (java.lang.Object) 131, 98);
        temp7.m1("", (java.lang.Object) 13, 103);
        temp0.m1("", (java.lang.Object) temp7, 131);
        temp7.m1("", (java.lang.Object) 81, 7);
        temp7.m();
        temp7.m();
    }

    @Test
    public void test582() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test582");
        Temp temp0 = new Temp();
        temp0.m();
        temp0.m1("hi!", (java.lang.Object) 88, 94);
        temp0.m1("hi!", (java.lang.Object) 131, 98);
        temp0.m1("", (java.lang.Object) 13, 103);
        temp0.m1("hi!", (java.lang.Object) 131, 143);
        temp0.m1("", (java.lang.Object) 195, 118);
        java.lang.Object obj23 = null;
        temp0.m1("", obj23, 58);
        temp0.m();
        java.lang.Class<?> wildcardClass27 = temp0.getClass();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass27);
    }

    @Test
    public void test583() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test583");
        Temp temp0 = new Temp();
        temp0.m();
        temp0.m1("hi!", (java.lang.Object) 88, 94);
        temp0.m1("hi!", (java.lang.Object) 131, 98);
        temp0.m1("", (java.lang.Object) 13, 103);
        temp0.m1("hi!", (java.lang.Object) 131, 143);
        temp0.m1("", (java.lang.Object) 23, 113);
        CopyClassFile copyClassFile23 = new CopyClassFile();
        java.lang.Class<?> wildcardClass24 = copyClassFile23.getClass();
        temp0.m1("hi!", (java.lang.Object) wildcardClass24, 131);
        temp0.m();
        temp0.m();
        temp0.m();
        temp0.m1("", (java.lang.Object) 181, 98);
        temp0.m();
        java.lang.Object obj36 = null;
        temp0.m1("hi!", obj36, 183);
        java.lang.Class<?> wildcardClass39 = temp0.getClass();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass24);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass39);
    }

    @Test
    public void test584() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test584");
        Temp temp0 = new Temp();
        temp0.m();
        temp0.m1("hi!", (java.lang.Object) 88, 94);
        temp0.m1("hi!", (java.lang.Object) 131, 98);
        temp0.m1("", (java.lang.Object) 13, 103);
        temp0.m1("hi!", (java.lang.Object) 131, 143);
        temp0.m1("", (java.lang.Object) 262144, 158);
        Temp temp23 = new Temp();
        temp23.m1("", (java.lang.Object) 127, 95);
        temp23.m();
        Example example30 = new Example();
        java.lang.Class<?> wildcardClass31 = example30.getClass();
        temp23.m1("", (java.lang.Object) wildcardClass31, 166);
        temp23.m1("hi!", (java.lang.Object) 180, 198);
        temp0.m1("", (java.lang.Object) temp23, 151);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass31);
    }

    @Test
    public void test585() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test585");
        Temp temp0 = new Temp();
        temp0.m1("", (java.lang.Object) 127, 95);
        temp0.m();
        Temp temp7 = new Temp();
        temp7.m();
        temp7.m1("hi!", (java.lang.Object) 88, 94);
        temp7.m1("hi!", (java.lang.Object) 131, 98);
        temp7.m1("", (java.lang.Object) 13, 103);
        temp0.m1("", (java.lang.Object) temp7, 131);
        temp0.m1("", (java.lang.Object) 176, 183);
        Temp temp28 = new Temp();
        temp28.m();
        temp28.m1("hi!", (java.lang.Object) 88, 94);
        temp28.m1("hi!", (java.lang.Object) 131, 98);
        temp28.m1("", (java.lang.Object) 13, 103);
        Temp temp43 = new Temp();
        temp43.m1("", (java.lang.Object) 127, 95);
        temp43.m1("hi!", (java.lang.Object) 126, 22);
        temp43.m1("", (java.lang.Object) 157, 154);
        temp43.m();
        temp43.m1("", (java.lang.Object) 161, 0);
        temp28.m1("hi!", (java.lang.Object) "", 86);
        temp0.m1("hi!", (java.lang.Object) 86, 2048);
        Temp temp66 = new Temp();
        temp66.m1("", (java.lang.Object) 127, 95);
        temp66.m();
        Temp temp73 = new Temp();
        temp73.m();
        temp73.m1("hi!", (java.lang.Object) 88, 94);
        temp73.m1("hi!", (java.lang.Object) 131, 98);
        temp73.m1("", (java.lang.Object) 13, 103);
        temp66.m1("", (java.lang.Object) temp73, 131);
        temp66.m1("", (java.lang.Object) 176, 183);
        temp66.m();
        temp0.m1("", (java.lang.Object) temp66, 149);
        temp0.m();
    }

    @Test
    public void test586() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test586");
        Temp temp0 = new Temp();
        temp0.m();
        temp0.m1("hi!", (java.lang.Object) 88, 94);
        temp0.m1("hi!", (java.lang.Object) 131, 98);
        temp0.m1("", (java.lang.Object) 13, 103);
        temp0.m();
        temp0.m();
        temp0.m();
        temp0.m1("hi!", (java.lang.Object) 262144, 84);
        temp0.m1("", (java.lang.Object) 32768, 91);
        temp0.m();
        Temp temp27 = new Temp();
        temp27.m1("", (java.lang.Object) 127, 95);
        temp27.m();
        temp27.m();
        Temp temp35 = new Temp();
        temp35.m();
        temp35.m1("hi!", (java.lang.Object) 88, 94);
        temp35.m1("hi!", (java.lang.Object) 131, 98);
        temp35.m1("", (java.lang.Object) 13, 103);
        temp35.m1("hi!", (java.lang.Object) 131, 143);
        temp35.m1("", (java.lang.Object) 23, 113);
        java.lang.Object obj58 = null;
        temp35.m1("hi!", obj58, 58);
        temp27.m1("", (java.lang.Object) temp35, 256);
        temp27.m1("", (java.lang.Object) 120, 0);
        temp0.m1("", (java.lang.Object) temp27, 56);
        temp27.m1("hi!", (java.lang.Object) 16384, 140);
        temp27.m();
    }

    @Test
    public void test587() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test587");
        Temp temp0 = new Temp();
        temp0.m1("", (java.lang.Object) 127, 95);
        temp0.m1("hi!", (java.lang.Object) 126, 22);
        temp0.m1("", (java.lang.Object) 157, 154);
        ExampleTransformed exampleTransformed14 = new ExampleTransformed();
        temp0.m1("hi!", (java.lang.Object) exampleTransformed14, 10);
        temp0.m1("", (java.lang.Object) 82, 105);
        temp0.m();
        temp0.m();
        Temp temp24 = new Temp();
        temp24.m();
        temp24.m1("", (java.lang.Object) 15, 157);
        temp24.m1("hi!", (java.lang.Object) 21, 152);
        temp24.m1("hi!", (java.lang.Object) 53, 53);
        temp24.m();
        java.lang.Class<?> wildcardClass39 = temp24.getClass();
        temp0.m1("hi!", (java.lang.Object) wildcardClass39, 114);
        temp0.m();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass39);
    }

    @Test
    public void test588() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test588");
        Temp temp0 = new Temp();
        temp0.m();
        temp0.m1("hi!", (java.lang.Object) 88, 94);
        temp0.m1("hi!", (java.lang.Object) 131, 98);
        temp0.m1("", (java.lang.Object) 13, 103);
        temp0.m1("hi!", (java.lang.Object) 131, 143);
        Temp temp19 = new Temp();
        temp19.m();
        temp19.m1("hi!", (java.lang.Object) 88, 94);
        temp19.m1("hi!", (java.lang.Object) 131, 98);
        temp19.m1("", (java.lang.Object) 13, 103);
        temp19.m1("hi!", (java.lang.Object) 131, 143);
        temp19.m1("", (java.lang.Object) 23, 113);
        CopyClassFile copyClassFile42 = new CopyClassFile();
        java.lang.Class<?> wildcardClass43 = copyClassFile42.getClass();
        temp19.m1("hi!", (java.lang.Object) wildcardClass43, 131);
        temp19.m();
        temp0.m1("", (java.lang.Object) temp19, 131);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass43);
    }

    @Test
    public void test589() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test589");
        Temp temp0 = new Temp();
        temp0.m();
        temp0.m1("", (java.lang.Object) 15, 157);
        temp0.m();
        Temp temp8 = new Temp();
        temp8.m();
        temp8.m1("hi!", (java.lang.Object) 88, 94);
        temp8.m1("hi!", (java.lang.Object) 131, 98);
        temp8.m1("", (java.lang.Object) 13, 103);
        temp8.m1("hi!", (java.lang.Object) 131, 143);
        temp8.m1("", (java.lang.Object) 23, 113);
        CopyClassFile copyClassFile31 = new CopyClassFile();
        java.lang.Class<?> wildcardClass32 = copyClassFile31.getClass();
        temp8.m1("hi!", (java.lang.Object) wildcardClass32, 131);
        Temp temp36 = new Temp();
        temp36.m();
        temp36.m1("hi!", (java.lang.Object) 88, 94);
        temp36.m1("hi!", (java.lang.Object) 131, 98);
        temp36.m1("", (java.lang.Object) 13, 103);
        temp36.m1("hi!", (java.lang.Object) 131, 143);
        temp36.m1("", (java.lang.Object) 262144, 158);
        temp36.m();
        temp36.m1("hi!", (java.lang.Object) 11, 11);
        temp36.m();
        temp8.m1("hi!", (java.lang.Object) temp36, (int) (short) 10);
        temp0.m1("hi!", (java.lang.Object) "hi!", 95);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass32);
    }

    @Test
    public void test590() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test590");
        Temp temp0 = new Temp();
        temp0.m();
        temp0.m1("hi!", (java.lang.Object) 88, 94);
        temp0.m1("hi!", (java.lang.Object) 131, 98);
        temp0.m1("", (java.lang.Object) 13, 103);
        temp0.m1("hi!", (java.lang.Object) 131, 143);
        temp0.m1("", (java.lang.Object) 23, 113);
        CopyClassFile copyClassFile23 = new CopyClassFile();
        java.lang.Class<?> wildcardClass24 = copyClassFile23.getClass();
        temp0.m1("hi!", (java.lang.Object) wildcardClass24, 131);
        temp0.m();
        temp0.m();
        temp0.m();
        temp0.m1("", (java.lang.Object) 181, 98);
        temp0.m();
        Temp temp36 = new Temp();
        temp0.m1("", (java.lang.Object) temp36, 196653);
        temp0.m();
        java.lang.Class<?> wildcardClass40 = temp0.getClass();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass24);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass40);
    }

    @Test
    public void test591() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test591");
        Temp temp0 = new Temp();
        temp0.m1("", (java.lang.Object) 127, 95);
        temp0.m1("hi!", (java.lang.Object) 126, 22);
        temp0.m1("", (java.lang.Object) 157, 154);
        temp0.m();
        temp0.m();
        temp0.m1("", (java.lang.Object) 11, 136);
        Temp temp20 = new Temp();
        temp20.m1("", (java.lang.Object) 127, 95);
        temp20.m();
        Temp temp27 = new Temp();
        temp27.m1("", (java.lang.Object) 127, 95);
        temp27.m1("hi!", (java.lang.Object) 126, 22);
        temp27.m1("", (java.lang.Object) 157, 154);
        temp27.m();
        temp27.m1("hi!", (java.lang.Object) 10.0d, 124);
        temp20.m1("", (java.lang.Object) 124, (int) (byte) -1);
        Temp temp48 = new Temp();
        temp48.m();
        temp48.m1("", (java.lang.Object) 15, 141);
        temp20.m1("", (java.lang.Object) temp48, 190);
        temp0.m1("hi!", (java.lang.Object) "", 23);
    }

    @Test
    public void test592() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test592");
        Temp temp0 = new Temp();
        temp0.m();
        temp0.m1("hi!", (java.lang.Object) 88, 94);
        temp0.m1("hi!", (java.lang.Object) 131, 98);
        temp0.m1("", (java.lang.Object) 13, 103);
        temp0.m1("hi!", (java.lang.Object) 131, 143);
        temp0.m1("", (java.lang.Object) 262144, 158);
        temp0.m();
        temp0.m1("", (java.lang.Object) false, 22);
        temp0.m();
    }

    @Test
    public void test593() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test593");
        Temp temp0 = new Temp();
        temp0.m();
        temp0.m1("hi!", (java.lang.Object) 88, 94);
        temp0.m1("hi!", (java.lang.Object) 131, 98);
        temp0.m1("", (java.lang.Object) 13, 103);
        temp0.m1("hi!", (java.lang.Object) 131, 143);
        temp0.m1("", (java.lang.Object) 262144, 158);
        temp0.m();
        temp0.m1("hi!", (java.lang.Object) 161, 85);
        Temp temp28 = new Temp();
        temp28.m1("", (java.lang.Object) 127, 95);
        temp28.m1("hi!", (java.lang.Object) 126, 22);
        temp28.m1("", (java.lang.Object) 157, 154);
        ExampleTransformed exampleTransformed42 = new ExampleTransformed();
        temp28.m1("hi!", (java.lang.Object) exampleTransformed42, 10);
        temp28.m();
        temp28.m();
        Temp temp48 = new Temp();
        temp48.m();
        temp48.m1("hi!", (java.lang.Object) 88, 94);
        temp48.m1("hi!", (java.lang.Object) 131, 98);
        temp48.m1("", (java.lang.Object) 13, 103);
        java.lang.Class<?> wildcardClass62 = temp48.getClass();
        temp28.m1("hi!", (java.lang.Object) temp48, 137);
        temp28.m();
        temp0.m1("hi!", (java.lang.Object) temp28, 4096);
        java.lang.Class<?> wildcardClass68 = temp28.getClass();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass62);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass68);
    }

    @Test
    public void test594() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test594");
        Temp temp0 = new Temp();
        temp0.m();
        temp0.m1("", (java.lang.Object) 15, 141);
        Temp temp7 = new Temp();
        temp7.m();
        temp7.m1("hi!", (java.lang.Object) 88, 94);
        temp7.m1("hi!", (java.lang.Object) 131, 98);
        temp7.m1("", (java.lang.Object) 13, 103);
        temp7.m1("hi!", (java.lang.Object) 131, 143);
        temp7.m1("", (java.lang.Object) 262144, 158);
        temp7.m();
        temp7.m1("hi!", (java.lang.Object) 161, 85);
        java.lang.Class<?> wildcardClass34 = temp7.getClass();
        temp0.m1("", (java.lang.Object) wildcardClass34, 184);
        temp0.m1("hi!", (java.lang.Object) 18, 0);
        temp0.m1("hi!", (java.lang.Object) ' ', 190);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass34);
    }

    @Test
    public void test595() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test595");
        Temp temp0 = new Temp();
        temp0.m();
        temp0.m1("", (java.lang.Object) 15, 157);
        temp0.m1("", (java.lang.Object) "hi!", 181);
        temp0.m1("hi!", (java.lang.Object) 9, 6);
        temp0.m();
        temp0.m();
    }

    @Test
    public void test596() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test596");
        Temp temp0 = new Temp();
        temp0.m1("", (java.lang.Object) 127, 95);
        temp0.m();
        Temp temp7 = new Temp();
        temp7.m();
        temp7.m1("hi!", (java.lang.Object) 88, 94);
        temp7.m1("hi!", (java.lang.Object) 131, 98);
        temp7.m1("", (java.lang.Object) 13, 103);
        temp0.m1("", (java.lang.Object) temp7, 131);
        temp7.m();
        temp7.m();
        temp7.m1("", (java.lang.Object) 54, 150);
        java.lang.Object obj30 = null;
        temp7.m1("", obj30, 82);
        Temp temp34 = new Temp();
        temp34.m1("", (java.lang.Object) 127, 95);
        temp34.m();
        temp34.m1("", (java.lang.Object) 1.0d, 130);
        temp34.m1("hi!", (java.lang.Object) 129, 118);
        temp7.m1("hi!", (java.lang.Object) "hi!", (int) (byte) 1);
    }

    @Test
    public void test597() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test597");
        Temp temp0 = new Temp();
        temp0.m();
        temp0.m1("hi!", (java.lang.Object) 88, 94);
        temp0.m1("hi!", (java.lang.Object) 131, 98);
        temp0.m1("", (java.lang.Object) 13, 103);
        temp0.m1("hi!", (java.lang.Object) 131, 143);
        temp0.m1("", (java.lang.Object) 23, 113);
        Temp temp23 = new Temp();
        temp23.m1("", (java.lang.Object) 127, 95);
        temp23.m1("hi!", (java.lang.Object) 126, 22);
        temp23.m1("", (java.lang.Object) 157, 154);
        ExampleTransformed exampleTransformed37 = new ExampleTransformed();
        temp23.m1("hi!", (java.lang.Object) exampleTransformed37, 10);
        temp23.m();
        temp23.m1("hi!", (java.lang.Object) 256, 51);
        temp23.m();
        temp23.m();
        temp23.m();
        temp0.m1("hi!", (java.lang.Object) temp23, 161);
        Temp temp51 = new Temp();
        temp51.m1("", (java.lang.Object) 127, 95);
        temp51.m1("hi!", (java.lang.Object) 126, 22);
        temp51.m1("", (java.lang.Object) 157, 154);
        ExampleTransformed exampleTransformed65 = new ExampleTransformed();
        temp51.m1("hi!", (java.lang.Object) exampleTransformed65, 10);
        temp23.m1("hi!", (java.lang.Object) temp51, 327680);
        temp23.m1("hi!", (java.lang.Object) 148, (int) (short) 1);
        temp23.m();
    }

    @Test
    public void test598() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test598");
        Temp temp0 = new Temp();
        temp0.m1("", (java.lang.Object) 127, 95);
        temp0.m();
        Temp temp7 = new Temp();
        temp7.m1("", (java.lang.Object) 127, 95);
        temp7.m1("hi!", (java.lang.Object) 126, 22);
        temp7.m1("", (java.lang.Object) 157, 154);
        temp7.m();
        temp7.m1("hi!", (java.lang.Object) 10.0d, 124);
        temp0.m1("", (java.lang.Object) 124, (int) (byte) -1);
        Temp temp28 = new Temp();
        temp28.m();
        temp28.m1("", (java.lang.Object) 15, 141);
        temp0.m1("", (java.lang.Object) temp28, 190);
        Temp temp37 = new Temp();
        temp37.m();
        temp37.m1("hi!", (java.lang.Object) 88, 94);
        temp37.m1("hi!", (java.lang.Object) 131, 98);
        temp37.m1("", (java.lang.Object) 13, 103);
        temp37.m1("hi!", (java.lang.Object) 131, 143);
        temp37.m1("", (java.lang.Object) 195, 118);
        java.lang.Object obj60 = null;
        temp37.m1("", obj60, 58);
        temp37.m();
        temp28.m1("", (java.lang.Object) temp37, (int) 'a');
        temp28.m1("hi!", (java.lang.Object) (short) 1, 2);
        java.lang.Class<?> wildcardClass70 = temp28.getClass();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass70);
    }

    @Test
    public void test599() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test599");
        Temp temp0 = new Temp();
        temp0.m();
        temp0.m1("", (java.lang.Object) 15, 141);
        temp0.m();
        Temp temp8 = new Temp();
        temp8.m();
        temp8.m1("hi!", (java.lang.Object) 88, 94);
        temp8.m1("hi!", (java.lang.Object) 131, 98);
        temp8.m1("", (java.lang.Object) 13, 103);
        temp8.m1("hi!", (java.lang.Object) 131, 143);
        temp8.m1("", (java.lang.Object) 195, 0);
        Temp temp31 = new Temp();
        temp31.m();
        temp31.m1("hi!", (java.lang.Object) 88, 94);
        temp31.m1("hi!", (java.lang.Object) 131, 98);
        temp31.m1("", (java.lang.Object) 13, 103);
        temp31.m1("hi!", (java.lang.Object) 131, 143);
        temp31.m1("", (java.lang.Object) 23, 113);
        CopyClassFile copyClassFile54 = new CopyClassFile();
        java.lang.Class<?> wildcardClass55 = copyClassFile54.getClass();
        temp31.m1("hi!", (java.lang.Object) wildcardClass55, 131);
        temp31.m1("", (java.lang.Object) 95, 135);
        temp8.m1("hi!", (java.lang.Object) temp31, 192);
        temp8.m();
        temp0.m1("", (java.lang.Object) temp8, 2048);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass55);
    }

    @Test
    public void test600() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test600");
        Temp temp0 = new Temp();
        temp0.m();
        temp0.m1("hi!", (java.lang.Object) 88, 94);
        temp0.m1("hi!", (java.lang.Object) 131, 98);
        temp0.m();
        Temp temp12 = new Temp();
        temp12.m();
        temp12.m1("hi!", (java.lang.Object) 88, 94);
        temp12.m1("hi!", (java.lang.Object) 131, 98);
        temp12.m1("", (java.lang.Object) 13, 103);
        temp12.m1("hi!", (java.lang.Object) 131, 143);
        temp12.m1("", (java.lang.Object) 23, 113);
        CopyClassFile copyClassFile35 = new CopyClassFile();
        java.lang.Class<?> wildcardClass36 = copyClassFile35.getClass();
        temp12.m1("hi!", (java.lang.Object) wildcardClass36, 131);
        temp12.m();
        java.lang.Class<?> wildcardClass40 = temp12.getClass();
        temp0.m1("hi!", (java.lang.Object) wildcardClass40, 4096);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass36);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass40);
    }

    @Test
    public void test601() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test601");
        Temp temp0 = new Temp();
        temp0.m();
        temp0.m();
        temp0.m();
        temp0.m1("hi!", (java.lang.Object) 180, 97);
    }

    @Test
    public void test602() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test602");
        Temp temp0 = new Temp();
        temp0.m();
        temp0.m1("hi!", (java.lang.Object) 88, 94);
        temp0.m1("hi!", (java.lang.Object) 131, 98);
        temp0.m1("", (java.lang.Object) 13, 103);
        temp0.m1("hi!", (java.lang.Object) 131, 143);
        temp0.m1("hi!", (java.lang.Object) 161, 132);
        temp0.m1("", (java.lang.Object) 130, 193);
        Temp temp27 = new Temp();
        temp27.m1("", (java.lang.Object) 127, 95);
        temp27.m1("hi!", (java.lang.Object) 126, 22);
        temp27.m1("", (java.lang.Object) 157, 154);
        temp27.m();
        temp27.m1("", (java.lang.Object) 161, 0);
        temp27.m();
        temp0.m1("", (java.lang.Object) temp27, 5);
    }

    @Test
    public void test603() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test603");
        Temp temp0 = new Temp();
        temp0.m1("", (java.lang.Object) 127, 95);
        temp0.m1("hi!", (java.lang.Object) 126, 22);
        temp0.m1("", (java.lang.Object) 157, 154);
        ExampleTransformed exampleTransformed14 = new ExampleTransformed();
        temp0.m1("hi!", (java.lang.Object) exampleTransformed14, 10);
        temp0.m();
        temp0.m1("hi!", (java.lang.Object) 256, 51);
        temp0.m();
        temp0.m1("", (java.lang.Object) 2048, 1);
        temp0.m();
        temp0.m();
        temp0.m();
        Temp temp31 = new Temp();
        Generated generated33 = new Generated();
        java.lang.Class<?> wildcardClass34 = generated33.getClass();
        temp31.m1("", (java.lang.Object) wildcardClass34, 96);
        temp0.m1("hi!", (java.lang.Object) temp31, 102);
        Temp temp40 = new Temp();
        temp40.m();
        temp40.m1("hi!", (java.lang.Object) 88, 94);
        temp40.m1("hi!", (java.lang.Object) 131, 98);
        temp40.m1("", (java.lang.Object) 13, 103);
        temp40.m1("hi!", (java.lang.Object) 131, 143);
        temp40.m1("", (java.lang.Object) 23, 113);
        CopyClassFile copyClassFile63 = new CopyClassFile();
        java.lang.Class<?> wildcardClass64 = copyClassFile63.getClass();
        temp40.m1("hi!", (java.lang.Object) wildcardClass64, 131);
        temp40.m();
        temp31.m1("", (java.lang.Object) temp40, 188);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass34);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass64);
    }

    @Test
    public void test604() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test604");
        Temp temp0 = new Temp();
        temp0.m1("", (java.lang.Object) 127, 95);
        temp0.m1("hi!", (java.lang.Object) 126, 22);
        temp0.m1("", (java.lang.Object) 157, 154);
        ExampleTransformed exampleTransformed14 = new ExampleTransformed();
        temp0.m1("hi!", (java.lang.Object) exampleTransformed14, 10);
        temp0.m();
        temp0.m1("hi!", (java.lang.Object) 256, 51);
        temp0.m();
        temp0.m1("", (java.lang.Object) 2048, 1);
        temp0.m1("hi!", (java.lang.Object) 14, 128);
        temp0.m1("", (java.lang.Object) 146, 118);
        Temp temp36 = new Temp();
        temp36.m();
        temp36.m1("hi!", (java.lang.Object) 88, 94);
        temp36.m();
        temp0.m1("", (java.lang.Object) temp36, 84);
        java.lang.Class<?> wildcardClass45 = temp36.getClass();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass45);
    }

    @Test
    public void test605() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test605");
        Temp temp0 = new Temp();
        temp0.m();
        temp0.m1("hi!", (java.lang.Object) 88, 94);
        temp0.m1("hi!", (java.lang.Object) 131, 98);
        temp0.m1("", (java.lang.Object) 13, 103);
        temp0.m1("hi!", (java.lang.Object) 131, 143);
        temp0.m1("", (java.lang.Object) 195, 118);
        java.lang.Object obj23 = null;
        temp0.m1("", obj23, 58);
        temp0.m();
        Temp temp28 = new Temp();
        temp28.m();
        temp28.m1("hi!", (java.lang.Object) 88, 94);
        temp28.m1("hi!", (java.lang.Object) 131, 98);
        temp28.m1("", (java.lang.Object) 13, 103);
        temp28.m();
        temp0.m1("", (java.lang.Object) temp28, (int) (byte) -1);
        temp0.m();
    }

    @Test
    public void test606() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test606");
        Temp temp0 = new Temp();
        temp0.m1("", (java.lang.Object) 127, 95);
        temp0.m();
        Temp temp7 = new Temp();
        temp7.m1("", (java.lang.Object) 127, 95);
        temp7.m1("hi!", (java.lang.Object) 126, 22);
        temp7.m1("", (java.lang.Object) 157, 154);
        temp7.m();
        temp7.m1("hi!", (java.lang.Object) 10.0d, 124);
        temp0.m1("", (java.lang.Object) 124, (int) (byte) -1);
        Temp temp28 = new Temp();
        temp28.m();
        temp28.m1("", (java.lang.Object) 15, 141);
        temp0.m1("", (java.lang.Object) temp28, 190);
        temp28.m1("", (java.lang.Object) 182, 0);
    }

    @Test
    public void test607() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test607");
        Temp temp0 = new Temp();
        temp0.m1("", (java.lang.Object) 127, 95);
        temp0.m();
        Temp temp7 = new Temp();
        temp7.m1("", (java.lang.Object) 127, 95);
        temp7.m1("hi!", (java.lang.Object) 126, 22);
        temp7.m1("", (java.lang.Object) 157, 154);
        temp7.m();
        temp7.m1("hi!", (java.lang.Object) 10.0d, 124);
        temp0.m1("", (java.lang.Object) 124, (int) (byte) -1);
        Temp temp28 = new Temp();
        temp28.m();
        temp28.m1("", (java.lang.Object) 15, 141);
        temp0.m1("", (java.lang.Object) temp28, 190);
        temp0.m();
        temp0.m();
        java.lang.Object obj39 = null;
        temp0.m1("hi!", obj39, 194);
    }

    @Test
    public void test608() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test608");
        Temp temp0 = new Temp();
        temp0.m1("", (java.lang.Object) 127, 95);
        temp0.m1("hi!", (java.lang.Object) 126, 22);
        temp0.m1("", (java.lang.Object) 157, 154);
        ExampleTransformed exampleTransformed14 = new ExampleTransformed();
        temp0.m1("hi!", (java.lang.Object) exampleTransformed14, 10);
        temp0.m();
        temp0.m1("hi!", (java.lang.Object) 256, 51);
        temp0.m();
        temp0.m();
        temp0.m();
        temp0.m();
        Temp temp27 = new Temp();
        temp27.m();
        temp27.m1("hi!", (java.lang.Object) 88, 94);
        temp27.m1("hi!", (java.lang.Object) 131, 98);
        temp27.m1("", (java.lang.Object) 13, 103);
        temp27.m1("hi!", (java.lang.Object) 131, 143);
        temp27.m1("", (java.lang.Object) 23, 113);
        CopyClassFile copyClassFile50 = new CopyClassFile();
        java.lang.Class<?> wildcardClass51 = copyClassFile50.getClass();
        temp27.m1("hi!", (java.lang.Object) wildcardClass51, 131);
        Temp temp55 = new Temp();
        temp55.m();
        temp55.m1("hi!", (java.lang.Object) 88, 94);
        temp55.m1("hi!", (java.lang.Object) 131, 98);
        temp55.m();
        java.lang.Class<?> wildcardClass66 = temp55.getClass();
        temp27.m1("hi!", (java.lang.Object) wildcardClass66, (int) (short) 1);
        temp0.m1("hi!", (java.lang.Object) wildcardClass66, 32768);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass51);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass66);
    }

    @Test
    public void test609() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test609");
        Temp temp0 = new Temp();
        temp0.m();
        temp0.m1("hi!", (java.lang.Object) 88, 94);
        temp0.m1("hi!", (java.lang.Object) 131, 98);
        temp0.m1("", (java.lang.Object) 13, 103);
        temp0.m1("hi!", (java.lang.Object) 131, 143);
        temp0.m1("", (java.lang.Object) 195, 0);
        temp0.m();
        Temp temp24 = new Temp();
        temp24.m1("", (java.lang.Object) 127, 95);
        temp24.m();
        Temp temp31 = new Temp();
        temp31.m();
        temp31.m1("hi!", (java.lang.Object) 88, 94);
        temp31.m1("hi!", (java.lang.Object) 131, 98);
        temp31.m1("", (java.lang.Object) 13, 103);
        temp24.m1("", (java.lang.Object) temp31, 131);
        temp24.m1("", (java.lang.Object) 135, 115);
        temp24.m();
        temp24.m();
        temp24.m();
        temp24.m1("", (java.lang.Object) 181, 0);
        temp24.m();
        java.lang.Class<?> wildcardClass59 = temp24.getClass();
        temp0.m1("", (java.lang.Object) wildcardClass59, 139);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass59);
    }

    @Test
    public void test610() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test610");
        Temp temp0 = new Temp();
        temp0.m1("", (java.lang.Object) 127, 95);
        Temp temp6 = new Temp();
        temp6.m1("", (java.lang.Object) 127, 95);
        temp6.m1("hi!", (java.lang.Object) 126, 22);
        temp6.m1("hi!", (java.lang.Object) 85, 174);
        temp0.m1("hi!", (java.lang.Object) "hi!", 142);
        Temp temp22 = new Temp();
        temp22.m();
        temp22.m1("", (java.lang.Object) 15, 141);
        temp22.m();
        temp22.m();
        temp0.m1("hi!", (java.lang.Object) temp22, 0);
        java.lang.Class<?> wildcardClass32 = temp22.getClass();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass32);
    }

    @Test
    public void test611() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test611");
        Temp temp0 = new Temp();
        temp0.m();
        temp0.m1("hi!", (java.lang.Object) 88, 94);
        temp0.m1("hi!", (java.lang.Object) 131, 98);
        temp0.m1("", (java.lang.Object) 13, 103);
        temp0.m1("hi!", (java.lang.Object) 131, 143);
        temp0.m1("", (java.lang.Object) 195, 118);
        temp0.m1("", (java.lang.Object) 96, 88);
        temp0.m();
        temp0.m1("", (java.lang.Object) 46, 262144);
        Temp temp32 = new Temp();
        temp32.m1("", (java.lang.Object) 127, 95);
        temp32.m1("hi!", (java.lang.Object) 126, 22);
        temp32.m1("", (java.lang.Object) 157, 154);
        temp32.m();
        temp32.m();
        temp32.m();
        temp32.m1("hi!", (java.lang.Object) 172, 112);
        temp32.m();
        java.lang.Class<?> wildcardClass53 = temp32.getClass();
        temp0.m1("", (java.lang.Object) wildcardClass53, 184);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass53);
    }

    @Test
    public void test612() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test612");
        Temp temp0 = new Temp();
        temp0.m();
        temp0.m1("hi!", (java.lang.Object) 88, 94);
        temp0.m1("hi!", (java.lang.Object) 131, 98);
        temp0.m1("", (java.lang.Object) 13, 103);
        Temp temp15 = new Temp();
        temp15.m1("", (java.lang.Object) 127, 95);
        temp15.m1("hi!", (java.lang.Object) 126, 22);
        temp15.m1("", (java.lang.Object) 157, 154);
        java.lang.Class<?> wildcardClass28 = temp15.getClass();
        temp0.m1("", (java.lang.Object) temp15, 180);
        temp0.m();
        temp0.m();
        java.lang.Class<?> wildcardClass33 = temp0.getClass();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass28);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass33);
    }

    @Test
    public void test613() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test613");
        Temp temp0 = new Temp();
        temp0.m();
        temp0.m1("", (java.lang.Object) 15, 157);
        temp0.m1("", (java.lang.Object) "hi!", 181);
        temp0.m1("", (java.lang.Object) 54, 152);
        Temp temp15 = new Temp();
        temp15.m1("", (java.lang.Object) 127, 95);
        temp15.m();
        Temp temp22 = new Temp();
        temp22.m();
        temp22.m1("hi!", (java.lang.Object) 88, 94);
        temp22.m1("hi!", (java.lang.Object) 131, 98);
        temp22.m1("", (java.lang.Object) 13, 103);
        temp15.m1("", (java.lang.Object) temp22, 131);
        temp15.m1("", (java.lang.Object) 135, 115);
        temp15.m();
        temp15.m();
        temp0.m1("hi!", (java.lang.Object) temp15, (int) '4');
    }

    @Test
    public void test614() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test614");
        Temp temp0 = new Temp();
        temp0.m();
        temp0.m1("hi!", (java.lang.Object) 88, 94);
        temp0.m();
        temp0.m();
        temp0.m();
        temp0.m1("hi!", (java.lang.Object) 92, 91);
        java.lang.Class<?> wildcardClass13 = temp0.getClass();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass13);
    }

    @Test
    public void test615() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test615");
        Temp temp0 = new Temp();
        Temp temp2 = new Temp();
        temp2.m1("", (java.lang.Object) 127, 95);
        temp2.m1("hi!", (java.lang.Object) 126, 22);
        temp2.m1("", (java.lang.Object) 157, 154);
        ExampleTransformed exampleTransformed16 = new ExampleTransformed();
        temp2.m1("hi!", (java.lang.Object) exampleTransformed16, 10);
        temp2.m();
        temp2.m1("hi!", (java.lang.Object) 256, 51);
        temp2.m();
        temp2.m1("", (java.lang.Object) 2048, 1);
        temp2.m1("hi!", (java.lang.Object) 14, 128);
        temp2.m1("", (java.lang.Object) 146, 118);
        Temp temp38 = new Temp();
        temp38.m();
        temp38.m1("hi!", (java.lang.Object) 88, 94);
        temp38.m();
        temp2.m1("", (java.lang.Object) temp38, 84);
        temp38.m();
        temp0.m1("hi!", (java.lang.Object) temp38, 131);
        java.lang.Class<?> wildcardClass50 = temp0.getClass();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass50);
    }

    @Test
    public void test616() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test616");
        Temp temp0 = new Temp();
        temp0.m();
        temp0.m1("hi!", (java.lang.Object) 88, 94);
        temp0.m1("hi!", (java.lang.Object) 131, 98);
        temp0.m1("", (java.lang.Object) 13, 103);
        temp0.m();
        temp0.m();
        temp0.m();
        temp0.m1("hi!", (java.lang.Object) 262144, 84);
        temp0.m1("", (java.lang.Object) 32768, 91);
        temp0.m();
        Temp temp27 = new Temp();
        temp27.m();
        temp27.m1("hi!", (java.lang.Object) 88, 94);
        temp27.m1("hi!", (java.lang.Object) 131, 98);
        temp27.m1("", (java.lang.Object) 147, (-65536));
        temp27.m1("hi!", (java.lang.Object) 12, 181);
        java.lang.Class<?> wildcardClass45 = temp27.getClass();
        temp0.m1("hi!", (java.lang.Object) wildcardClass45, 5);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass45);
    }

    @Test
    public void test617() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test617");
        Temp temp0 = new Temp();
        temp0.m();
        temp0.m1("", (java.lang.Object) 15, 157);
        temp0.m1("", (java.lang.Object) "hi!", 181);
        temp0.m1("hi!", (java.lang.Object) 9, 6);
        temp0.m();
        java.lang.Class<?> wildcardClass15 = temp0.getClass();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass15);
    }

    @Test
    public void test618() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test618");
        Temp temp0 = new Temp();
        temp0.m();
        temp0.m1("hi!", (java.lang.Object) 88, 94);
        temp0.m1("hi!", (java.lang.Object) 131, 98);
        temp0.m1("", (java.lang.Object) 13, 103);
        temp0.m1("hi!", (java.lang.Object) 131, 143);
        temp0.m1("", (java.lang.Object) 23, 113);
        Temp temp23 = new Temp();
        temp23.m1("", (java.lang.Object) 127, 95);
        temp23.m1("hi!", (java.lang.Object) 126, 22);
        temp23.m1("", (java.lang.Object) 157, 154);
        ExampleTransformed exampleTransformed37 = new ExampleTransformed();
        temp23.m1("hi!", (java.lang.Object) exampleTransformed37, 10);
        temp23.m();
        temp23.m1("hi!", (java.lang.Object) 256, 51);
        temp23.m();
        temp23.m();
        temp23.m();
        temp0.m1("hi!", (java.lang.Object) temp23, 161);
        temp23.m();
        Temp temp52 = new Temp();
        temp52.m();
        temp52.m1("", (java.lang.Object) 15, 141);
        temp52.m();
        temp52.m1("hi!", (java.lang.Object) 121, 170);
        temp23.m1("", (java.lang.Object) "hi!", 171);
        temp23.m();
    }

    @Test
    public void test619() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test619");
        Temp temp0 = new Temp();
        temp0.m();
        temp0.m1("hi!", (java.lang.Object) 88, 94);
        temp0.m1("hi!", (java.lang.Object) 131, 98);
        temp0.m1("", (java.lang.Object) 13, 103);
        temp0.m1("hi!", (java.lang.Object) 131, 143);
        temp0.m1("", (java.lang.Object) 195, 118);
        java.lang.Object obj23 = null;
        temp0.m1("", obj23, 58);
        Temp temp27 = new Temp();
        temp27.m1("", (java.lang.Object) 127, 95);
        temp27.m1("hi!", (java.lang.Object) 126, 22);
        temp27.m1("", (java.lang.Object) 152, 199);
        temp27.m();
        temp0.m1("", (java.lang.Object) temp27, 50);
        temp27.m();
    }

    @Test
    public void test620() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test620");
        Temp temp0 = new Temp();
        temp0.m();
        temp0.m1("hi!", (java.lang.Object) 88, 94);
        temp0.m1("hi!", (java.lang.Object) 131, 98);
        temp0.m1("", (java.lang.Object) 13, 103);
        temp0.m1("hi!", (java.lang.Object) 131, 143);
        temp0.m1("", (java.lang.Object) 262144, 158);
        temp0.m();
        temp0.m();
        Temp temp25 = new Temp();
        temp25.m();
        temp25.m1("", (java.lang.Object) 15, 141);
        temp25.m1("", (java.lang.Object) 128, (int) (short) 100);
        temp25.m();
        java.lang.Class<?> wildcardClass36 = temp25.getClass();
        temp0.m1("", (java.lang.Object) wildcardClass36, 96);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass36);
    }

    @Test
    public void test621() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test621");
        Temp temp0 = new Temp();
        temp0.m();
        temp0.m1("", (java.lang.Object) 15, 157);
        temp0.m1("hi!", (java.lang.Object) 21, 152);
        temp0.m();
        temp0.m1("hi!", (java.lang.Object) 32, 104);
        Temp temp16 = new Temp();
        temp16.m();
        temp16.m1("hi!", (java.lang.Object) 88, 94);
        temp16.m1("hi!", (java.lang.Object) 131, 98);
        temp16.m1("", (java.lang.Object) 147, (-65536));
        temp16.m1("hi!", (java.lang.Object) 86, 177);
        Temp temp35 = new Temp();
        temp35.m();
        java.lang.Class<?> wildcardClass37 = temp35.getClass();
        temp16.m1("", (java.lang.Object) wildcardClass37, 184);
        java.lang.Class<?> wildcardClass40 = temp16.getClass();
        temp0.m1("", (java.lang.Object) temp16, 129);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass37);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass40);
    }

    @Test
    public void test622() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test622");
        Temp temp0 = new Temp();
        temp0.m1("hi!", (java.lang.Object) (short) 100, 120);
        temp0.m();
        temp0.m();
        temp0.m();
        temp0.m();
        temp0.m1("hi!", (java.lang.Object) 174, 0);
    }

    @Test
    public void test623() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test623");
        Temp temp0 = new Temp();
        temp0.m();
        temp0.m();
        Temp temp4 = new Temp();
        temp4.m();
        temp4.m1("hi!", (java.lang.Object) 88, 94);
        temp4.m1("hi!", (java.lang.Object) 131, 98);
        temp0.m1("", (java.lang.Object) 131, 5);
        temp0.m1("hi!", (java.lang.Object) 168, 100);
        temp0.m1("", (java.lang.Object) 0, 159);
        temp0.m();
        temp0.m();
    }

    @Test
    public void test624() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test624");
        Temp temp0 = new Temp();
        temp0.m();
        temp0.m1("hi!", (java.lang.Object) 88, 94);
        temp0.m1("hi!", (java.lang.Object) 131, 98);
        temp0.m1("", (java.lang.Object) 13, 103);
        temp0.m1("hi!", (java.lang.Object) 131, 143);
        temp0.m1("", (java.lang.Object) 195, 0);
        temp0.m();
        Temp temp24 = new Temp();
        temp24.m1("", (java.lang.Object) 127, 95);
        temp24.m();
        temp24.m();
        temp24.m1("", (java.lang.Object) 81, 139);
        java.lang.Object obj36 = null;
        temp24.m1("", obj36, 7);
        temp0.m1("", (java.lang.Object) temp24, (int) (byte) -1);
        temp24.m();
        temp24.m();
        temp24.m();
    }

    @Test
    public void test625() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test625");
        Temp temp0 = new Temp();
        temp0.m();
        temp0.m1("", (java.lang.Object) 15, 141);
        temp0.m();
        temp0.m();
        temp0.m();
        temp0.m();
        java.lang.Class<?> wildcardClass10 = temp0.getClass();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass10);
    }

    @Test
    public void test626() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test626");
        Temp temp0 = new Temp();
        temp0.m();
        temp0.m1("hi!", (java.lang.Object) 88, 94);
        temp0.m1("hi!", (java.lang.Object) 131, 98);
        temp0.m1("", (java.lang.Object) 13, 103);
        temp0.m1("hi!", (java.lang.Object) 131, 143);
        temp0.m1("hi!", (java.lang.Object) 161, 132);
        temp0.m();
        temp0.m();
        temp0.m();
        temp0.m();
    }

    @Test
    public void test627() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test627");
        Temp temp0 = new Temp();
        temp0.m1("", (java.lang.Object) 127, 95);
        temp0.m();
        Temp temp7 = new Temp();
        temp7.m();
        temp7.m1("hi!", (java.lang.Object) 88, 94);
        temp7.m1("hi!", (java.lang.Object) 131, 98);
        temp7.m1("", (java.lang.Object) 13, 103);
        temp0.m1("", (java.lang.Object) temp7, 131);
        temp0.m1("", (java.lang.Object) 135, 115);
        temp0.m();
        temp0.m();
        temp0.m();
        Temp temp31 = new Temp();
        temp31.m1("", (java.lang.Object) 127, 95);
        temp31.m();
        temp31.m();
        temp31.m();
        temp31.m1("", (java.lang.Object) 176, (int) '#');
        temp31.m();
        temp31.m();
        temp31.m();
        temp0.m1("", (java.lang.Object) temp31, 0);
        java.lang.Class<?> wildcardClass48 = temp0.getClass();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass48);
    }

    @Test
    public void test628() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test628");
        Temp temp0 = new Temp();
        temp0.m();
        temp0.m1("hi!", (java.lang.Object) 88, 94);
        temp0.m1("hi!", (java.lang.Object) 131, 98);
        temp0.m1("", (java.lang.Object) 13, 103);
        temp0.m1("hi!", (java.lang.Object) 131, 143);
        temp0.m1("", (java.lang.Object) 195, 118);
        temp0.m1("", (java.lang.Object) 96, 88);
        Temp temp27 = new Temp();
        temp27.m1("", (java.lang.Object) 127, 95);
        temp27.m();
        temp27.m();
        Temp temp35 = new Temp();
        temp35.m();
        temp35.m1("hi!", (java.lang.Object) 88, 94);
        temp35.m1("hi!", (java.lang.Object) 131, 98);
        temp35.m1("", (java.lang.Object) 13, 103);
        temp35.m1("hi!", (java.lang.Object) 131, 143);
        temp35.m1("", (java.lang.Object) 23, 113);
        java.lang.Object obj58 = null;
        temp35.m1("hi!", obj58, 58);
        temp27.m1("", (java.lang.Object) temp35, 256);
        java.lang.Class<?> wildcardClass63 = temp27.getClass();
        temp0.m1("", (java.lang.Object) temp27, 185);
        Temp temp67 = new Temp();
        temp67.m();
        temp67.m1("hi!", (java.lang.Object) 88, 94);
        temp67.m();
        temp67.m();
        temp0.m1("", (java.lang.Object) temp67, 2);
        temp67.m();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass63);
    }
}

